const test = require('node:test'), assert = require('node:assert');
const C = require('../app/core.js');
const mk = (o) => Object.assign({ id: 'p1', student: 'Mina', total: 10, price: 500, currency: 'USD', start: '2026-10-01', expires: '2026-12-31', stamps: [], paid: true }, o);

test('remaining and per-lesson value', () => {
  const p = mk(); assert.equal(C.remaining(p), 10); assert.equal(C.perLesson(p), 50);
  C.addStamp(p, '2026-10-05'); C.addStamp(p, '2026-10-02');
  assert.equal(C.remaining(p), 8); assert.equal(C.unearned(p), 400);
  assert.equal(p.stamps[0].date, '2026-10-02', 'stamps stay sorted');
});
test('cannot stamp beyond total', () => {
  const p = mk({ total: 1 }); assert.ok(C.addStamp(p, '2026-10-01')); assert.equal(C.addStamp(p, '2026-10-02'), false);
});
test('status transitions', () => {
  const p = mk({ total: 3 });
  assert.equal(C.status(p, '2026-11-01'), 'active');
  C.addStamp(p, '2026-10-02'); C.addStamp(p, '2026-10-03');
  assert.equal(C.status(p, '2026-11-01'), 'low');
  assert.equal(C.status(p, '2027-01-01'), 'expired');
  C.addStamp(p, '2026-10-04'); assert.equal(C.status(p, '2027-01-01'), 'done');
  assert.equal(C.status(mk({ expires: '' }), '2030-01-01'), 'active');
});
test('removeStamp restores balance', () => {
  const p = mk(); C.addStamp(p, '2026-10-02'); const id = p.stamps[0].id;
  assert.ok(C.removeStamp(p, id)); assert.equal(C.remaining(p), 10); assert.equal(C.removeStamp(p, id), false);
});
test('date helpers incl. month-end clamp', () => {
  assert.equal(C.addMonths('2026-01-31', 1), '2026-02-28');
  assert.equal(C.addMonths('2026-11-15', 3), '2027-02-15');
  assert.equal(C.addDays('2026-12-30', 3), '2027-01-02');
  assert.equal(C.daysBetween('2026-10-01', '2026-10-31'), 30);
});
test('month stats and unearned total exclude expired', () => {
  const a = mk(); C.addStamp(a, '2026-10-05'); C.addStamp(a, '2026-11-02');
  const b = mk({ id: 'p2', start: '2026-11-03', price: 100, total: 4, expires: '2026-01-01' });
  const s = C.monthStats([a, b], '2026-10'); assert.deepEqual(s, { lessons: 1, earned: 50, cash: 500 });
  assert.equal(C.monthStats([a, b], '2026-11').cash, 100);
  assert.equal(C.totalUnearned([a, b], '2026-11-10'), 400);
  assert.equal(C.lapsed([a, b], '2026-11-10').length, 1);
});
test('balance card round-trips unicode and rejects junk', () => {
  const p = mk({ student: '김민아 😀' }); C.addStamp(p, '2026-10-05');
  const c = C.decodeCard(C.encodeCard(p, 'Park 선생님'));
  assert.equal(c.student, '김민아 😀'); assert.equal(c.teacher, 'Park 선생님'); assert.deepEqual(c.dates, ['2026-10-05']); assert.equal(c.total, 10);
  assert.equal(C.decodeCard('not-base64!!'), null);
  assert.equal(C.decodeCard(Buffer.from(JSON.stringify({ v: 1, n: 'x', T: 5, s: ['<script>'] })).toString('base64')), null);
  assert.equal(C.decodeCard(Buffer.from(JSON.stringify({ v: 1, n: 'x', T: 99999, s: [] })).toString('base64')), null);
  assert.equal(C.encodeCard(p, '').includes('+'), false);
});
test('csv escapes quotes, commas and formula injection', () => {
  const p = mk({ student: '=HYPERLINK("x"),"a"' });
  const out = C.toCsv([p]).split('\n')[1];
  assert.ok(out.startsWith('"\'=HYPERLINK(""x""),""a"""'), out);
});
test('licence keys', () => {
  const k = C.makeKey('hello123'); assert.ok(C.validKey(k)); assert.ok(C.validKey(' ' + k.toLowerCase() + ' '));
  assert.equal(C.validKey(k.slice(0, -1) + (k.endsWith('A') ? 'B' : 'A')), false); assert.equal(C.validKey(''), false);
});

test('excused absences are logged but not counted; no-shows are counted', () => {
  const p = mk({ total: 2 });
  assert.ok(C.addStamp(p, '2026-10-02', 'sick', 'excused')); assert.equal(C.remaining(p), 2);
  assert.ok(C.addStamp(p, '2026-10-03', '', 'noshow')); assert.equal(C.remaining(p), 1);
  assert.ok(C.addStamp(p, '2026-10-04')); assert.equal(C.status(p, '2026-10-05'), 'done');
  assert.equal(C.addStamp(p, '2026-10-06'), false); assert.ok(C.addStamp(p, '2026-10-06', 'late', 'excused'), 'excused allowed when full');
  assert.equal(C.decodeCard(C.encodeCard(p, '')).dates.length, 2);
  assert.equal(C.monthStats([p], '2026-10').lessons, 2);
  assert.ok(C.toCsv([p]).split('\n')[1].endsWith(',1,2,2'));
});
test('legacy stamps without kind still work', () => {
  const p = mk(); p.stamps.push({ id: 'x', date: '2026-10-01', note: '' }); assert.equal(C.remaining(p), 9);
});
test('notes are trimmed and settable', () => {
  const p = mk(); C.addStamp(p, '2026-10-01', 'x'.repeat(500)); assert.equal(p.stamps[0].note.length, 200);
  assert.ok(C.setNote(p, p.stamps[0].id, 'ok')); assert.equal(p.stamps[0].note, 'ok'); assert.equal(C.setNote(p, 'nope', 'z'), false);
});
test('renew copies terms; months derived for old packs', () => {
  const old = mk({ start: '2026-10-01', expires: '2026-12-31' }); assert.equal(C.monthsOf(old), 3);
  const n = C.renew(old, '2026-11-15', 'new1'); assert.equal(n.expires, '2027-02-15'); assert.equal(n.total, 10); assert.equal(n.stamps.length, 0); assert.equal(n.renewsFrom, 'p1');
  assert.equal(C.renew(mk({ expires: '' }), '2026-11-15').expires, '');
  assert.equal(C.monthsOf(mk({ months: 6 })), 6);
});
test('extend moves from later of expiry or today', () => {
  const p = mk({ expires: '2026-10-01' }); assert.equal(C.extend(p, 1, '2026-10-20'), '2026-11-20');
  const q = mk({ expires: '2026-12-10' }); assert.equal(C.extend(q, 1, '2026-10-20'), '2027-01-10');
});
test('attention and search', () => {
  const a = mk({ expires: '2026-11-03' }), b = mk({ id: 'b', student: 'Joon', expires: '2027-06-01' }), c = mk({ id: 'c', student: 'Ana', total: 1 });
  C.addStamp(c, '2026-10-01', '', ''); // done -> not attention
  const t = '2026-10-30'; assert.deepEqual(C.attention([a, b, c], t).map(x => x.id), ['p1']);
  assert.equal(C.matches(b, ' jo '), true); assert.equal(C.matches(b, 'zz'), false); assert.equal(C.matches(b, ''), true);
});

test('monthReport: per-student lessons for one month, excused not counted, formulas neutralised', () => {
  const a = mk({ student: 'Mina', total: 10, price: 500 });
  C.addStamp(a, '2026-10-05'); C.addStamp(a, '2026-10-12', '', 'noshow'); C.addStamp(a, '2026-10-19', '', 'excused'); C.addStamp(a, '2026-11-02');
  const b = mk({ id: 'p2', student: '=evil', total: 4, price: 200 }); C.addStamp(b, '2026-10-08');
  const c = mk({ id: 'p3', student: 'Idle' }); C.addStamp(c, '2026-09-01');
  const rows = C.monthReport([a, b, c], '2026-10').split('\n');
  assert.equal(rows[0], 'month,student,lessons,no_shows,excused,earned,currency');
  assert.equal(rows[1], '2026-10,Mina,2,1,1,100,USD');
  assert.equal(rows[2], "2026-10,'=evil,1,0,0,50,USD");
  assert.equal(rows.length, 3, 'students with no activity that month are left out');
});

/* ---- insights ---- */
const stamp = (p, d, kind) => C.addStamp(p, d, '', kind);
const sample = () => {
  const a = mk({ id: 'a', student: 'Mina', total: 10 }), b = mk({ id: 'b', student: 'Joon', total: 4, price: 200 });
  stamp(a, '2026-09-30'); stamp(a, '2026-10-05'); stamp(a, '2026-10-12', 'noshow'); stamp(a, '2026-10-19', 'excused'); stamp(a, '2026-10-26');
  stamp(b, '2026-10-05'); stamp(b, '2026-11-02');
  return [a, b];
};
test('ymAdd crosses year boundaries', () => {
  assert.equal(C.ymAdd('2026-11', 1), '2026-12'); assert.equal(C.ymAdd('2026-12', 1), '2027-01'); assert.equal(C.ymAdd('2026-01', -2), '2025-11');
});
test('monthGrid is rectangular and starts on the right weekday', () => {
  const g = C.monthGrid('2026-11', 0); // 1 Nov 2026 is a Sunday
  assert.equal(g.length % 7, 0); assert.equal(g[0], '2026-11-01'); assert.equal(g.filter(Boolean).length, 30); assert.equal(g.length, 35);
  const m = C.monthGrid('2026-11', 1); assert.equal(m.indexOf('2026-11-01'), 6); assert.equal(m.length, 42);
  assert.equal(C.monthGrid('2026-02', 1).filter(Boolean).length, 28);
});
test('events and dayMap include every kind, sorted', () => {
  const ev = C.events(sample()); assert.equal(ev.length, 7); assert.equal(ev[0].date, '2026-09-30');
  const dm = C.dayMap(sample(), '2026-10'); assert.deepEqual(Object.keys(dm).sort(), ['2026-10-05', '2026-10-12', '2026-10-19', '2026-10-26']);
  assert.equal(dm['2026-10-05'].length, 2); assert.equal(dm['2026-10-19'][0].kind, 'excused');
});
test('monthlyTrend counts lessons and no-shows, excused excluded', () => {
  const t = C.monthlyTrend(sample(), '2026-11', 3);
  assert.deepEqual(t.map(x => x.ym), ['2026-09', '2026-10', '2026-11']);
  assert.deepEqual(t.map(x => x.lessons), [1, 4, 1]); assert.deepEqual(t.map(x => x.noshow), [0, 1, 0]);
  assert.equal(C.monthlyTrend([], '2026-01', 2)[0].lessons, 0);
});
test('weekdayCounts', () => {
  const c = C.weekdayCounts(sample()); // 05 Oct 2026 is Monday, 12 Oct Monday(noshow counts), 26 Oct Monday
  assert.equal(c.reduce((x, y) => x + y, 0), 6); assert.equal(c[1], 5);
});
test('studentStats merges packs by name and computes attendance', () => {
  const ps = sample(); ps.push(mk({ id: 'c', student: ' mina ', total: 2 })); stamp(ps[2], '2026-11-01');
  const rows = C.studentStats(ps, '2026-11-05'), m = rows.find(r => r.student === 'Mina');
  assert.equal(rows.length, 2); assert.equal(m.packs, 2); assert.equal(m.lessons, 5); assert.equal(m.noshow, 1); assert.equal(m.excused, 1);
  assert.equal(m.attendance, 80); assert.equal(m.last, '2026-11-01'); assert.equal(m.sinceLast, 4); assert.equal(m.spent, 1000);
  assert.equal(rows[0].student, 'Mina', 'busiest first');
  assert.equal(m.avgGap, Math.round(32 / 4 * 10) / 10);
});
test('studentStats handles students with no lessons', () => {
  const r = C.studentStats([mk()], '2026-11-01')[0];
  assert.equal(r.lessons, 0); assert.equal(r.attendance, null); assert.equal(r.last, ''); assert.equal(r.sinceLast, null); assert.equal(r.avgGap, null);
});
test('quiet lists students with lessons left and no recent lesson', () => {
  const ps = sample(), today = '2026-11-20';
  assert.deepEqual(C.quiet(ps, today, 14).map(r => r.student), ['Mina', 'Joon']);
  assert.deepEqual(C.quiet(ps, today, 20).map(r => r.student), ['Mina']);
  assert.deepEqual(C.quiet(ps, today, 30).length, 0);
  const done = mk({ total: 1 }); stamp(done, '2026-01-01');
  assert.equal(C.quiet([done], today, 14).length, 0, 'no lessons left means nothing to chase');
  assert.equal(C.quiet([mk({ expires: '2026-01-01' })], today, 14).length, 0, 'expired lessons are not chased');
  assert.equal(C.quiet([mk()], today, 14).length, 1, 'never started counts');
});
test('overview totals', () => {
  const o = C.overview(sample(), '2026-11-05');
  assert.deepEqual(o, { students: 2, lessons: 6, noshow: 1, excused: 1, noshowRate: 17 });
  assert.equal(C.overview([], '2026-11-05').noshowRate, 0);
});

test('app i18n: every language has every key', () => {
  const I = require('../app/i18n.js'), keys = Object.keys(I.L.en);
  for (const l of I.langs) for (const k of keys) assert.ok(typeof I.L[l][k] === 'string' && I.L[l][k].trim(), `${l}.${k}`);
});

/* ---- schedule, agenda, ics, backup nudge ---- */
const sched = (o) => { const p = mk(Object.assign({ start: '2026-11-01', expires: '2026-12-31', total: 3 }, o)); C.setSchedule(p, [1, 3], '18:30'); return p; };
test('setSchedule normalises days and time, empty removes it', () => {
  const p = mk(); assert.deepEqual(C.setSchedule(p, ['3', 1, 1, 9, -1, 'x', 2.5], '7:00'), { days: [1, 3], time: '' });
  assert.equal(C.setSchedule(p, [2], '07:05').time, '07:05');
  assert.equal(C.setSchedule(p, [], '10:00'), null); assert.equal(p.schedule, undefined);
});
test('upcoming respects remaining lessons, window and stamped dates', () => {
  const p = sched(); // Mondays and Wednesdays
  assert.deepEqual(C.upcoming(p, '2026-11-01', 14).map(e => e.date), ['2026-11-02', '2026-11-04', '2026-11-09']);
  C.addStamp(p, '2026-11-02'); assert.deepEqual(C.upcoming(p, '2026-11-01', 14).map(e => e.date), ['2026-11-04', '2026-11-09'], 'stamped day and used lesson drop out');
  assert.deepEqual(C.upcoming(sched({ start: '2026-11-05' }), '2026-11-01', 20).map(e => e.date), ['2026-11-09', '2026-11-11', '2026-11-16'], 'not before start');
  assert.deepEqual(C.upcoming(sched({ expires: '2026-11-03' }), '2026-11-01', 14).map(e => e.date), ['2026-11-02'], 'not after expiry');
  assert.deepEqual(C.upcoming(mk(), '2026-11-01', 14), [], 'no schedule');
  const done = sched({ total: 1 }); C.addStamp(done, '2026-10-30'); assert.deepEqual(C.upcoming(done, '2026-11-01', 14), []);
});
test('agenda merges packs sorted by date then time', () => {
  const a = sched({ id: 'a', student: 'A' }), b = sched({ id: 'b', student: 'B' }); C.setSchedule(b, [1], '09:00');
  const ag = C.agenda([a, b], '2026-11-02', 3);
  assert.deepEqual(ag.map(e => e.student + e.date.slice(8) + e.time), ['B0209:00', 'A0218:30', 'A0418:30']);
});
test('toIcs makes valid, escaped events', () => {
  const p = sched({ student: 'Mi,na; Kim' }), ics = C.toIcs([p], '2026-11-02', 1, Date.UTC(2026, 10, 1, 12, 0, 0));
  assert.ok(ics.startsWith('BEGIN:VCALENDAR\r\n') && ics.endsWith('END:VCALENDAR\r\n'));
  assert.ok(ics.includes('SUMMARY:Mi\\,na\\; Kim')); assert.ok(ics.includes('DTSTART:20261102T183000') && ics.includes('DTEND:20261102T193000'));
  assert.ok(ics.includes('DTSTAMP:20261101T120000Z'));
  const late = mk({ id: 'l', start: '2026-11-01', expires: '' }); C.setSchedule(late, [1], '23:30');
  assert.ok(C.toIcs([late], '2026-11-02', 1, 0).includes('DTEND:20261103T003000'), 'crosses midnight');
  const allDay = mk({ id: 'd', start: '2026-11-01', expires: '' }); C.setSchedule(allDay, [1], '');
  assert.ok(C.toIcs([allDay], '2026-11-02', 1, 0).includes('DTSTART;VALUE=DATE:20261102'));
  assert.equal(C.toIcs([], '2026-11-02', 30, 0).includes('VEVENT'), false);
});
test('backupDue only when there is data worth saving', () => {
  const few = mk(); for (let i = 1; i <= 4; i++) C.addStamp(few, '2026-10-0' + i);
  const now = Date.UTC(2026, 10, 1); assert.equal(C.backupDue([few], 0, now), false);
  C.addStamp(few, '2026-10-05'); assert.equal(C.backupDue([few], 0, now), true);
  assert.equal(C.backupDue([few], now - 13 * 86400000, now), false); assert.equal(C.backupDue([few], now - 14 * 86400000, now), true);
});

/* ---- payments, note search, forecast ---- */
test('unpaid packs and outstanding amount', () => {
  const a = mk({ id: 'a', price: 300 }), b = mk({ id: 'b', price: 120.5 }), c = mk({ id: 'c' });
  assert.equal(C.setPaid(a, false), false); C.setPaid(b, false);
  assert.deepEqual(C.unpaid([a, b, c]).map(p => p.id), ['a', 'b']); assert.equal(C.outstanding([a, b, c]), 420.5);
  C.setPaid(a, true); assert.equal(C.outstanding([a, b, c]), 120.5);
  assert.equal(C.outstanding([mk({ paid: undefined })]), 0, 'legacy packs without the flag count as paid');
});
test('unpaid packs are left out of cash collected', () => {
  const p = mk({ start: '2026-10-03' }); assert.equal(C.monthStats([p], '2026-10').cash, 500);
  C.setPaid(p, false); assert.equal(C.monthStats([p], '2026-10').cash, 0);
});
test('searchNotes is case-insensitive, newest first, ignores short queries', () => {
  const p = mk(); C.addStamp(p, '2026-10-01', 'Scales and Arpeggios'); C.addStamp(p, '2026-10-08', 'homework: scales'); C.addStamp(p, '2026-10-15', 'sight reading');
  assert.deepEqual(C.searchNotes([p], ' SCALES ').map(e => e.date), ['2026-10-08', '2026-10-01']);
  assert.deepEqual(C.searchNotes([p], 's'), []); assert.deepEqual(C.searchNotes([p], ''), []); assert.deepEqual(C.searchNotes([p], 'zzz'), []);
  assert.equal(C.searchNotes([p], 'sc', 1).length, 1);
  assert.equal(C.searchNotes([p], 'scales')[0].student, 'Mina');
});
test('forecast values planned lessons at the per-lesson price', () => {
  const p = sched({ price: 300 }); // 3 lessons, 100 each, Mon/Wed
  assert.deepEqual(C.forecast([p], '2026-11-01', 14), { lessons: 3, value: 300 });
  assert.deepEqual(C.forecast([p], '2026-11-01', 4), { lessons: 2, value: 200 });
  assert.deepEqual(C.forecast([mk()], '2026-11-01', 30), { lessons: 0, value: 0 });
});

/* ---- presets and monthly report ---- */
test('presets ranks reused terms, ties go to the newer pack', () => {
  const ps = [mk({ id: '1', total: 8, price: 400 }), mk({ id: '2', total: 10, price: 500 }), mk({ id: '3', total: 10, price: 500 }), mk({ id: '4', total: 5, price: 250 })];
  const r = C.presets(ps, 2); assert.equal(r.length, 2); assert.deepEqual([r[0].total, r[0].price, r[0].count], [10, 500, 2]); assert.equal(r[1].total, 8, 'newest of the singles');
  assert.deepEqual(C.presets([], 3), []);
  assert.equal(C.presets(ps).length, 3, 'default is three');
});
test('presets keeps currency and validity apart', () => {
  const r = C.presets([mk({ id: '1', currency: 'KRW', months: 1, start: '', expires: '' }), mk({ id: '2', currency: 'USD', months: 3 })], 5);
  assert.equal(r.length, 2); assert.equal(r[0].currency, 'KRW'); assert.equal(r[0].months, 1); assert.equal(r[1].months, 3);
});
test('report summarises one month of a pack', () => {
  const p = mk({ total: 5 }); C.addStamp(p, '2026-09-30'); C.addStamp(p, '2026-10-05', 'scales'); C.addStamp(p, '2026-10-12', '', 'noshow'); C.addStamp(p, '2026-10-19', '', 'excused');
  const r = C.report(p, '2026-10', '2026-11-01');
  assert.deepEqual(r.rows.map(x => x.date), ['2026-10-05', '2026-10-12', '2026-10-19']);
  assert.deepEqual([r.lessons, r.noshow, r.excused, r.left, r.total, r.status], [2, 1, 1, 2, 5, 'active']);
  assert.equal(r.rows[0].note, 'scales'); assert.deepEqual(C.report(p, '2026-08', '2026-11-01').rows, []);
});

/* ---- skipped dates ---- */
test('toggleSkip hides one planned date and restores it', () => {
  const p = sched(); assert.equal(C.toggleSkip(p, '2026-11-02'), true);
  assert.deepEqual(C.upcoming(p, '2026-11-01', 14).map(e => e.date), ['2026-11-04', '2026-11-09', '2026-11-11'], 'next lesson fills the freed slot');
  assert.deepEqual(C.plannedWithSkips(p, '2026-11-01', 14).map(e => e.date + (e.skipped ? '!' : '')), ['2026-11-02!', '2026-11-04', '2026-11-09']);
  assert.equal(C.toggleSkip(p, '2026-11-02'), false); assert.equal(p.schedule.skip, undefined);
  assert.equal(C.toggleSkip(mk(), '2026-11-02'), false, 'no schedule, nothing to skip');
});
test('editing the weekly pattern keeps skipped dates', () => {
  const p = sched(); C.toggleSkip(p, '2026-11-09'); C.setSchedule(p, [1], '10:00');
  assert.deepEqual(p.schedule, { days: [1], time: '10:00', skip: ['2026-11-09'] });
  assert.deepEqual(C.upcoming(p, '2026-11-01', 20).map(e => e.date), ['2026-11-02', '2026-11-16']);
});

/* ---- merge ---- */
test('mergePacks unions stamps by id and adds new packs', () => {
  const a = mk({ id: 'a' }), a2 = JSON.parse(JSON.stringify(a)); C.addStamp(a, '2026-10-05'); a2.stamps = JSON.parse(JSON.stringify(a.stamps));
  C.addStamp(a2, '2026-10-12'); a2.price = 999; const b = mk({ id: 'b', student: 'Joon' });
  const r = C.mergePacks([a], [a2, b]);
  assert.deepEqual([r.added, r.merged, r.packs.length], [1, 1, 2]);
  assert.deepEqual(r.packs[0].stamps.map(s => s.date), ['2026-10-05', '2026-10-12']); assert.equal(r.packs[0].price, 500, 'local fields win');
  const again = C.mergePacks(r.packs, [a2, b]); assert.deepEqual([again.added, again.merged, again.packs.length], [0, 0, 2], 'merging twice changes nothing');
  assert.equal(C.mergePacks([], []).packs.length, 0);
});
test('mergePacks copies incoming data rather than sharing it', () => {
  const b = mk({ id: 'b' }), r = C.mergePacks([], [b]); r.packs[0].student = 'X'; assert.equal(b.student, 'Mina');
});

test('statsCsv has one row per student and neutralises formulas', () => {
  const ps = sample(); ps[1].student = '=HYPERLINK("x")';
  const lines = C.statsCsv(ps, '2026-11-05').split('\n');
  assert.equal(lines.length, 3); assert.ok(lines[0].startsWith('student,packs,lessons'));
  assert.ok(lines[1].startsWith('Mina,1,4,1,1,75,'), lines[1]); assert.ok(lines.join('\n').includes('"\'=HYPERLINK(""x"")"'));
  assert.equal(C.statsCsv([], '2026-11-05').split('\n').length, 1);
});

test('incomeByMonth sums paid packs by start month and currency, skips unpaid', () => {
  const mk = (id, start, price, cur, paid) => ({ id, student: id, total: 5, price, currency: cur, start, expires: '', stamps: [], paid });
  const packs = [mk('a', '2026-11-03', 100, 'USD'), mk('b', '2026-11-20', 50.5, 'USD', true), mk('c', '2026-10-01', 80, 'EUR'),
    mk('d', '2026-11-05', 999, 'USD', false), mk('e', '2025-01-01', 70, 'USD')];
  const r = C.incomeByMonth(packs, '2026-11', 3);
  assert.deepEqual(r.map(x => x.ym), ['2026-09', '2026-10', '2026-11']);
  assert.deepEqual(r[2].byCur, { USD: 150.5 }); assert.equal(r[2].packs, 2);
  assert.deepEqual(r[1].byCur, { EUR: 80 }); assert.equal(r[0].packs, 0);
  assert.equal(C.incomeCsv(packs, '2026-11', 3), 'month,packs,income,currency\n2026-10,1,80,EUR\n2026-11,2,150.5,USD');
});

test('make-ups: excused lessons are owed back until a make-up lesson is stamped', () => {
  const p = { id: 'p1', student: 'Ann', total: 5, price: 50, stamps: [] };
  C.addStamp(p, '2026-11-02', '', 'excused'); C.addStamp(p, '2026-11-03', '', 'excused');
  assert.equal(C.makeupsOwed(p), 2); assert.equal(C.remaining(p), 5, 'excused does not use a lesson');
  C.addStamp(p, '2026-11-09', '', '', true); assert.equal(C.makeupsOwed(p), 1); assert.equal(C.remaining(p), 4);
  C.addStamp(p, '2026-11-10', '', '', true); C.addStamp(p, '2026-11-11', '', '', true); assert.equal(C.makeupsOwed(p), 0, 'never negative');
  C.addStamp(p, '2026-11-12', '', 'noshow', true); assert.ok(!p.stamps.some(s => s.kind === 'noshow' && s.mk), 'a no-show is not a make-up');
  assert.deepEqual(C.makeupList([p]), []);
  const q = { id: 'q', student: 'Bo', total: 3, price: 30, stamps: [] }; C.addStamp(q, '2026-11-01', '', 'excused');
  assert.equal(C.makeupList([p, q]).length, 1); assert.equal(C.makeupList([p, q])[0].student, 'Bo');
});

test('pace: warns when the remaining lessons will not fit before expiry', () => {
  const mk = (dates, total, expires) => { const p = { id: 'x', student: 'S', total, price: 100, expires, stamps: [] }; dates.forEach(d => C.addStamp(p, d)); return p; };
  const slow = mk(['2026-10-01', '2026-10-15', '2026-10-29'], 10, '2026-12-01');
  const r = C.pace(slow, '2026-11-02');
  assert.equal(r.atRisk, true); assert.ok(r.finish > '2026-12-01'); assert.ok(r.needPerWeek > 1);
  const fast = mk(['2026-10-26', '2026-10-28', '2026-10-30', '2026-11-01'], 8, '2026-12-31');
  assert.equal(C.pace(fast, '2026-11-02').atRisk, false);
  assert.equal(C.pace(mk(['2026-10-01'], 5, '2026-12-01'), '2026-11-02').known, false, 'too little history to project');
  assert.equal(C.pace(mk([], 5, ''), '2026-11-02'), null, 'no expiry, nothing to warn about');
  assert.equal(C.pace(mk(['2026-10-01', '2026-10-08'], 2, '2026-12-01'), '2026-11-02'), null, 'pack complete');
  assert.equal(C.pace(mk(['2026-10-01', '2026-10-08'], 5, '2026-11-01'), '2026-11-02'), null, 'already expired');
  assert.equal(C.packsAtRisk([slow, fast], '2026-11-02').length, 1);
});

test('receipt data', () => {
  const r = C.receipt({ student: 'Ann', total: 10, price: 250, currency: 'USD', start: '2026-11-01', expires: '2027-02-01' }, 'Prof. Park');
  assert.equal(r.perLesson, 25); assert.equal(r.paid, true); assert.equal(r.teacher, 'Prof. Park');
});

test('make-ups on expired packs are not listed; receipt knows unpaid; pace needs 3 past lessons', () => {
  const old = { id: 'o', student: 'Old', total: 5, price: 50, start: '2025-01-01', expires: '2025-03-01', stamps: [] };
  C.addStamp(old, '2025-01-05', '', 'excused'); assert.equal(C.makeupList([old], '2026-11-02')[0].open, false);
  assert.equal(C.receipt({ student: 'U', total: 2, price: 20, paid: false }).paid, false);
  const two = { id: 't', student: 'T', total: 5, price: 50, expires: '2026-10-31', stamps: [] };
  C.addStamp(two, '2026-10-01'); C.addStamp(two, '2026-10-20'); assert.equal(C.pace(two, '2026-10-03').known, false);
  assert.ok(C.toCsv([old]).split('\n')[0].endsWith('makeups_owed'));
});

test('owed make-ups stay visible on ended packs, can be waived, and reach the card and report', () => {
  const old = { id: 'o', student: 'Old', total: 3, price: 30, start: '2025-01-01', expires: '2025-03-01', stamps: [] };
  C.addStamp(old, '2025-01-05', '', 'excused');
  const l = C.makeupList([old], '2026-11-02'); assert.equal(l.length, 1); assert.equal(l[0].open, false);
  assert.equal(C.decodeCard(C.encodeCard(old, '')).owed, 1);
  assert.equal(C.report(old, '2025-01', '2026-11-02').owed, 1);
  assert.equal(C.waiveMakeups(old), 1); assert.equal(C.makeupsOwed(old), 0); assert.equal(C.makeupList([old], '2026-11-02').length, 0);
  C.addStamp(old, '2025-01-06', '', 'excused'); assert.equal(C.makeupsOwed(old), 1, 'a new excused lesson is owed again');
  assert.equal(C.decodeCard(C.encodeCard({ student: 'N', total: 2, stamps: [] }, '')).owed, 0);
});

test('waiving make-ups is tied to specific lessons', () => {
  const p = { id: 'w', student: 'W', total: 9, price: 90, stamps: [] };
  C.addStamp(p, '2026-10-01', '', 'excused'); C.addStamp(p, '2026-10-02', '', 'excused');
  C.waiveMakeups(p); assert.equal(C.makeupsOwed(p), 0);
  C.removeStamp(p, p.stamps[0].id); C.addStamp(p, '2026-10-05', '', 'excused');
  assert.equal(C.makeupsOwed(p), 1, 'a new excused lesson after a waive is still owed');
});

test('balance card carries the next-lesson note and unpaid flag', () => {
  const p = { id: 'n', student: 'Nia', total: 4, price: 40, paid: false, stamps: [] };
  C.setNext(p, '  Bring the red book  '); const c = C.decodeCard(C.encodeCard(p, 'T'));
  assert.equal(c.next, 'Bring the red book'); assert.equal(c.unpaid, true);
  const q = C.decodeCard(C.encodeCard({ student: 'Q', total: 2, stamps: [] }, '')); assert.equal(q.next, ''); assert.equal(q.unpaid, false);
  assert.equal(C.setNext(p, 'x'.repeat(300)).length, 120);
});

test('balance card records the date it was made', () => {
  const c = C.decodeCard(C.encodeCard({ student: 'D', total: 2, stamps: [] }, ''));
  assert.match(c.asOf, /^\d{4}-\d{2}-\d{2}$/);
});

test('balance card dates are packed small and old links still open', () => {
  const p = { id: 'b', student: 'Big', total: 200, price: 1, stamps: [] };
  for (let i = 0; i < 200; i++) C.addStamp(p, C.addDays('2026-01-01', i * 2));
  const link = C.encodeCard(p, 'Prof. Park'); assert.ok(link.length < 1500, 'link length ' + link.length);
  const back = C.decodeCard(link); assert.equal(back.dates.length, 200); assert.equal(back.dates[0], '2026-01-01'); assert.equal(back.dates[199], C.addDays('2026-01-01', 398));
  const legacy = Buffer.from(JSON.stringify({ v: 1, t: '', n: 'Old', T: 3, x: '', s: ['2026-10-01', '2026-10-08'] })).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  assert.deepEqual(C.decodeCard(legacy).dates, ['2026-10-01', '2026-10-08']);
  assert.equal(C.decodeCard(Buffer.from(JSON.stringify({ v: 1, n: 'X', T: 3, z: [1e9] })).toString('base64')), null);
});

test('balance link handles old and unsorted dates', () => {
  const p = { id: 'o', student: 'Old', total: 5, price: 1, stamps: [{ id: 'a', date: '2026-03-01' }, { id: 'b', date: '1999-12-31' }, { id: 'c', date: '1950-05-05' }] };
  assert.deepEqual(C.decodeCard(C.encodeCard(p, '')).dates, ['1950-05-05', '1999-12-31', '2026-03-01']);
});

test('ink colour is a bounded palette index; bad values fall back to the default', () => {
  const p = mk(); assert.equal(C.inkOf(p), 0);
  assert.ok(C.setInk(p, 3)); assert.equal(C.inkOf(p), 3);
  assert.ok(C.setInk(p, 0)); assert.equal('ink' in p, false);
  assert.equal(C.setInk(p, 99), false); assert.equal(C.setInk(p, 'x'), false);
  for (const bad of ['<script>', 7, -1, 1.5, null, {}]) assert.equal(C.inkOf({ ink: bad }), 0);
});
test('weekPlan groups planned lessons by day and skips empty days', () => {
  const a = mk({ id: 'a', student: 'Ann', schedule: { days: [1, 3], time: '10:00' } });
  const b = mk({ id: 'b', student: 'Bo', schedule: { days: [3], time: '09:00' } });
  const w = C.weekPlan([a, b], '2026-11-02', 7); // Monday
  assert.deepEqual(w.map(d => d.date), ['2026-11-02', '2026-11-04']);
  assert.deepEqual(w[1].items.map(i => i.student), ['Bo', 'Ann'], 'sorted by time within a day');
  assert.deepEqual(C.weekPlan([mk()], '2026-11-02', 7), []);
});
test('justCompleted is true only for the stamp that used up the pack', () => {
  const p = mk({ total: 2 }); C.addStamp(p, '2026-10-02'); const first = p.stamps[0].id;
  assert.equal(C.justCompleted(p, first), false);
  C.addStamp(p, '2026-10-03'); const last = p.stamps[1].id;
  assert.equal(C.justCompleted(p, last), true); assert.equal(C.justCompleted(p, first), false);
});

test('packs filter: attention, unpaid and ended are separate; all matches everything', () => {
  const today = '2026-11-05';
  const ok = mk({ id: 'ok' }), unpaid = mk({ id: 'u', paid: false }), done = mk({ id: 'd', total: 1 }), old = mk({ id: 'x', expires: '2026-01-01' });
  stamp(done, '2026-11-01');
  assert.deepEqual(C.FILTERS, ['all', 'attn', 'unpaid', 'ended']);
  const pick = (f) => [ok, unpaid, done, old].filter(p => C.matchesFilter(p, f, today)).map(p => p.id);
  assert.deepEqual(pick('all'), ['ok', 'u', 'd', 'x']);
  assert.deepEqual(pick('unpaid'), ['u']);
  assert.deepEqual(pick('ended'), ['d', 'x'], 'complete or expired');
  assert.deepEqual(pick('attn'), ['x'], 'expired with lessons left needs attention; complete does not');
});

test('cleanPacks keeps usable packs and stamps, drops the rest', () => {
  const good = mk({ id: 'g', stamps: [{ id: 's1', date: '2026-10-05', note: '' }, { id: 's2', date: 'soon' }, { date: '2026-10-06' }, null] });
  const out = C.cleanPacks([good, { id: 'n', student: 'No total', total: 0, stamps: [] }, { id: 'm', student: 'M', total: 3 }, null, { student: 'no id', total: 2, stamps: [] }]);
  assert.deepEqual(out.map(p => p.id), ['g']);
  assert.deepEqual(out[0].stamps.map(s => s.id), ['s1']);
  assert.deepEqual(C.cleanPacks('not a list'), []);
  assert.deepEqual(C.cleanPacks(undefined), []);
});

test('progress gives used out of total for the pack ring', () => {
  const p = mk({ total: 4 }); stamp(p, '2026-10-01'); stamp(p, '2026-10-02', 'excused');
  assert.deepEqual(C.progress(p), { used: 1, total: 4, pct: 0.25 });
  assert.deepEqual(C.progress(mk({ total: 0 })), { used: 0, total: 0, pct: 0 });
});

test('planned dates add one-off lessons without changing the weekly pattern', () => {
  const p = mk({ total: 5, expires: '' });
  assert.equal(C.addPlanned(p, '2026-11-07'), true); assert.equal(C.addPlanned(p, '2026-11-07'), false, 'no duplicates');
  assert.equal(C.addPlanned(p, 'soon'), false, 'bad dates are refused');
  C.addPlanned(p, '2026-11-03');
  assert.deepEqual(p.planned, ['2026-11-03', '2026-11-07']);
  assert.deepEqual(C.upcoming(p, '2026-11-01', 14).map(e => e.date), ['2026-11-03', '2026-11-07']);
  assert.equal(C.upcoming(p, '2026-11-01', 14)[0].planned, true);
  assert.deepEqual(C.upcoming(p, '2026-11-04', 14).map(e => e.date), ['2026-11-07'], 'outside the window is left out');
  assert.equal(C.removePlanned(p, '2026-11-03'), true); assert.equal(C.removePlanned(p, '2026-11-03'), false);
  assert.deepEqual(p.planned, ['2026-11-07']);
  C.removePlanned(p, '2026-11-07'); assert.equal(p.planned, undefined, 'an empty list is removed');
});

test('a planned date that is already stamped drops out; weekly and planned lessons merge in order', () => {
  const q = mk({ total: 5, expires: '' }); C.addPlanned(q, '2026-11-03'); C.addStamp(q, '2026-11-03');
  assert.deepEqual(C.upcoming(q, '2026-11-01', 14), []);
  const w = sched(); C.addPlanned(w, '2026-11-05');
  /* Mon 11-02 and Wed 11-04 from the weekly pattern, Thu 11-05 added by hand; sched() has 3 lessons left */
  assert.deepEqual(C.upcoming(w, '2026-11-01', 14).map(e => e.date + (e.planned ? '*' : '')), ['2026-11-02', '2026-11-04', '2026-11-05*']);
});

test('skipPlanned removes an added lesson and skips a weekly one', () => {
  const p = sched(); C.addPlanned(p, '2026-11-05');
  assert.equal(C.skipPlanned(p, '2026-11-05'), false); assert.equal(p.planned, undefined);
  assert.equal(C.skipPlanned(p, '2026-11-02'), true); assert.deepEqual(p.schedule.skip, ['2026-11-02']);
});

test('groupByStudent clusters packs by name and totals what is left on open packs', () => {
  const a = mk({ id: 'a', student: 'Mina', total: 4 }), b = mk({ id: 'b', student: ' mina ', total: 2 }), c = mk({ id: 'c', student: 'Joon', total: 3, expires: '2026-01-01' });
  const g = C.groupByStudent([a, c, b], '2026-11-05');
  assert.deepEqual(g.map(x => x.student), ['Mina', 'Joon']);
  assert.deepEqual(g[0].packs.map(p => p.id), ['a', 'b']);
  assert.deepEqual([g[0].left, g[1].left], [6, 0], 'expired packs add nothing to what is left');
});

test('logCsv lists every stamp with its pack currency and flags', () => {
  const p = mk({ student: 'Ann', currency: 'EUR', start: '2026-10-01' });
  C.addStamp(p, '2026-10-05', 'scales'); C.addStamp(p, '2026-10-06', '', 'noshow'); C.addStamp(p, '2026-10-07', '', '', true);
  const lines = C.logCsv([p]).split('\n');
  assert.equal(lines[0], 'student,date,kind,make_up,note,pack_start,currency');
  assert.equal(lines[1], 'Ann,2026-10-05,lesson,,scales,2026-10-01,EUR');
  assert.equal(lines[2], 'Ann,2026-10-06,noshow,,,2026-10-01,EUR');
  assert.equal(lines[3], 'Ann,2026-10-07,lesson,yes,,2026-10-01,EUR');
  assert.equal(C.logCsv([]).split('\n').length, 1);
});

test('plannedProblem gives the reason a date cannot be added', () => {
  const q = mk({ expires: '2026-12-31' });
  assert.equal(C.plannedProblem(q, 'soon'), 'bad');
  assert.equal(C.plannedProblem(q, '2026-09-01'), 'range', 'before the pack starts');
  assert.equal(C.plannedProblem(q, '2027-01-02'), 'range', 'after the pack expires');
  C.addStamp(q, '2026-11-02'); assert.equal(C.plannedProblem(q, '2026-11-02'), 'taken');
  C.addPlanned(q, '2026-11-20'); assert.equal(C.plannedProblem(q, '2026-11-20'), 'dup');
  assert.equal(C.plannedProblem(q, '2026-11-21'), '');
  C.setClosures(['2026-11-21']);
  try { assert.equal(C.plannedProblem(q, '2026-11-21'), 'closed'); assert.equal(C.addPlanned(q, '2026-11-21'), false); }
  finally { C.setClosures([]); }
});

test('added lessons respect class closures, and the weekly pattern still applies', () => {
  const w = sched(); C.addPlanned(w, '2026-11-05');
  C.setClosures(['2026-11-05', '2026-11-04']);
  try { assert.deepEqual(C.upcoming(w, '2026-11-01', 14).map(e => e.date), ['2026-11-02', '2026-11-09', '2026-11-11']); }
  finally { C.setClosures([]); }
});

test('mergePacks carries planned lessons from the other device without duplicates', () => {
  const a = mk({ id: 'a', planned: ['2026-11-20'] }), b = mk({ id: 'a', planned: ['2026-11-20', '2026-11-25'] });
  const r = C.mergePacks([a], [b]);
  assert.deepEqual(r.packs[0].planned, ['2026-11-20', '2026-11-25']); assert.equal(r.merged, 1);
});

test('cleanBackup repairs closures, waitlist and packs of a backup or saved state', () => {
  const o = C.cleanBackup({ packs: [mk({ id: 'k' })], closures: ['2026-12-25', 'x'], waitlist: [{ name: 'Ana' }, { name: '' }, null] });
  assert.deepEqual(o.closures, ['2026-12-25']); assert.deepEqual(o.waitlist.map(w => w.name), ['Ana']); assert.equal(o.packs.length, 1);
  const e = C.cleanBackup({ packs: 'nope', closures: 'x', waitlist: {} });
  assert.deepEqual([e.packs, e.closures, e.waitlist], [[], [], []]);
});

test('clonePack starts a fresh pack with the same terms, weekly days and ink', () => {
  const p = sched({ price: 300 }); C.addStamp(p, '2026-11-02'); C.setInk(p, 2);
  const c = C.clonePack(p, '2026-11-10', 'new1');
  assert.equal(c.id, 'new1'); assert.equal(c.total, 3); assert.equal(c.price, 300); assert.equal(c.start, '2026-11-10');
  assert.deepEqual(c.stamps, []); assert.deepEqual(c.schedule, { days: [1, 3], time: '18:30' }); assert.equal(c.ink, 2);
  assert.equal(c.expires, C.addMonths('2026-11-10', 2));
  assert.equal(p.stamps.length, 1, 'the original is untouched');
});

test('i18n placeholders match English in every language', () => {
  const I = require('../app/i18n.js'), ph = (s) => (String(s).match(/\{\w+\}/g) || []).slice().sort().join(' ');
  for (const k of Object.keys(I.L.en)) for (const l of I.langs) assert.equal(ph(I.L[l][k]), ph(I.L.en[k]), `${l}.${k} placeholders`);
});

test('cleanPacks keeps good planned dates only', () => {
  assert.deepEqual(C.cleanPacks([mk({ id: 'z', planned: ['2026-11-03', 'nope', '2026-11-03'] })])[0].planned, ['2026-11-03']);
  assert.equal(C.cleanPacks([mk({ id: 'y', planned: 'x' })])[0].planned, undefined);
});
