import * as L from "./logic.js";
import * as I from "./i18n.js";
import { CONFIG, checkoutLive } from "./config.js";
import * as LS from "./license.js";
import { initWorkspace } from "./workspace.js";
import { ensureSchema } from "./storage.js";
import { createAuth, localBackend } from "./auth.js";
import { initAccount } from "./account.js";
import { safeLink, shareUrl } from "./share.js";
import * as FX from "./fx.js";
import * as CL from "./clients.js";
import * as CAT from "./catalog.js";
import * as CD from "./cloud-data.js";

// The account layer is wired here only; swap localBackend for a Supabase backend without changing account.js.
const auth = createAuth(localBackend(localStorage));

// Optional cloud login + backup (Supabase). Off unless config.js has a project URL and key; the app never depends on it.
const SYNCED = new Set(CD.SYNC_KEYS);
const cloud = globalThis.CloudSync?.create({
  url: CONFIG.supabaseUrl, anonKey: CONFIG.supabaseKey, app: "quickbill", storage: localStorage, device: (navigator.platform || "web").slice(0, 60),
  snapshot: () => CD.snapshot(localStorage),
  isEmpty: (snap) => CD.isEmpty(snap),
  apply: (snap) => { if (CD.apply(localStorage, snap)) location.reload(); },
  onResult: (r) => { if (r.status === "pushed") toast(globalThis.CloudI18n.t(I.getLang(), "pushed")); },
});

const $ = (s) => document.querySelector(s);
const store = {
  get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); if (SYNCED.has(k)) cloud?.changed(); return true; } catch { $("#store-warn").hidden = false; return false; } },
  del(k) { try { localStorage.removeItem(k); } catch {} },
};
try { ensureSchema(localStorage); } catch {}
// A stored value that is not a list would crash every screen; keep a copy of it and start from an empty list instead.
const rawInvoices = store.get("qb.invoices", []);
if (!Array.isArray(rawInvoices)) { try { localStorage.setItem("qb.invoices.bad", JSON.stringify(rawInvoices)); } catch {} }
let invoices = Array.isArray(rawInvoices) ? rawInvoices : [];
let filters = { q: "", f: "all" };
let selected = new Set(); // ids ticked in the list, for bulk status changes (not saved)
let shownIds = []; // ids currently visible in the list; bulk changes only touch these
try { localStorage.setItem("qb.probe", "1"); localStorage.removeItem("qb.probe"); } catch { document.addEventListener("DOMContentLoaded", () => ($("#store-warn").hidden = false)); }
let license = store.get("qb.license", "");
let logo = store.get("qb.logo", "");
let editing = null; // the document open in the form
let licRec = store.get("qb.licsrv", null); // set when the key was accepted by the license server
let srvMode = store.get("qb.srvmode", false); // the server checks keys; offline-format keys are then not accepted
const isPro = () => LS.proStatus(license, licRec, srvMode);
const today = () => new Date().toISOString().slice(0, 10);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const persist = () => store.set("qb.invoices", invoices);
const money = (n, cur) => L.formatMoney(n, cur, I.locale());

let toastTimer;
function toast(msg) {
  const el = $("#toast");
  el.textContent = msg;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (el.hidden = true), 3500);
}

function renderList() {
  document.body.classList.toggle("is-pro", isPro());
  $("#plan").textContent = isPro() ? "Pro" : `Free ${invoices.length}/${L.FREE_LIMIT}`;
  $("#btn-upgrade").hidden = isPro();
  $("#empty").hidden = invoices.length > 0;
  $("#clients").innerHTML = [...new Set(invoices.map((i) => i.client).filter(Boolean))]
    .map((c) => `<option value="${esc(c)}">`).join("");
  $("#filters").hidden = invoices.length < 4;
  const shown = invoices.length < 4 ? invoices : L.filterInvoices(invoices, filters, today());
  shownIds = shown.map((i) => i.id);
  $("#nomatch").hidden = !(invoices.length && !shown.length);
  $("#list").innerHTML = shown.map((i) => {
    const q = L.isQuote(i), bal = L.balanceOf(i);
    return `<div class="cardrow"><span class="selbox"><input type="checkbox" data-sel="${esc(i.id)}"${selected.has(i.id) ? " checked" : ""} aria-label="${esc(I.t("selAria"))} ${esc(i.number)}"></span><div class="card" data-id="${esc(i.id)}" role="button" tabindex="0"><div><b>${esc(i.number)}</b> · ${esc(i.client)}<br>
      <span class="muted">${q ? I.t("validUntil") : I.t("dueWord")} ${esc(I.formatDate(i.dueDate))} · ${I.t(i.status)}${i.recur ? " · " + I.t(i.recur) : ""}</span>
      ${L.overdue(i) ? `<span class="late"> ${I.t("overdue")}</span>` : ""}</div>
      <div class="r"><b>${money(L.totalOf(i), i.currency)}</b>${L.withheldOf(i) > 0 ? `<br><span class="muted">${I.t("payableL")} ${money(L.payableOf(i), i.currency)}</span>` : ""}${!q && i.paid > 0 && bal > 0 ? `<br><span class="muted">${I.t("balance")} ${money(bal, i.currency)}</span>` : ""}</div></div></div>`;
  }).join("");
  renderDash();
  renderAgeing();
  renderActivity();
  renderBulk();
}

function renderDash() {
  const sums = L.summarize(invoices, today());
  $("#dash").innerHTML = sums.map((x) => `<div class="pc"><b>${esc(x.currency)}</b>
    <p>${I.t("dashOutstanding")}: <b>${money(x.outstanding, x.currency)}</b></p>
    <p class="${x.overdue ? "late" : ""}">${I.t("dashOverdue")}: ${money(x.overdue, x.currency)}</p>
    <p>${I.t("dashCollected")}: ${money(x.collected, x.currency)}</p></div>`).join("");
  renderFx(sums);
  const rows = L.byClient(invoices);
  $("#clientsum").innerHTML = !rows.length ? "" : isPro()
    ? `<details open><summary>${I.t("byClient")}</summary><table class="mini">${rows.map((r) =>
        `<tr><td>${esc(r.client)}</td><td class="r">${r.count}× ${I.t("billed")} ${money(r.billed, r.currency)}</td><td class="r">${I.t("balance")} ${money(r.balance, r.currency)}</td><td class="r"><button type="button" data-stmt="${esc(r.client)}" data-cur="${esc(r.currency)}">${I.t("stmtBtn")}</button></td></tr>`).join("")}</table></details>`
    : `<p class="muted">${I.t("byClientPro")}</p>`;
}

// Combined total across currencies, using rates typed in here. The inputs are only rebuilt when the set of
// currencies or the base changes, so typing a rate never loses focus.
let catalog = CAT.cleanCatalog(store.get("qb.catalog", {})); // items billed before, offered while typing a description
let profiles = store.get("qb.clients", {}); // remembered terms per client, learned when an invoice is saved
let fx = FX.cleanRates(store.get("qb.fx", null));
function renderFx(sums) {
  const box = $("#fx");
  if (sums.length < 2 || !isPro()) { box.innerHTML = ""; box.dataset.sig = ""; return; }
  const curs = [...new Set(sums.map((s) => s.currency).concat(fx.base))].sort();
  const sig = curs.join() + "|" + fx.base + "|" + I.getLang();
  if (box.dataset.sig !== sig) {
    box.dataset.sig = sig;
    box.innerHTML = `<details open><summary>${I.t("fxHead")}</summary>
      <p class="muted">${I.t("fxNote")}</p>
      <label class="inline"><span>${I.t("fxBase")}</span><select id="fx-base">${curs.map((c) => `<option${c === fx.base ? " selected" : ""}>${esc(c)}</option>`).join("")}</select></label>
      <div class="fxrates">${curs.filter((c) => c !== fx.base).map((c) => `<label class="inline"><span>${esc(I.t("fxRate", { cur: c }))}</span>
        <input data-fx="${esc(c)}" inputmode="decimal" value="${esc(fx.rates[c] ?? "")}" aria-label="${esc(I.t("fxRate", { cur: c }))} ${esc(fx.base)}"> ${esc(fx.base)}</label>`).join("")}</div>
      <div id="fx-out" class="pc" aria-live="polite"></div></details>`;
    $("#fx-base").onchange = (e) => { fx = FX.cleanRates({ base: e.target.value, rates: fx.rates }); store.set("qb.fx", fx); renderFx(L.summarize(invoices, today())); };
    box.querySelectorAll("[data-fx]").forEach((el) => (el.oninput = () => {
      const r = { ...fx.rates };
      const v = FX.parseRate(el.value);
      if (v) r[el.dataset.fx] = v; else delete r[el.dataset.fx];
      fx = FX.cleanRates({ base: fx.base, rates: r });
      store.set("qb.fx", fx);
      renderFx(L.summarize(invoices, today()));
    }));
  }
  const c = FX.combine(sums, fx);
  $("#fx-out").innerHTML = `<p>${I.t("dashOutstanding")}: <b>${money(c.outstanding, c.currency)}</b></p>
    <p class="${c.overdue ? "late" : ""}">${I.t("dashOverdue")}: ${money(c.overdue, c.currency)}</p>
    <p>${I.t("dashCollected")}: ${money(c.collected, c.currency)}</p>
    ${c.missing.length ? `<p class="muted">${esc(I.t("fxMissing", { list: c.missing.join(", ") }))}</p>` : ""}`;
}

function renderAgeing() {
  const rows = L.ageing(invoices, today());
  $("#ageing").innerHTML = !rows.length || !isPro() ? "" : `<details open><summary>${I.t("ageingTitle")}</summary><table class="mini">
    <tr><th></th><th class="r">${I.t("d30")}</th><th class="r">${I.t("d60")}</th><th class="r">${I.t("d90")}</th><th class="r">${I.t("older")}</th></tr>
    ${rows.map((r) => `<tr><td>${esc(r.currency)}</td>${["d30", "d60", "d90", "older"].map((k) => `<td class="r">${money(r[k], r.currency)}</td>`).join("")}</tr>`).join("")}</table></details>`;
}

// Recent payments and issues, newest first. Derived from the saved invoices, so nothing extra is stored.
function renderActivity() {
  const rows = L.recentActivity(invoices);
  $("#activity").innerHTML = !rows.length ? "" : `<details open><summary>${I.t("actHead")}</summary><table class="mini">${rows.map((r) => {
    const key = r.kind === "payment" ? "actPaid" : r.kind === "quote" ? "actQuote" : "actIssued";
    return `<tr><td class="muted">${esc(I.formatDate(r.date))}</td><td>${esc(I.t(key, { n: r.number, amount: money(r.amount, r.currency) }))}</td><td class="r">${esc(r.client)}</td></tr>`;
  }).join("")}</table></details>`;
}
// Keeps the bulk bar in step with the ticked boxes; forgets ids that no longer exist.
function renderBulk() {
  const known = new Set(invoices.map((i) => i.id));
  for (const id of [...selected]) if (!known.has(id)) selected.delete(id);
  // Only rows on screen count: a ticked row hidden by the search or filter is not changed by Apply.
  const n = activeSel().length;
  $("#bulk").hidden = !n;
  $("#bulk-n").textContent = I.t("bulkCount", { n });
}
function activeSel() { return [...selected].filter((id) => shownIds.includes(id)); }

// ---- time tracker ----
let entries = Array.isArray(store.get("qb.time", [])) ? store.get("qb.time", []) : [];
let running = store.get("qb.timer", null); // { client, desc, at }
let rate = store.get("qb.rate", 0);
let tick;
const fmtClock = (secs) => [Math.floor(secs / 3600), Math.floor(secs / 60) % 60, secs % 60].map((n) => String(n).padStart(2, "0")).join(":");
function renderTime() {
  $("#t-toggle").textContent = I.t(running ? "stop" : "start");
  $("#t-rate").value = rate;
  const groups = L.unbilledByClient(entries);
  $("#t-list").innerHTML = groups.length ? groups.map((g) =>
    `<button type="button" data-pro data-bill="${esc(g.client)}">${esc(I.t("billTime", { client: g.client, h: L.hoursOf(g.secs) }))}</button>`).join(" ")
    : `<p class="muted">${I.t("timeEmpty")}</p>`;
  clearInterval(tick);
  const clock = () => ($("#t-clock").textContent = running ? fmtClock(Math.floor((Date.now() - running.at) / 1000)) : "");
  clock();
  if (running) tick = setInterval(clock, 1000);
}
$("#t-toggle").onclick = () => {
  if (!running) {
    const client = $("#t-client").value.trim();
    if (!client) return $("#t-client").focus();
    running = { client, desc: $("#t-desc").value.trim(), at: Date.now() };
    store.set("qb.timer", running);
  } else {
    const secs = Math.max(1, Math.round((Date.now() - running.at) / 1000));
    entries.push({ id: crypto.randomUUID(), client: running.client, desc: running.desc, secs, billed: false });
    store.set("qb.time", entries);
    running = null;
    store.del("qb.timer");
  }
  renderTime();
};
// A typed negative rate would bill negative hours; clamp it and show the value that is actually used.
$("#t-rate").onchange = (e) => { rate = Math.max(0, Number(e.target.value) || 0); e.target.value = rate; store.set("qb.rate", rate); };
$("#t-list").onclick = (e) => {
  const b = e.target.closest("[data-bill]");
  if (!b) return;
  if (!isPro()) return openUpgrade(I.t("timePro"));
  if (!L.canSave(invoices, true, null)) return;
  const client = b.dataset.bill;
  const items = L.timeItems(entries, client, rate);
  const n = items.length;
  const doc = newDoc("invoice", { client, items });
  entries = entries.map((x) => (x.client === client && !x.billed ? { ...x, billed: true } : x));
  store.set("qb.time", entries);
  renderTime();
  toast(I.t("timeBilled", { n, num: doc.number }));
};

function itemRow(it = { desc: "", qty: 1, price: 0 }) {
  const d = document.createElement("div");
  d.className = "item";
  if (it.lateFee) d.dataset.fee = "1";
  d.innerHTML = `<input placeholder="${esc(I.t("desc"))}" value="${esc(it.desc)}" data-k="desc" list="catalog" autocomplete="off">
    <input type="number" min="0" step="any" value="${esc(it.qty)}" data-k="qty" aria-label="${esc(I.t("qty"))}">
    <input type="number" min="0" step="any" value="${esc(it.price)}" data-k="price" aria-label="${esc(I.t("price"))}">
    <button type="button" class="danger" aria-label="Remove item">×</button>`;
  d.querySelector("button").onclick = () => { d.remove(); renderPreview(); };
  d.querySelector('[data-k="desc"]').addEventListener("change", (e) => {
    const price = d.querySelector('[data-k="price"]');
    const known = isPro() ? CAT.priceFor(catalog, e.target.value) : null;
    if (known != null && !Number(price.value)) { price.value = known; renderPreview(); }
  });
  return d;
}

function readForm() {
  const f = new FormData($("#form"));
  const inv = { ...editing, ...Object.fromEntries(f) };
  delete inv[""];
  inv.taxRate = Number(inv.taxRate) || 0;
  inv.discount = Number(inv.discount) || 0;
  inv.withholdingRate = Math.min(Math.max(Number(inv.withholdingRate) || 0, 0), L.MAX_WITHHOLDING);
  inv.taxId = String(inv.taxId || "").trim().slice(0, 40);
  inv.recur = inv.recur || "";
  inv.paid = Number(inv.paid) || 0;
  inv.lateFeePct = Number(inv.lateFeePct) || 0;
  inv.items = [...document.querySelectorAll("#items .item")].map((r) => ({
    desc: r.querySelector('[data-k="desc"]').value,
    qty: Number(r.querySelector('[data-k="qty"]').value) || 0,
    price: Number(r.querySelector('[data-k="price"]').value) || 0,
    ...(r.dataset.fee ? { lateFee: true } : {}),
  }));
  return inv;
}

function renderPreview() {
  if (!editing) return;
  const i = readForm();
  const t = L.calcTotals(i.items, i.taxRate, i.discount, i.withholdingRate);
  const m = (n) => money(n, i.currency);
  const habit = !L.isQuote(i) && i.client ? L.clientHabits(invoices.filter((x) => x.id !== i.id))[L.habitKey(i.client)] : null;
  $("#client-hint").textContent = habit ? `${I.t("insCashHistory", { d: habit.avgDays })} · ${I.t("insPayOnTime")} ${habit.onTimePct}% · ${I.t("habitFrom", { n: habit.count })}` : "";
  const late = L.overdue({ ...i, paid: L.isQuote(i) ? 0 : i.paid }, today());
  $("#btn-latefee").hidden = !late;
  $("#btn-remind").hidden = !late;
  $("#btn-share").hidden = !i.number;
  $("#btn-email").hidden = !CL.validEmail(i.clientEmail);
  // Sticky strip at the top of the editor: totals always in view, plus the late fee the button would add today.
  const fee = !L.isQuote(i) && late ? L.lateFeeAmount({ ...i, items: i.items.filter((x) => !x.lateFee) }, today(), i.lateFeePct) : 0;
  $("#sticky").innerHTML = `<span>${I.t("total")} <b>${m(t.total)}</b></span>${L.isQuote(i) ? "" : `<span>${I.t("balance")} <b>${m(L.balanceOf(i))}</b></span>`}${fee ? `<span class="late">${I.t("lateFeeNow")} ${m(fee)}</span>` : ""}`;
  const showLogo = logo && isPro();
  $("#btn-logo-rm").hidden = !logo;
  $("#preview").innerHTML = `${showLogo ? `<img class="logo" alt="" src="${esc(logo)}">` : ""}<h2>${I.t(L.isQuote(i) ? "quote" : "invoice")} ${esc(i.number)}</h2>
    <p><b>${I.t("fromL")}:</b> ${esc(i.from)}${i.taxId ? ` (${esc(I.t("taxIdShort"))} ${esc(i.taxId)})` : ""}<br><b>${I.t("toL")}:</b> ${esc(i.client)}<br>
    ${I.t("issuedL")} ${esc(I.formatDate(i.issueDate))} · ${I.t(L.isQuote(i) ? "validUntil" : "dueL")} ${esc(I.formatDate(i.dueDate))}${i.convertedFrom ? `<br><small>${esc(I.t("quoteOf", { n: i.convertedFrom }))}</small>` : ""}</p>
    <table><tr><th>${I.t("desc")}</th><th class="r">${I.t("qty")}</th><th class="r">${I.t("price")}</th><th class="r">${I.t("total")}</th></tr>
    ${i.items.map((x) => `<tr><td>${esc(x.desc)}</td><td class="r">${x.qty}</td><td class="r">${m(x.price)}</td><td class="r">${m(x.qty * x.price)}</td></tr>`).join("")}</table>
    <p class="r">${I.t("subtotal")} ${m(t.subtotal)}<br>${t.discount ? `${I.t("discountL")} −${m(t.discount)}<br>` : ""}${I.t("taxL")} ${m(t.tax)}<br><b>${I.t("total")} ${m(t.total)}</b>${t.withholding ? `<br>${I.t("whL")} (${i.withholdingRate}%) −${m(t.withholding)}<br><b>${I.t("payableL")} ${m(t.payable)}</b>` : ""}${!L.isQuote(i) && i.paid > 0 ? `<br>− ${m(Math.min(i.paid, t.payable))}<br><b>${I.t("balance")} ${m(L.balanceOf(i))}</b>` : ""}</p>
    <p>${esc(i.notes)}</p>${i.terms ? `<p class="terms"><b>${I.t("termsL")}</b><br>${esc(i.terms).replace(/\n/g, "<br>")}</p>` : ""}${i.payinfo ? `<p><b>${I.t("payinfo").replace(/\s*[（(].*$/, "")}</b><br>${esc(i.payinfo).replace(/\n/g, "<br>")}</p>` : ""}
    ${isPro() ? "" : `<p class="wm">${I.t("watermark")}</p>`}`;
}

function renderPayLog() {
  const q = L.isQuote(editing);
  $("#pay-log").hidden = q;
  if (q) return;
  const list = editing.payments || [];
  $("#pay-list").innerHTML = list.length
    ? `<table class="mini">${list.map((p, k) => `<tr><td>${esc(I.formatDate(p.date))}</td><td class="r">${money(p.amount, editing.currency)}</td>
        <td class="r"><button type="button" class="danger" data-rm="${k}" aria-label="${esc(I.t("payRemove"))}">×</button></td></tr>`).join("")}</table><p class="muted">${I.t("payNote")}</p>`
    : `<p class="muted">${I.t("payNone")}</p>`;
}
function applyPaid(next) {
  editing = next;
  $("#form").elements.paid.value = next.paid;
  $("#form").elements.status.value = next.status;
  renderPayLog();
  renderPreview();
}
$("#pay-add").onclick = () => {
  const cur = L.settle(readForm());
  const date = $("#pay-date").value || today(), amt = Number($("#pay-amt").value);
  const next = L.recordPayment(cur, date, amt);
  $("#pay-err").textContent = next === cur ? I.t("payBadAmt") : "";
  if (next === cur) return;
  $("#pay-amt").value = "";
  applyPaid(next);
};
$("#pay-list").onclick = (e) => {
  const b = e.target.closest("[data-rm]");
  if (b) applyPaid(L.removePayment(L.settle(readForm()), Number(b.dataset.rm)));
};
// Fills the amount with what is still owed; the payment is only recorded by "Record payment", so nothing is booked by accident.
$("#pay-full").onclick = () => {
  const bal = L.balanceOf(L.settle(readForm()));
  $("#pay-err").textContent = bal > 0 ? "" : I.t("payBadAmt");
  $("#pay-amt").value = bal > 0 ? String(bal) : "";
  if (bal > 0) $("#pay-amt").focus();
};
$("#taxpresets").innerHTML = L.TAX_PRESETS.map((r) => `<option value="${r}">`).join("");

function openEditor(inv) {
  editing = inv;
  $("#catalog").innerHTML = CAT.suggestions(catalog).map((x) => `<option value="${esc(x.desc)}"></option>`).join("");
  for (const el of $("#form").elements) if (el.name) el.value = inv[el.name] ?? "";
  $("#items").replaceChildren(...inv.items.map(itemRow));
  const q = L.isQuote(inv), saved = invoices.some((x) => x.id === inv.id);
  $("#btn-delete").hidden = !saved;
  $("#btn-convert").hidden = !(q && saved);
  $("#paid-wrap").hidden = q;
  $("#pay-date").value = today();
  $("#pay-amt").value = "";
  $("#pay-err").textContent = "";
  renderPayLog();
  $("#due-lbl").textContent = I.t(q ? "validUntil" : "due");
  for (const o of $("#form").elements.status.options) o.hidden = o.disabled = q ? o.value === "paid" : o.value === "accepted";
  $("#list-view").hidden = true;
  $("#new-row").hidden = true;
  $("#edit-view").hidden = false;
  renderPreview();
}
function closeEditor() {
  editing = null;
  $("#edit-view").hidden = true;
  $("#new-row").hidden = false;
  $("#list-view").hidden = false;
  renderList();
}

function openUpgrade(reason = "") {
  // Until a real checkout link is set, don't send people to the placeholder page.
  const live = checkoutLive();
  $("#price").textContent = CONFIG.price;
  $("#buy").href = CONFIG.checkoutUrl;
  $("#buy").hidden = !live;
  $("#price").hidden = !live;
  $("#buy-soon").hidden = live;
  $("#lic-msg").textContent = reason;
  $("#lic-msg").hidden = !reason;
  $("#dlg").showModal();
}
const limitMsg = () => I.t("freeLimit", { n: L.FREE_LIMIT });

function runRecurring() {
  if (!isPro()) return;
  const r = L.runRecurring(invoices, today(), () => crypto.randomUUID());
  if (r.created) {
    invoices = r.invoices;
    persist();
    toast(I.t("generated", { n: r.created }));
  }
}

function fullRender() {
  I.applyI18n();
  document.title = "QuickBill";
  renderList();
  renderPreview();
  renderTime();
  ws?.render();
}

// ---- events ----
function newDoc(type, extra = {}) {
  if (!L.canSave(invoices, isPro(), null)) return openUpgrade(limitMsg());
  const last = invoices[0];
  const doc = {
    id: crypto.randomUUID(), type, number: L.nextNumber(invoices, type), from: last?.from ?? "", taxId: last?.taxId ?? "", client: "",
    currency: last?.currency ?? I.LANGS[I.getLang()].currency, issueDate: today(), dueDate: L.addDays(today(), type === "quote" ? 30 : 14),
    taxRate: last?.taxRate ?? 0, withholdingRate: last?.withholdingRate ?? 0, discount: 0, paid: 0, payments: [], status: "draft", notes: "", payinfo: last?.payinfo ?? "", payLink: last?.payLink ?? "", terms: type === "quote" ? "" : (last?.terms ?? I.t("termsDefault")), clientEmail: "", recur: "", nextRun: "",
    items: [{ desc: "", qty: 1, price: 0 }], lateFeePct: last?.lateFeePct ?? 0, ...extra,
  };
  openEditor(doc);
  return doc;
}
$("#btn-new").onclick = () => newDoc("invoice");
$("#btn-new-quote").onclick = () => newDoc("quote");
$("#btn-convert").onclick = () => {
  if (!L.canSave(invoices, isPro(), null)) return openUpgrade(limitMsg());
  const q = readForm();
  const inv = L.convertQuote(q, invoices, () => crypto.randomUUID(), today());
  const i = invoices.findIndex((x) => x.id === q.id);
  invoices[i >= 0 ? i : invoices.length] = { ...q, status: "accepted" };
  invoices.unshift(inv);
  persist();
  closeEditor();
  toast(I.t("converted", { n: inv.number }));
  openEditor(structuredClone(inv));
};
$("#btn-latefee").onclick = () => {
  const inv = readForm();
  const next = L.applyLateFee(inv, today(), inv.lateFeePct, I.t("feeItem"));
  editing = next;
  $("#items").replaceChildren(...next.items.map(itemRow));
  renderPreview();
};
// The link opens a read-only page for the client; the invoice travels inside the link, nothing is uploaded.
function clientLink() {
  const inv = L.settle(readForm());
  if (inv.payLink && !safeLink(inv.payLink)) { toast(I.t("payLinkBad")); $("#form").elements.payLink.focus(); return null; }
  return shareUrl(new URL("view.html", location.href).href, { ...inv, payLink: safeLink(inv.payLink) }, I.getLang());
}
$("#btn-share").onclick = async () => {
  if (!isPro()) return openUpgrade(I.t("sharePro"));
  const link = clientLink();
  if (!link) return;
  try { await navigator.clipboard.writeText(link.url); toast(I.t(link.long ? "shareLong" : "shareCopied", { n: link.length })); }
  catch { window.prompt(I.t("shareLink"), link.url); }
};
$("#btn-email").onclick = () => {
  if (!isPro()) return openUpgrade(I.t("sharePro"));
  const inv = L.settle(readForm());
  const quote = L.isQuote(inv);
  const vars = { client: inv.client, number: inv.number, amount: money(L.balanceOf(inv) || L.totalOf(inv), inv.currency), date: I.formatDate(inv.dueDate), from: inv.from };
  let body = I.t(quote ? "emailQuoteBody" : L.overdue(inv, today()) ? "reminderText" : "emailBody", vars);
  const link = !inv.payLink || safeLink(inv.payLink) ? clientLink() : null;
  if (link && !link.long) body += `\n\n${I.t("reminderLink", { url: link.url })}`;
  const url = CL.mailtoUrl(inv.clientEmail, I.t(quote ? "quoteSubject" : "emailSubject", vars), body);
  if (url) location.href = url;
};
$("#form").elements.client.addEventListener("change", () => {
  // Only for a brand-new invoice: a saved one keeps the terms it was written with.
  const p = profiles[CL.keyOf($("#form").elements.client.value)];
  if (!p || !editing || invoices.some((x) => x.id === editing.id) || !isPro()) return;
  const next = CL.applyDefaults(readForm(), p);
  for (const k of ["currency", "taxRate", "withholdingRate", "dueDate", "clientEmail", "payinfo", "payLink"]) $("#form").elements[k].value = next[k] ?? "";
  renderPreview();
  toast(I.t("clientApplied", { client: next.client }));
});
$("#btn-remind").onclick = async () => {
  const inv = readForm();
  let text = I.t("reminderText", { client: inv.client, number: inv.number, amount: money(L.balanceOf(inv), inv.currency), date: I.formatDate(inv.dueDate), from: inv.from });
  const link = isPro() && (!inv.payLink || safeLink(inv.payLink)) ? clientLink() : null;
  if (link && !link.long) text += `\n\n${I.t("reminderLink", { url: link.url })}`;
  try { await navigator.clipboard.writeText(text); toast(I.t("reminderCopied")); }
  catch { window.prompt(I.t("reminder"), text); }
};
// The new row takes focus, so keyboard users can type the description straight away.
$("#btn-add").onclick = () => {
  const row = itemRow();
  $("#items").append(row);
  row.querySelector('[data-k="desc"]').focus();
};
$("#form").addEventListener("input", renderPreview);
$("#form").onsubmit = (e) => {
  e.preventDefault();
  const inv = L.settle(readForm());
  if (inv.payLink && !safeLink(inv.payLink)) { toast(I.t("payLinkBad")); return $("#form").elements.payLink.focus(); }
  if (inv.payLink) inv.payLink = safeLink(inv.payLink);
  if (inv.recur && !isPro()) { $("#form").elements.recur.value = ""; renderPreview(); return openUpgrade(I.t("recurPro")); }
  if (!L.canSave(invoices, isPro(), inv.id)) return openUpgrade(limitMsg());
  if (isPro() && inv.clientEmail && !CL.validEmail(inv.clientEmail)) inv.clientEmail = "";
  if (isPro()) {
    profiles = CL.learn(profiles, inv); store.set("qb.clients", profiles);
    if (!L.isQuote(inv)) { catalog = CAT.learnItems(catalog, inv.items); store.set("qb.catalog", catalog); }
  }
  const prev = invoices.find((x) => x.id === inv.id);
  if (!inv.recur) inv.nextRun = "";
  else if (!inv.nextRun || prev?.recur !== inv.recur) inv.nextRun = L.addPeriod(inv.issueDate, inv.recur);
  const idx = invoices.findIndex((x) => x.id === inv.id);
  if (idx >= 0) invoices[idx] = inv; else invoices.unshift(inv);
  persist();
  runRecurring();
  closeEditor();
};
$("#btn-back").onclick = closeEditor;
$("#btn-print").onclick = () => window.print();
$("#btn-delete").onclick = () => {
  if (!confirm(I.t("confirmDelete"))) return;
  invoices = invoices.filter((x) => x.id !== editing.id);
  persist();
  closeEditor();
};
// A tick box inside a card selects the row for bulk changes; it must not open the card.
const openCard = (e) => {
  if (e.target.closest("input")) return;
  const c = e.target.closest(".card");
  if (c) openEditor(structuredClone(invoices.find((x) => x.id === c.dataset.id)));
};
$("#list").onclick = openCard;
$("#list").onkeydown = (e) => { if (!e.target.closest("input") && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); openCard(e); } };
$("#list").onchange = (e) => {
  const box = e.target.closest("[data-sel]");
  if (!box) return;
  if (box.checked) selected.add(box.dataset.sel); else selected.delete(box.dataset.sel);
  renderBulk();
};
$("#bulk-clear").onclick = () => { selected.clear(); renderList(); };
$("#bulk-all").onclick = () => { for (const id of shownIds) selected.add(id); renderList(); };
$("#bulk-go").onclick = () => {
  const before = invoices;
  invoices = L.bulkStatus(invoices, activeSel(), $("#bulk-st").value);
  const n = invoices.filter((x, k) => x !== before[k]).length;
  selected.clear();
  persist();
  renderList();
  toast(I.t("bulkDone", { n }));
};
$("#empty-new").onclick = () => $("#btn-new").click();
$("#q").oninput = (e) => { filters.q = e.target.value; renderList(); };
$("#f").onchange = (e) => { filters.f = e.target.value; renderList(); };
$("#btn-dup").onclick = () => {
  const src = readForm();
  const copy = newDoc(src.type, {
    from: src.from, taxId: src.taxId, client: src.client, currency: src.currency, taxRate: src.taxRate, withholdingRate: src.withholdingRate, discount: src.discount,
    notes: src.notes, terms: src.terms, payinfo: src.payinfo, payLink: src.payLink, clientEmail: src.clientEmail, lateFeePct: src.lateFeePct,
    items: src.items.filter((x) => !x.lateFee).map((x) => ({ ...x })),
  });
  if (copy) toast(I.t("dupNote"));
};
$("#btn-upgrade").onclick = () => openUpgrade();

function download(name, type, text) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([type === "text/csv" ? "\uFEFF" + text : text], { type }));
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
$("#btn-csv").onclick = () => {
  if (!isPro()) return openUpgrade(I.t("csvPro"));
  download("invoices.csv", "text/csv", L.toCSV(invoices));
};
$("#btn-backup").onclick = () => download("quickbill-backup.json", "application/json", JSON.stringify({ app: "quickbill", v: 2, invoices, logo, expenses: store.get("qb.expenses", []), clients: profiles, catalog }));
$("#btn-restore").onclick = () => $("#file-restore").click();
$("#file-restore").onchange = async (e) => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    if (data.app !== "quickbill" || !Array.isArray(data.invoices) || !data.invoices.every(L.validInvoice)) throw 0;
    if (!isPro() && data.invoices.length > L.FREE_LIMIT) return openUpgrade(limitMsg());
    // Backups from before expenses existed have no "expenses" key; those leave the current expenses alone.
    const hasExpenses = data.expenses !== undefined;
    if (hasExpenses && (!Array.isArray(data.expenses) || !data.expenses.every(L.validExpense))) throw 0;
    try { localStorage.setItem("qb.invoices.bak-restore", JSON.stringify(invoices)); } catch {}
    invoices = data.invoices;
    if (data.clients && typeof data.clients === "object" && !Array.isArray(data.clients)) {
      profiles = Object.fromEntries(Object.entries(data.clients).map(([k, v]) => [CL.keyOf(k), CL.cleanProfile(v)]).filter(([k]) => k));
      store.set("qb.clients", profiles);
    }
    if (data.catalog !== undefined) { catalog = CAT.cleanCatalog(data.catalog); store.set("qb.catalog", catalog); }
    if (hasExpenses) store.set("qb.expenses", data.expenses);
    if (typeof data.logo === "string" && data.logo.startsWith("data:image/")) { logo = data.logo; store.set("qb.logo", logo); }
    persist();
    renderList();
    toast(I.t("restoreOk", { n: invoices.length }));
  } catch { toast(I.t("restoreBad")); }
};

function shrinkImage(file, max = 240) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.max(1, Math.round(img.width * k));
      c.height = Math.max(1, Math.round(img.height * k));
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/png"));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("bad image")); };
    img.src = url;
  });
}
$("#logo-file").onchange = async (e) => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  if (!isPro()) return openUpgrade(I.t("logoPro"));
  try { logo = await shrinkImage(file); store.set("qb.logo", logo); renderPreview(); } catch { toast(I.t("restoreBad")); }
};
$("#btn-logo-rm").onclick = () => { logo = ""; store.del("qb.logo"); renderPreview(); };

const licFail = { network: "licNetwork", revoked: "licRevoked", unknown: "badKey" };
$("#dlg").addEventListener("close", async () => {
  if ($("#dlg").returnValue !== "ok") return;
  const k = $("#lic").value.trim();
  if (!k) return;
  toast(I.t("licChecking"));
  const r = await LS.activate(k, { fetchImpl: fetch.bind(window), api: CONFIG.licenseApi });
  if (!r.ok) return openUpgrade(I.t(licFail[r.reason] || "badKey"));
  license = k; store.set("qb.license", k);
  licRec = r.record; if (licRec) store.set("qb.licsrv", licRec); else store.del("qb.licsrv");
  if (r.server) { srvMode = true; store.set("qb.srvmode", true); }
  $("#toast").hidden = true;
  runRecurring(); renderList(); renderPreview();
});

// Ask the license server once per load whether it is switched on, and re-check a stored key about once a week.
// Being offline or having no server never removes Pro; only a clear "refunded/disabled" answer does.
if (/^https?:$/.test(location.protocol) && navigator.onLine !== false) (async () => {
  const m = await LS.serverMode(fetch.bind(window), CONFIG.licenseApi);
  if (m !== null && m !== srvMode) { srvMode = m; store.set("qb.srvmode", m); renderList(); renderPreview(); }
  if (licRec && LS.needsRecheck(licRec)) {
    const r = await LS.recheck(licRec, { fetchImpl: fetch.bind(window), api: CONFIG.licenseApi });
    if (r.keep) { licRec = r.record; store.set("qb.licsrv", licRec); }
    else { licRec = null; store.del("qb.licsrv"); toast(I.t("licLost")); renderList(); renderPreview(); }
  }
})();

let saved = null; try { saved = localStorage.getItem("qb.lang"); } catch {}
I.setLang(I.detectLang(saved));
I.langSelect($("#lang"), (l) => { I.setLang(l); try { localStorage.setItem("qb.lang", l); } catch {} fullRender(); });
runRecurring();
const ws = initWorkspace({
  store, toast, isPro, openUpgrade, download,
  getInvoices: () => invoices,
  getFrom: () => invoices.find((i) => i.from)?.from ?? "",
  createInvoice: (items, extra = {}) => newDoc("invoice", { items, ...extra }),
  createDoc: (type, extra = {}) => newDoc(type, extra),
});
fullRender();
renderTime();
const cloudPanel = cloud?.enabled() && globalThis.CloudPanel ? globalThis.CloudPanel.build({ cloud, lang: () => I.getLang() }) : null;
const account = initAccount({ auth, cloud, cloudPanel });
auth.init().then(() => account.paint()).catch(() => account.paint());
if (cloudPanel && cloud.user()) cloud.sync().then((r) => { if (r.status === "pulled") toast(globalThis.CloudI18n.t(I.getLang(), "pulled")); });
if ("serviceWorker" in navigator && location.protocol !== "file:") navigator.serviceWorker.register("sw.js").catch(() => {});

// Statement of account: a printable page per client, built on the device from saved invoices.
let stmtOpen = null;
function openStatement(client, currency) {
  const st = L.statement(invoices, client, currency, today());
  stmtOpen = st;
  const m = (n) => money(n, currency);
  const from = esc(invoices.find((x) => x.from)?.from || "");
  $("#stmt-doc").innerHTML = `<h2 id="stmt-title">${esc(I.t("stmtTitle"))}</h2>
    <p>${from ? `<b>${esc(I.t("fromL"))}:</b> ${from}<br>` : ""}<b>${esc(I.t("toL"))}:</b> ${esc(client)}<br><span class="sub">${esc(I.t("stmtAsOf", { d: I.formatDate(st.asOf) }))}</span></p>
    <table><thead><tr><th>${esc(I.t("stmtCol"))}</th><th>${esc(I.t("dueL"))}</th><th class="r">${esc(I.t("total"))}</th><th class="r">${esc(I.t("paidAmt").replace(/\s*\/.*$/, ""))}</th><th class="r">${esc(I.t("stmtOwed"))}</th></tr></thead><tbody>${st.rows.map((r) =>
      `<tr><td>${esc(r.number)}<br><span class="sub">${esc(I.formatDate(r.issueDate))}</span></td><td>${esc(I.formatDate(r.dueDate))}${r.overdue ? ` <span class="late">${esc(I.t("overdue"))}</span>` : ""}</td><td class="r">${m(r.total)}${r.withheld ? `<br><span class="sub">${esc(I.t("whL"))} −${m(r.withheld)}</span>` : ""}</td><td class="r">${m(r.paid)}${r.payments.map((p) => `<br><span class="sub">${esc(I.t("stmtPaidOn", { d: I.formatDate(p.date) }))}</span>`).join("")}</td><td class="r">${m(r.balance)}</td></tr>`).join("")}</tbody></table>
    <p class="r"><b>${esc(I.t("stmtLatest"))}: ${m(st.totals.balance)}</b>${st.totals.overdue ? `<br><span class="late">${esc(I.t("dashOverdue"))}: ${m(st.totals.overdue)}</span>` : ""}</p>
    <p class="sub">${esc(I.t("stmtNote"))}</p>`;
  $("#stmt").showModal();
}
$("#clientsum").addEventListener("click", (e) => {
  const b = e.target.closest("[data-stmt]");
  if (b && isPro()) openStatement(b.dataset.stmt, b.dataset.cur);
});
$("#stmt-close").onclick = () => $("#stmt").close();
$("#stmt-csv").onclick = () => { if (stmtOpen) download(`statement-${stmtOpen.client.replace(/[^\w-]+/g, "_")}.csv`, "text/csv", L.statementCSV(stmtOpen)); };
$("#stmt-print").onclick = () => { document.body.classList.add("print-stmt"); window.print(); };
window.addEventListener("afterprint", () => document.body.classList.remove("print-stmt"));
