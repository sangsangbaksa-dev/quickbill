(function () {
  'use strict';
  var C = window.SL, I = window.I18N, CFG = window.SL_CONFIG;
  var KEY = 'stayline.v1', root = document.getElementById('root');
  var state = load(), lang = I.pick(state.lang), plan = {}, adding = false, creating = false, editing = '', editCounter = false, pasting = false, calMonth = '';

  function load() {
    try { var s = JSON.parse(localStorage.getItem(KEY)); if (s && Array.isArray(s.trackers)) { s.trackers = C.sanitize(s.trackers); return s; } } catch (e) {}
    return { v: 1, trackers: [], active: '', pro: false, lang: '' };
  }
  /* a failed write (storage full, blocked) used to lose data silently: say so, so the user can back up */
  function save() { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { toast(T('saveFail')); } if (cloud) cloud.changed(); }

  /* Optional cloud sync (Supabase). Off unless config.js has a project URL and key. Licence fields stay on this device. */
  var LOCAL_ONLY = ['theme', 'pro', 'key', 'licMode', 'instanceId', 'licChecked', 'lang'];
  var cloud = window.CloudSync && window.SL_CONFIG ? window.CloudSync.create({
    url: window.SL_CONFIG.supabaseUrl, anonKey: window.SL_CONFIG.supabaseKey, app: 'stayline', storage: window.localStorage, device: (navigator.platform || 'web').slice(0, 60),
    snapshot: function () { var o = JSON.parse(JSON.stringify(state)); LOCAL_ONLY.forEach(function (k) { delete o[k]; }); return o; },
    isEmpty: function (snap) { return !snap.trackers || !snap.trackers.length; },
    apply: function (snap) {
      if (!snap || !Array.isArray(snap.trackers)) return;
      var keep = {}; LOCAL_ONLY.forEach(function (k) { keep[k] = state[k]; });
      try { localStorage.setItem(KEY, JSON.stringify(Object.assign({}, snap, keep))); } catch (e) { return; }
      location.reload();
    },
    onResult: function (r) { if (r.status === 'pushed') toast(window.CloudI18n.t(lang, 'pushed')); }
  }) : null;
  if (cloud && !cloud.enabled()) cloud = null;
  var shared = (function () { var m = /^#s=([A-Za-z0-9_-]+)$/.exec(location.hash); return m ? C.decodeShare(m[1]) : null; })();
  if (shared) cloud = null;
  function T(k, v) { return I.t(lang, k, v); }
  function h(tag, attrs, kids) {
    var e = document.createElement(tag);
    for (var k in (attrs || {})) {
      if (k === 'class') e.className = attrs[k]; else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), attrs[k]);
      else if (attrs[k] !== false && attrs[k] != null) e.setAttribute(k, attrs[k]);
    }
    [].concat(kids == null ? [] : kids).forEach(function (c) { if (c == null) return; e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  function toast(msg, undo) {
    var t = h('div', { class: 'toast', role: 'status' }, msg); document.body.appendChild(t);
    if (undo) t.appendChild(h('button', { class: 'ghost small tundo', onclick: function () { t.remove(); undo(); } }, T('undo')));
    setTimeout(function () { t.remove(); }, undo ? 6000 : 2200);
  }
  /* snapshot before a destructive change; the toast offers to put it back */
  function undoable(msg, change) {
    var snap = JSON.stringify({ t: state.trackers, a: state.active });
    change();
    toast(msg, function () { var s = JSON.parse(snap); state.trackers = C.sanitize(s.t); state.active = s.a; save(); render(); toast(T('undone')); });
  }
  function uid() { return 'k' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function fmt(s) {
    try { return new Intl.DateTimeFormat(lang, { year: 'numeric', month: 'short', day: 'numeric', timeZone: 'UTC' }).format(new Date(C.dn(s) * 86400000)); }
    catch (e) { return s; }
  }
  function current() {
    return state.trackers.filter(function (t) { return t.id === state.active; })[0] || state.trackers[0] || null;
  }
  function download(name, text, type) {
    var url = URL.createObjectURL(new Blob([type === 'text/csv' ? '\uFEFF' + text : text], { type: type })), a = h('a', { href: url, download: name });
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }
  /* Pro key check. If the server function is configured it decides; if it is absent (404) or not configured,
     fall back to the built-in offline check. A network failure never unlocks anything. */
  function verifyKey(key) {
    if (!key) return Promise.resolve('bad');
    return fetch(CFG.licenseApi, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: key }) })
      .then(function (r) { return r.ok ? r.json() : { configured: false }; })
      .then(function (d) { return d && d.configured ? (d.valid ? 'ok' : 'bad') : (C.validKey(key) ? 'ok' : 'bad'); })
      .catch(function () { return 'net'; });
  }
  function legal(page) { return (lang === 'en' ? '/' : '/' + lang + '/') + page; }
  function needPro() { if (state.pro) return false; toast(T('proOnly')); return true; }

  /* SVG progress ring for the status card: share of the limit used, drawn in the board's state colour */
  function svgEl(tag, attrs) {
    var e = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (var k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  }
  function ring(used, limit, state) {
    var r = 15, c = 2 * Math.PI * r, pct = limit > 0 ? Math.min(1, Math.max(0, used / limit)) : 0;
    var svg = svgEl('svg', { viewBox: '0 0 36 36', width: 76, height: 76, class: 'ring st-' + state, role: 'img', 'aria-label': T('usedOf', { u: used, l: limit }), focusable: 'false' });
    svg.appendChild(svgEl('circle', { cx: 18, cy: 18, r: r, class: 'ring-bg', fill: 'none', 'stroke-width': 3.2 }));
    svg.appendChild(svgEl('circle', { cx: 18, cy: 18, r: r, class: 'ring-fg', fill: 'none', 'stroke-width': 3.2, 'stroke-linecap': 'round', 'stroke-dasharray': (pct * c).toFixed(2) + ' ' + c.toFixed(2), transform: 'rotate(-90 18 18)' }));
    var tx = svgEl('text', { x: 18, y: 19.6, 'text-anchor': 'middle', class: 'ring-txt' });
    tx.textContent = Math.round(pct * 100) + '%';
    svg.appendChild(tx);
    return svg;
  }
  function explainText(rule) { var e = C.explainRule(rule); return T(e.key, e.vars); }
  function leftText(n) {
    if (n >= 0) return n === 1 ? T('dayLeft') : T('daysLeft', { n: n });
    return n === -1 ? T('dayOver') : T('daysOver', { n: -n });
  }

  /* ---------- views ---------- */
  function header() {
    var sel = h('select', { 'aria-label': T('lang'), onchange: function () { state.lang = sel.value; lang = sel.value; save(); render(); } },
      I.langs.map(function (l) { return h('option', { value: l, selected: l === lang ? '' : false }, I.L[l].name); }));
    return h('header', null, [h('h1', null, [h('span', { class: 'mark' }, '▸'), T('app')]), sel]);
  }

  function tabs() {
    var cur = current();
    return h('nav', { class: 'tabs' }, state.trackers.map(function (t) {
      return h('button', { class: 'tab' + (cur && t.id === cur.id ? ' on' : ''), 'aria-pressed': cur && t.id === cur.id ? 'true' : 'false', onclick: function () { state.active = t.id; plan = {}; save(); render(); } }, t.name || T('namePh'));
    }).concat([h('button', { class: 'tab add', 'aria-label': T('newTracker'), onclick: function () {
      creating = true; render();
    } }, '+')]));
  }

  function board(tr, ro) {
    var s = C.summary(tr, C.todayStr());
    var big = s.left < 0 ? -s.left : s.left;
    var cells = C.strip(tr, C.todayStr());
    var strip = h('div', { class: 'strip', role: 'img', 'aria-label': T('usedOf', { u: s.used, l: s.rule.limit }) },
      cells.map(function (c) { return h('i', { class: (c.in ? 'in ' : '') + (c.today ? 'now ' : '') + (c.future ? 'fut' : '') }); }));
    return h('section', { class: 'board st-' + s.state }, [
      h('div', { class: 'flap', 'aria-live': 'polite' }, [
        h('div', { class: 'digits' }, String(big).split('').map(function (d) { return h('b', null, d); })),
        h('div', { class: 'unit' }, T(s.left < 0 ? 'unitOver' : 'unitLeft')),
        ring(s.used, s.rule.limit, s.state)
      ]),
      h('div', { class: 'line' }, [h('span', { class: 'chip' }, T('s_' + s.state)), h('span', null, T('usedOf', { u: s.used, l: s.rule.limit }))]),
      strip,
      h('div', { class: 'sub' }, [
        h('span', null, T('from_win', { date: fmt(s.windowFrom) })),
        s.inside ? h('span', null, T('inside')) : null,
        s.inside && C.lastDay(tr, C.todayStr()) ? h('span', null, T('leaveBy', { date: fmt(C.lastDay(tr, C.todayStr())) })) : null,
        s.inside && tr.buffer && C.safeLastDay(tr, C.todayStr()) ? h('span', { class: 'safe' }, T('safeLeave', { date: fmt(C.safeLastDay(tr, C.todayStr())), n: tr.buffer })) : null,
        s.inside && tr.buffer && s.left >= 0 && !C.safeLastDay(tr, C.todayStr()) ? h('span', { class: 'marginGone' }, T('marginGone', { n: tr.buffer })) : null,
        s.freesOn ? h('span', { class: 'free' }, T('freeOn', { date: fmt(s.freesOn) })) : null,
        s.permit ? h('span', { class: 'permit p-' + s.permit.state }, s.permit.state === 'gone' ? T('permitGone', { date: fmt(tr.expires) }) : s.permit.days === 0 ? T('permitToday') : T('permitLeft', { n: s.permit.days })) : null
      ]),
      ro ? null : h('div', { class: 'row wrap boardbtns' }, [quickBtn(tr), h('button', { class: 'ghost small editc', onclick: function () { editCounter = true; render(); } }, T('editCounter'))])
    ]);
  }

  function ruleLabel(r) { return r.kind === 'year' ? r.limit + ' / ' + T('calYear') : r.limit + ' / ' + r.window; }
  function overview() {
    var today = C.todayStr(), cur = current();
    return h('section', { class: 'card ov' }, [h('h2', null, T('overview')), h('ul', null, state.trackers.map(function (t) {
      var s = C.summary(t, today);
      return h('li', null, h('button', { class: 'ovrow' + (cur && cur.id === t.id ? ' on' : ''), onclick: function () { state.active = t.id; plan = {}; save(); render(); } }, [
        h('span', null, [h('strong', null, t.name || T('namePh')), h('span', { class: 'dates' }, ruleLabel(s.rule))]),
        h('span', { class: 'chip st-' + s.state }, leftText(s.left)),
        s.permit && s.permit.state !== 'ok' ? h('span', { class: 'permit p-' + s.permit.state }, s.permit.state === 'gone' ? '!' : s.permit.days + 'd') : null
      ]));
    }))]);
  }

  function planner(tr) {
    /* a cleared field is stored as '' or 0; keep it empty instead of snapping back on the next render */
    var start = plan.arrive != null ? plan.arrive : C.addDays(C.todayStr(), 1), n = plan.nights != null ? plan.nights : 14, rule = C.cleanRule(tr.rule);
    var out = h('p', { class: 'plan-out', id: 'plan-out', role: 'status' }), win = h('div', { class: 'wins' });
    function calc() {
      var a = document.getElementById('p-arrive').value, d = +document.getElementById('p-days').value;
      plan = { arrive: a, nights: d };
      if (!C.validDate(a) || !(d >= 1)) { out.textContent = ''; win.replaceChildren(); return; }
      var max = C.maxStay(tr, a, C.todayStr()), msg;
      if (d > rule.limit) msg = T('planNoEarly', { n: d });
      else {
        var e = C.earliestEntry(tr, d, a, C.todayStr());
        msg = max <= 0 ? T('planNone') : T('planMax', { date: fmt(a), n: max, end: fmt(C.addDays(a, max - 1)) });
        if (e === a) msg += ' ' + T('planNow'); else if (e) msg += ' ' + T('planEarly', { n: d, date: fmt(e) });
        else msg += ' ' + T('planNoEarly', { n: d });
        if (tr.expires && max > 0 && C.addDays(a, d - 1) > tr.expires) msg += ' ' + T('planPast', { date: fmt(tr.expires) });
      }
      out.textContent = msg;
      var wins = d <= rule.limit ? C.arrivalWindows(tr, d, C.todayStr() > a ? C.todayStr() : a, C.todayStr(), 365) : [];
      win.replaceChildren();
      if (d <= rule.limit) {
        win.appendChild(h('div', null, wins.length ? T('winH', { n: d }) : T('winNone', { n: d })));
        wins.slice(0, 4).forEach(function (w) { win.appendChild(h('div', { class: 'dates' }, T('winRange', { a: fmt(w.from), b: fmt(w.to) }))); });
      }
    }
    var wrap = h('section', { class: 'card' }, [
      h('h2', null, T('planH')),
      h('div', { class: 'grid2' }, [
        h('label', null, [T('arrive'), h('input', { type: 'date', id: 'p-arrive', value: start, oninput: calc })]),
        h('label', null, [T('nights'), h('input', { type: 'number', id: 'p-days', min: 1, max: 366, value: n, inputmode: 'numeric', oninput: calc })])
      ]), out, win]);
    setTimeout(calc, 0);
    return wrap;
  }

  /* what if I leave on a date: days left that day, if the current stay ends then */
  function leaveCard(tr) {
    var today = C.todayStr(), out = h('p', { class: 'plan-out', id: 'lv-out', role: 'status' });
    var inp = h('input', { type: 'date', id: 'lv-date', value: C.addDays(today, 30) });
    function calc() {
      var r = C.leaveOn(tr, inp.value, today);
      out.textContent = r ? T('leaveRes', { date: fmt(r.date), t: leftText(r.left) }) : '';
    }
    inp.addEventListener('input', calc);
    calc();
    return h('section', { class: 'card' }, [h('h2', null, T('leaveH')), h('label', null, [T('leaveDate'), inp]), out]);
  }
  /* days inside per week (Monday to Sunday) so far this year */
  function weeklyCard(tr) {
    var wk = C.weeklyYear(tr, C.todayStr());
    var bars = h('div', { class: 'fc weeks', role: 'img', 'aria-label': T('wkH') }, wk.map(function (x) {
      return h('i', { title: T('wkTip', { date: fmt(x.start), n: x.days }), style: 'height:' + Math.max(2, Math.round(Math.min(7, x.days) / 7 * 100)) + '%' });
    }));
    return h('section', { class: 'card' }, [h('h2', null, T('wkH')), bars, h('p', { class: 'muted small' }, T('wkCap'))]);
  }
  /* upcoming trip reminders across all counters (next 30 days) */
  function reminderCard() {
    var items = C.reminders(state.trackers, C.todayStr(), 30);
    if (!items.length) return null;
    return h('section', { class: 'card', 'aria-labelledby': 'rem-h' }, [h('h2', { id: 'rem-h' }, T('remH')),
      h('ul', { class: 'alerts' }, items.map(function (x) {
        return h('li', null, [
          h('span', null, [h('button', { class: 'ghost small', onclick: function () { state.active = x.id; plan = {}; save(); render(); } }, x.name || T('namePh')), ' ', (x.place || '—') + (x.text ? ' · ' + x.text : '')]),
          h('span', { class: 'dates' }, fmt(x.on) + ' · ' + rel(x.in))
        ]);
      }))]);
  }
  function rel(n) { return n === 0 ? T('todayWord') : n === 1 ? T('inDay') : T('inDays', { n: n }); }
  function banner() {
    var list = C.urgent(state.trackers, C.todayStr());
    if (!list.length) return null;
    return h('section', { class: 'banner', role: 'region', 'aria-label': T('bannerH') }, [h('strong', null, T('bannerH')),
      h('ul', null, list.slice(0, 5).map(function (u) {
        return h('li', null, T('a_' + u.kind) + ' · ' + (u.name || T('namePh')) + ' · ' + fmt(u.date) + (u.in >= 0 ? ' · ' + rel(u.in) : ''));
      }))]);
  }
  function keyDates(tr) {
    var list = C.alerts(tr, C.todayStr());
    return h('section', { class: 'card' }, [h('h2', null, T('alertsH')),
      list.length ? h('ul', { class: 'alerts' }, list.map(function (a) {
        return h('li', { class: 'al-' + a.kind }, [h('span', null, T('a_' + a.kind)),
          h('span', { class: 'dates' }, fmt(a.date) + (a.in >= 0 ? ' · ' + rel(a.in) : ''))]);
      })) : h('p', { class: 'muted' }, T('noAlerts'))]);
  }

  /* what-if: several future legs replayed on top of the real trips; nothing is saved until "add all" */
  function itinerary(tr) {
    var res = C.simulate(tr, tr.drafts || [], C.todayStr()), n = res.legs.length;
    var from = h('input', { type: 'date', id: 'w-from', 'aria-label': T('from'), value: C.addDays(C.todayStr(), 30) });
    var to = h('input', { type: 'date', id: 'w-to', 'aria-label': T('to'), value: C.addDays(C.todayStr(), 44) });
    var err = h('p', { class: 'err', role: 'alert' });
    var rows = res.legs.map(function (l) {
      var msg = l.ok ? T('legOk', { n: l.peak, l: res.limit }) : [T('legBreach', { date: fmt(l.breachDate) }),
        l.trimTo ? ' ' + T('legTrim', { date: fmt(l.trimTo), n: l.fit }) : ' ' + T('legNone'),
        l.earliest && l.earliest !== l.from ? ' ' + T('legEarly', { date: fmt(l.earliest) }) : ''].join('');
      return h('li', { class: l.ok ? 'leg-ok' : 'leg-bad' }, [
        h('div', null, [h('strong', null, fmt(l.from) + ' → ' + fmt(l.to) + ' · ' + l.days), h('span', { class: 'dates' }, msg)]),
        h('button', { class: 'ghost x', 'aria-label': T('removeLeg'), onclick: function () { C.removeDraft(tr, l.id); save(); render(); } }, '×')
      ]);
    });
    var ac = h('input', { type: 'number', min: 1, max: 20, value: 3, id: 'a-n', inputmode: 'numeric' }), ad = h('input', { type: 'number', min: 1, max: 366, value: 14, id: 'a-d', inputmode: 'numeric' }), ag = h('input', { type: 'number', min: 0, max: 365, value: 30, id: 'a-g', inputmode: 'numeric' });
    var autoBox = h('details', { class: 'auto' }, [h('summary', null, T('autoH')),
      h('div', { class: 'grid3' }, [h('label', null, [T('autoCount'), ac]), h('label', null, [T('autoNights'), ad]), h('label', null, [T('autoGap'), ag])]),
      h('div', { class: 'row' }, [h('button', { class: 'ghost small', onclick: function () {
        var d = C.autoItinerary(tr, +ac.value, +ad.value, +ag.value, C.todayStr(), C.todayStr());
        if (!d.length) { toast(T('autoNone')); return; }
        tr.drafts = []; d.forEach(function (x) { C.addDraft(tr, x); }); save(); render();
      } }, T('autoBtn'))])]);
    return h('section', { class: 'card' }, [h('h2', null, T('whatH')), h('p', { class: 'muted' }, T('whatHint')), autoBox,
      h('div', { class: 'grid2' }, [h('label', null, [T('from'), from]), h('label', null, [T('to'), to])]),
      err, h('div', { class: 'row' }, [h('button', { class: 'pri small', onclick: function () {
        if (!C.addDraft(tr, { from: from.value, to: to.value })) { err.textContent = T('badTrip'); return; }
        save(); render();
      } }, '+ ' + T('addLeg'))]),
      n ? h('ul', { class: 'trips legs' }, rows) : h('p', { class: 'muted' }, T('noLegs')),
      n ? h('p', { class: 'verdict ' + (res.ok ? 'v-ok' : 'v-bad'), role: 'status' }, T(res.ok ? 'whatOk' : 'whatBad')) : null,
      n ? h('div', { class: 'row' }, [
        h('button', { class: 'ghost', onclick: function () {
          var txt = C.itineraryText(res, function (l) { return l.ok ? '' : T('legBreach', { date: l.breachDate }); }).trim();
          (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(function () { toast(T('copied')); }, function () { toast(T('copyFail')); });
        } }, T('copyBtn')),
        h('button', { class: 'ghost', onclick: function () { tr.drafts = []; save(); render(); } }, T('clearAll')),
        h('button', { class: 'pri', onclick: function () { undoable(T('applied', { n: res.legs.length }), function () { C.commitDrafts(tr); save(); render(); }); } }, T('applyAll'))]) : null]);
  }

  function forecastCard(tr) {
    var f = C.forecast(tr, C.todayStr(), 180), max = C.cleanRule(tr.rule).limit;
    var bars = h('div', { class: 'fc', role: 'img', 'aria-label': T('forecastCap') }, f.map(function (x) {
      var v = Math.max(0, Math.min(max, x.left));
      return h('i', { title: T('forecastTip', { date: fmt(x.date), n: x.left }), class: x.left < 0 ? 'neg' : '', style: 'height:' + Math.max(2, Math.round(v / max * 100)) + '%' });
    }));
    return h('section', { class: 'card' }, [h('h2', null, T('forecastH')), bars, h('p', { class: 'muted small' }, T('forecastCap'))]);
  }

  function groupCard() {
    var start = plan.garrive != null ? plan.garrive : C.addDays(C.todayStr(), 1), n = plan.gnights != null ? plan.gnights : 14, all = state.trackers;
    var out = h('div', { class: 'plan-out', id: 'g-out', role: 'status' });
    function calc() {
      var a = document.getElementById('g-arrive').value, d = +document.getElementById('g-days').value;
      plan.garrive = a; plan.gnights = d; out.replaceChildren();
      if (!C.validDate(a) || !(d >= 1)) return;
      var g = C.groupMaxStay(all, a, C.todayStr()), nm = {}, lim = C.groupEarliest(all, d, a, C.todayStr());
      all.forEach(function (t) { nm[t.id] = t.name || T('namePh'); });
      out.appendChild(h('p', null, g.days > 0 ? T('groupMax', { date: fmt(a), n: g.days, end: fmt(C.addDays(a, g.days - 1)) }) : T('groupNone')));
      out.appendChild(h('ul', { class: 'alerts' }, g.people.map(function (p) { return h('li', null, h('span', null, T('groupWho', { name: nm[p.id], n: p.max }))); })));
      out.appendChild(h('p', { class: 'muted' }, T('groupLimit', { name: g.limiting.map(function (id) { return nm[id]; }).join(', ') })));
      out.appendChild(h('p', null, lim ? (lim === a ? T('planNow') : T('groupEarly', { n: d, date: fmt(lim) })) : T('groupNoEarly', { n: d })));
    }
    var card = h('section', { class: 'card' }, [h('h2', null, T('groupH')), h('p', { class: 'muted' }, T('groupHint')),
      h('div', { class: 'grid2' }, [
        h('label', null, [T('arrive'), h('input', { type: 'date', id: 'g-arrive', value: start, oninput: calc })]),
        h('label', null, [T('nights'), h('input', { type: 'number', id: 'g-days', min: 1, max: 366, value: n, inputmode: 'numeric', oninput: calc })])]), out]);
    setTimeout(calc, 0);
    return card;
  }
  function calendarCard(tr) {
    var ym = calMonth || C.todayStr().slice(0, 7), weeks = C.calendarMonth(tr, ym, C.todayStr());
    var label;
    try { label = new Intl.DateTimeFormat(lang, { year: 'numeric', month: 'long', timeZone: 'UTC' }).format(new Date(C.dn(ym + '-01') * 86400000)); } catch (e) { label = ym; }
    var heads = weeks[0].map(function (c) {
      var w; try { w = new Intl.DateTimeFormat(lang, { weekday: 'narrow', timeZone: 'UTC' }).format(new Date(C.dn(c.date) * 86400000)); } catch (e) { w = ''; }
      return h('span', { class: 'wd' }, w);
    });
    var cells = [].concat.apply([], weeks).map(function (c) {
      return h('span', { class: 'day' + (c.inMonth ? '' : ' off') + (c.in ? (c.planned ? ' plan' : ' in') : '') + (c.over ? ' over' : '') + (c.today ? ' now' : ''), title: fmt(c.date) }, String(+c.date.slice(8)));
    });
    return h('section', { class: 'card' }, [
      h('div', { class: 'rowhead' }, [h('h2', null, T('calH') + ' · ' + label), h('span', { class: 'rowbtns' }, [
        h('button', { class: 'ghost small', 'aria-label': T('calPrev'), onclick: function () { calMonth = C.addMonth(ym, -1); render(); } }, '‹'),
        h('button', { class: 'ghost small', 'aria-label': T('calNext'), onclick: function () { calMonth = C.addMonth(ym, 1); render(); } }, '›'),
        calMonth && calMonth !== C.todayStr().slice(0, 7) ? h('button', { class: 'ghost small', onclick: function () { calMonth = ''; render(); } }, T('today')) : null])]),
      h('div', { class: 'cal' }, heads.concat(cells)), h('p', { class: 'muted small' }, T('calLegend'))]);
  }
  function auditCard(tr) {
    var eps = C.audit(tr, C.todayStr(), 3);
    return h('section', { class: 'card' }, [h('h2', null, T('auditH')),
      eps.length ? h('ul', { class: 'alerts' }, eps.map(function (e) { return h('li', { class: 'al-over' }, h('span', null, T('auditEp', { from: fmt(e.from), to: fmt(e.to), n: e.over }))); }))
        : h('p', { class: 'v-ok' }, T('auditOk')),
      h('p', { class: 'muted small' }, T('auditNote'))]);
  }
  function monthCard(tr) {
    var m = C.monthlyUsage(tr, C.todayStr(), 12);
    var bars = h('div', { class: 'fc months', role: 'img', 'aria-label': T('monthCap') }, m.map(function (x) {
      return h('i', { title: T('monthTip', { month: x.month, n: x.days }), style: 'height:' + Math.max(2, Math.round(x.days / 31 * 100)) + '%' });
    }));
    return h('section', { class: 'card' }, [h('h2', null, T('monthH')), bars, h('p', { class: 'muted small' }, T('monthCap'))]);
  }

  function placesCard(tr) {
    var ps = C.placeStats(tr, C.todayStr(), 365);
    if (!ps.length) return null;
    var max = ps[0].days, total = ps.reduce(function (a, x) { return a + x.days; }, 0);
    return h('section', { class: 'card' }, [h('h2', null, T('placesH')),
      h('ul', { class: 'places' }, ps.slice(0, 8).map(function (x) {
        return h('li', null, [
          h('div', { class: 'pl-top' }, [h('strong', null, x.place || T('placeNone')), h('span', { class: 'muted small' }, T('placeRow', { n: x.days, t: x.trips, l: x.longest }))]),
          h('div', { class: 'pl-bar', role: 'presentation' }, h('i', { style: 'width:' + Math.max(2, Math.round(x.days / max * 100)) + '%' }))
        ]);
      })),
      h('p', { class: 'muted small' }, T('placesCap', { n: total }))]);
  }

  function borderText(tr) {
    var b = C.borderSheet(tr, C.todayStr()), L = [T('borderTitle', { name: b.name || T('namePh') }), b.rule.kind === 'year' ? T('borderRuleY', { l: b.rule.limit }) : T('borderRuleR', { l: b.rule.limit, w: b.rule.window }),
      T('borderUsed', { u: b.used, n: Math.max(0, b.left), date: b.windowFrom, today: b.today }), ''];
    if (!b.trips.length) L.push(T('borderNone'));
    b.trips.forEach(function (x) { L.push((x.place || '—') + ': ' + x.from + ' → ' + (x.to || b.today) + ' (' + x.days + (x.countedFrom !== x.from ? ', ' + T('borderCounted', { date: x.countedFrom }) : '') + ')' + (x.note ? ' · ' + x.note : '')); });
    if (b.overlap) L.push(T('borderOverlap'));
    if (b.left < 0) L.push(T('borderOver', { n: -b.left, today: b.today }));
    if (b.lastDay) L.push('', T('borderLast', { date: b.lastDay }));
    if (b.safeLastDay) L.push(T('borderSafe', { date: b.safeLastDay }));
    L.push('', T('borderDisc'));
    return L.join('\n');
  }
  function borderCard(tr) {
    var txt = borderText(tr);
    return h('section', { class: 'card' }, [h('h2', null, T('borderH')), h('p', { class: 'muted' }, T('borderHint')),
      h('pre', { class: 'sheet', tabindex: '0', role: 'region', 'aria-label': T('borderH') }, txt),
      h('div', { class: 'row' }, [h('button', { class: 'ghost', onclick: function () {
        (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(function () { toast(T('borderCopied')); }, function () {
          var pre = document.querySelector('pre.sheet'), r = document.createRange(); r.selectNodeContents(pre);
          var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(r); toast(T('borderCopyFail'));
        });
      } }, T('borderCopy'))])]);
  }
  function tripList(tr, ro) {
    var list = tr.trips.length ? h('ul', { class: 'trips' }, tr.trips.map(function (t) {
      var days = Object.keys(C.stayDays([t], C.todayStr())).length;
      return h('li', null, [
        h('div', null, [
          h('strong', null, t.place || '—'),
          h('span', { class: 'dates' }, fmt(t.from) + ' → ' + (t.to ? fmt(t.to) : T('today')) + ' · ' + days),
          t.from > C.todayStr() ? h('span', { class: 'chip plan' }, T('planned')) : null,
          t.holiday ? h('span', { class: 'chip plan' }, T('holidayChip')) : null,
          t.remindOn ? h('span', { class: 'dates note' }, fmt(t.remindOn) + (t.remindText ? ' · ' + t.remindText : '')) : null,
          t.note ? h('span', { class: 'dates note' }, t.note) : null
        ]),
        ro ? null : h('span', { class: 'rowbtns' }, [
          /* only a trip that has started can end today; a planned one would get an end before its start */
          !t.to && t.from <= C.todayStr() ? h('button', { class: 'ghost', onclick: function () { t.to = C.todayStr(); save(); render(); } }, T('leftToday')) : null,
          h('button', { class: 'ghost', onclick: function () { editing = t.id; render(); } }, T('edit')),
          h('button', { class: 'ghost x', 'aria-label': T('confTrip'), onclick: function () { if (confirm(T('confTrip'))) undoable(T('tripGone'), function () { C.removeTrip(tr, t.id); save(); render(); }); } }, '×')
        ])
      ]);
    })) : h('p', { class: 'muted' }, T('noTrips'));
    return h('section', { class: 'card' }, [
      h('div', { class: 'rowhead' }, [h('h2', null, T('trips')), ro ? null : h('span', { class: 'rowbtns' }, [h('button', { class: 'ghost small', onclick: function () { pasting = true; render(); } }, T('pasteBtn')), h('button', { class: 'pri small', onclick: function () { adding = true; render(); } }, '+ ' + T('addTrip'))])]),
      list]);
  }

  function tripDialog(tr) {
    var cur = editing ? tr.trips.filter(function (x) { return x.id === editing; })[0] : null;
    var dlg = h('dialog', { 'aria-labelledby': 'dlg-h' }), err = h('p', { class: 'err', role: 'alert' });
    var from = h('input', { type: 'date', id: 'f-from', required: '', value: cur ? cur.from : C.todayStr() });
    var to = h('input', { type: 'date', id: 'f-to', value: cur ? cur.to : '', disabled: cur && !cur.to ? '' : false });
    var on = h('input', { type: 'checkbox', id: 'f-on', checked: cur && !cur.to ? '' : false, onchange: function () { to.disabled = on.checked; if (on.checked) to.value = ''; } });
    var hol = h('input', { type: 'checkbox', id: 'f-hol', checked: cur && cur.holiday ? '' : false });
    var rd = h('input', { type: 'date', id: 'f-rdate', value: cur && cur.remindOn ? cur.remindOn : '' });
    var rt = h('input', { id: 'f-rtext', maxlength: 120, value: cur ? cur.remindText || '' : '' });
    dlg.appendChild(h('form', { method: 'dialog', onsubmit: function (e) {
      e.preventDefault();
      var data = { place: document.getElementById('f-place').value, note: document.getElementById('f-note').value, from: from.value, to: on.checked ? '' : to.value, holiday: hol.checked, remindOn: rd.value, remindText: rt.value };
      var ok = cur ? C.updateTrip(tr, cur.id, data) : C.addTrip(tr, data);
      if (!ok) { err.textContent = T('badTrip'); return; }
      adding = false; editing = ''; save(); render();
    } }, [
      h('h2', { id: 'dlg-h' }, cur ? T('editTrip') : T('addTrip')),
      h('label', null, [T('place'), h('input', { id: 'f-place', maxlength: 60, value: cur ? cur.place : '' })]),
      h('label', null, [T('from'), from]),
      h('label', null, [T('to'), to]),
      h('label', null, [T('noteL'), h('input', { id: 'f-note', maxlength: 120, value: cur ? cur.note || '' : '' })]),
      h('label', { class: 'chk' }, [on, T('ongoing')]),
      h('label', { class: 'chk' }, [hol, T('holidayL')]),
      h('label', null, [T('remindDateL'), rd]),
      h('label', null, [T('remindTextL'), rt]),
      err,
      h('div', { class: 'row' }, [h('button', { type: 'button', class: 'ghost', onclick: function () { adding = false; editing = ''; render(); } }, T('cancel')), h('button', { type: 'submit', class: 'pri' }, T('save'))])
    ]));
    return dlg;
  }

  function pasteDialog(tr) {
    var dlg = h('dialog', { 'aria-labelledby': 'dlg-h' }), info = h('p', { class: 'muted', role: 'status' }), parsed = { trips: [], bad: [] };
    var ta = h('textarea', { id: 'f-paste', rows: 6, spellcheck: 'false', oninput: function () {
      parsed = C.parseTrips(ta.value);
      info.textContent = ta.value.trim() ? T('pasteFound', { n: parsed.trips.length }) + (parsed.bad.length ? ' ' + T('pasteBad', { lines: parsed.bad.slice(0, 8).join(', ') }) : '') : '';
      go.disabled = !parsed.trips.length;
    } });
    var go = h('button', { type: 'button', class: 'pri', disabled: '', onclick: function () {
      pasting = false;
      undoable(T('pasteDone', { n: parsed.trips.length }), function () { parsed.trips.forEach(function (t) { C.addTrip(tr, t); }); save(); render(); });
    } }, T('pasteAdd'));
    dlg.appendChild(h('div', null, [h('h2', { id: 'dlg-h' }, T('pasteH')), h('p', { class: 'muted' }, T('pasteHint')), ta, info,
      h('div', { class: 'row' }, [h('button', { type: 'button', class: 'ghost', onclick: function () { pasting = false; render(); } }, T('cancel')), go])]));
    return dlg;
  }
  function trackerDialog() {
    var dlg = h('dialog', { 'aria-labelledby': 'dlg-h' });
    var sel = h('select', { id: 'f-rule', onchange: sync }, [['schengen', 'r_schengen'], ['visitor180', 'r_visitor180'], ['tax183', 'r_tax183'], ['custom', 'r_custom'], ['customYear', 'r_customYear']]
      .map(function (o) { return h('option', { value: o[0] }, T(o[1])); }));
    var limit = h('input', { type: 'number', id: 'f-limit', min: 1, max: 366, value: 90 });
    var win = h('input', { type: 'number', id: 'f-win', min: 1, max: 730, value: 180 });
    var custom = h('div', { class: 'grid2', hidden: '' }, [h('label', null, [T('limit'), limit]), h('label', { id: 'f-winl' }, [T('window'), win])]);
    var expl = h('p', { class: 'fine', id: 'f-expl', role: 'status' });
    function pickRule() {
      var v = sel.value;
      return v === 'schengen' ? C.PRESETS.schengen : v === 'visitor180' ? C.PRESETS.visitor180 : v === 'tax183' ? C.PRESETS.tax183
        : v === 'custom' ? { kind: 'rolling', limit: limit.value, window: win.value } : { kind: 'year', limit: limit.value };
    }
    function showExpl() { expl.textContent = explainText(pickRule()); }
    limit.addEventListener('input', showExpl); win.addEventListener('input', showExpl);
    function sync() {
      var v = sel.value; custom.hidden = v.indexOf('custom') !== 0;
      document.getElementById('f-winl').hidden = v !== 'custom';
      showExpl();
    }
    dlg.appendChild(h('form', { method: 'dialog', onsubmit: function (e) {
      e.preventDefault();
      var rule = pickRule();
      var t = { id: uid(), name: (document.getElementById('f-name').value || '').trim().slice(0, 40), rule: C.cleanRule(rule), expires: document.getElementById('f-exp').value || '', trips: [] };
      state.trackers.push(t); state.active = t.id; creating = false; save(); render();
    } }, [
      h('h2', { id: 'dlg-h' }, T('newTracker')),
      h('label', null, [T('trackerName'), h('input', { id: 'f-name', maxlength: 40, placeholder: T('namePh') })]),
      h('label', null, [T('rule'), sel]), custom, expl,
      h('label', null, [T('expires'), h('input', { type: 'date', id: 'f-exp' })]),
      h('div', { class: 'row' }, [h('button', { type: 'button', class: 'ghost', onclick: function () { creating = false; render(); } }, T('cancel')), h('button', { type: 'submit', class: 'pri' }, T('save'))])
    ]));
    setTimeout(sync, 0);
    return dlg;
  }

  function counterDialog(tr) {
    var dlg = h('dialog', { 'aria-labelledby': 'dlg-h' });
    dlg.appendChild(h('form', { method: 'dialog', onsubmit: function (e) {
      e.preventDefault();
      tr.name = (document.getElementById('e-name').value || '').trim().slice(0, 40); tr.buffer = C.cleanBuffer(document.getElementById('e-buf').value);
      var x = document.getElementById('e-exp').value; tr.expires = C.validDate(x) ? x : '';
      editCounter = false; save(); render();
    } }, [
      h('h2', { id: 'dlg-h' }, T('editCounter')),
      h('label', null, [T('trackerName'), h('input', { id: 'e-name', maxlength: 40, value: tr.name })]),
      h('label', null, [T('expires'), h('input', { type: 'date', id: 'e-exp', value: tr.expires || '' })]),
      h('label', null, [T('bufferL'), h('input', { type: 'number', id: 'e-buf', min: 0, max: 30, step: 1, value: tr.buffer || 0, 'aria-describedby': 'e-buf-h' })]),
      h('p', { class: 'fine', id: 'e-buf-h' }, T('bufferHint')),
      h('div', { class: 'row' }, [h('button', { type: 'button', class: 'ghost', onclick: function () { editCounter = false; render(); } }, T('cancel')), h('button', { type: 'submit', class: 'pri' }, T('save'))])
    ]));
    return dlg;
  }
  /* Stayline is a paid app: without an activated Pro licence the counter stays behind this screen.
     Trips stay in local storage and show up again once the key is accepted on this device. */
  function paywall() {
    var lic = h('input', { id: 'lic', placeholder: T('licPh'), autocomplete: 'off', spellcheck: 'false', 'aria-label': T('lic') });
    return h('section', { class: 'paywall', 'aria-labelledby': 'pay-h' }, [
      h('h2', { id: 'pay-h' }, T('payH')),
      h('p', null, T('payLead', { price: CFG.price })),
      h('p', null, [h('a', { class: 'pri btnlink', href: CFG.checkoutUrl, rel: 'noopener', target: '_blank' }, T('upgrade'))]),
      h('div', { class: 'settings' }, [
        h('p', null, T('payHave')),
        h('label', null, [T('lic'), lic]),
        h('button', { class: 'pri', onclick: function () { activate(lic); } }, T('activate'))
      ]),
      h('p', { class: 'fine' }, T('payRefund')),
      h('p', { class: 'fine' }, [h('a', { href: legal('privacy') }, T('privacyLink')), ' · ', h('a', { href: legal('terms') }, T('termsLink')), ' · ', h('a', { href: 'mailto:' + CFG.supportEmail }, CFG.supportEmail)])
    ]);
  }
  function activate(input) {
    verifyKey(input.value.trim()).then(function (r) {
      if (r === 'ok') { state.pro = true; save(); toast(T('okKey')); render(); }
      else toast(T(r === 'net' ? 'licNet' : 'badKey'));
    });
  }
  /* permits and visas across all counters, soonest first; links to the counter */
  function permitCard() {
    var items = C.permitWatch(state.trackers, C.todayStr(), 90);
    if (!items.length) return null;
    return h('section', { class: 'card permits', 'aria-labelledby': 'permit-h' }, [
      h('h2', { id: 'permit-h' }, T('permitH')),
      h('ul', null, items.map(function (p) {
        return h('li', null, [h('button', { class: 'ghost small', onclick: function () { state.active = p.id; plan = {}; save(); render(); } }, p.name || T('namePh')), ' ',
          p.left < 0 ? T('permitGone', { date: fmt(p.expires) }) : T('permitIn', { n: p.left, date: fmt(p.expires) })]);
      }))
    ]);
  }
  function quickStart() {
    var t = { id: uid(), name: '', rule: C.cleanRule(C.PRESETS.schengen), expires: '', trips: [] };
    state.trackers.push(t); state.active = t.id; save(); render();
  }

  function empty() {
    return h('div', { class: 'empty' }, [
      h('div', { class: 'ghostflap' }, '90'),
      h('h2', null, T('emptyH')), h('p', null, T('emptyB')),
      h('ol', { class: 'steps' }, [T('emptyStep1'), T('emptyStep2'), T('emptyStep3')].map(function (s) { return h('li', null, s); })),
      h('div', { class: 'row center' }, [h('button', { class: 'pri', onclick: quickStart }, T('quick')), h('button', { class: 'ghost', onclick: function () { creating = true; render(); } }, T('newTracker'))])]);
  }

  /* opt-in reminder: one system notification per day, only when the app is opened and something is urgent */
  function remind() {
    if (!state.remind || typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
    var today = C.todayStr(), list = C.urgent(state.trackers, today);
    if (!list.length || state.remindedOn === today) return;
    try {
      new Notification(T('bannerH'), { body: list.slice(0, 3).map(function (u) { return T('a_' + u.kind) + ' · ' + (u.name || T('namePh')) + ' · ' + fmt(u.date); }).join('\n'), icon: '../icon.svg' });
      state.remindedOn = today; save();
    } catch (e) {}
  }
  function toggleRemind() {
    if (state.remind) { state.remind = false; save(); render(); return; }
    if (typeof Notification === 'undefined') { toast(T('remindNo')); return; }
    Notification.requestPermission().then(function (p) {
      if (p === 'granted') { state.remind = true; save(); toast(T('remindOk')); render(); remind(); } else toast(T('remindNo'));
    });
  }
  function footer(tr) {
    var file = h('input', { type: 'file', accept: 'application/json', hidden: '', onchange: function () {
      var f = file.files[0]; file.value = ''; if (!f) return; var r = new FileReader();
      r.onload = function () {
        try { var s = JSON.parse(r.result); if (!s || !Array.isArray(s.trackers)) throw 0; state = { v: 1, trackers: C.sanitize(s.trackers), active: s.active || '', pro: state.pro, lang: state.lang, theme: state.theme, remind: state.remind, remindedOn: state.remindedOn }; save(); render(); toast(T('restored')); }
        catch (e) { toast(T('badFile')); }
      };
      r.readAsText(f);
    } });
    var icsIn = h('input', { type: 'file', accept: '.ics,text/calendar', hidden: '', onchange: function () {
      var f = icsIn.files[0]; icsIn.value = ''; if (!f || !tr) return; var r = new FileReader();
      r.onload = function () {
        var found = C.parseIcs(r.result);
        if (!found.length) { toast(T('icsNone')); return; }
        undoable(T('icsDone', { n: found.length }), function () { found.forEach(function (t) { C.addTrip(tr, t); }); save(); render(); });
      };
      r.readAsText(f);
    } });
    var csvIn = h('input', { type: 'file', accept: '.csv,text/csv', hidden: '', onchange: function () {
      var f = csvIn.files[0]; csvIn.value = ''; if (!f || !tr) return; var r = new FileReader();
      r.onload = function () {
        var got = C.parseCsvTrips(r.result);
        if (!got.trips.length) { toast(T('csvNone')); return; }
        var add = C.newTrips(tr.trips, got.trips).fresh, dupes = got.trips.length - add.length, parts = [];
        if (!add.length) { toast(T('csvDup', { n: dupes })); return; }
        parts.push(T('csvDone', { n: add.length }));
        if (dupes) parts.push(T('csvDup', { n: dupes }));
        if (got.capped) parts.push(T('csvCapped', { n: got.capped }));
        if (got.bad.length) parts.push(T('pasteBad', { lines: got.bad.slice(0, 8).join(', ') }));
        undoable(parts.join(' '), function () { add.forEach(function (t) { C.addTrip(tr, t); }); save(); render(); });
      };
      r.readAsText(f);
    } });
    var cloudPanel = cloud && window.CloudPanel ? window.CloudPanel.build({ cloud: cloud, lang: function () { return lang; } }) : null;
    return h('footer', { class: 'foot' }, [
      h('div', { class: 'row wrap' }, [
        h('button', { class: 'ghost', onclick: function () { download('stayline-backup.json', JSON.stringify({ v: 1, trackers: state.trackers, active: state.active }), 'application/json'); toast(T('backupDone')); } }, T('exp')),
        h('button', { class: 'ghost', onclick: function () { file.click(); } }, T('imp')), file,
        tr ? h('button', { class: 'ghost', onclick: function () { icsIn.click(); } }, T('icsImport')) : null, icsIn,
        tr ? h('button', { class: 'ghost', onclick: function () { csvIn.click(); } }, T('csvImport')) : null, csvIn,
        state.trackers.length ? h('button', { class: 'ghost', onclick: function () { download('stayline-report.md', C.yearReport(state.trackers, C.todayStr()), 'text/markdown'); } }, T('report')) : null,
        h('button', { class: 'ghost', onclick: function () { if (needPro()) return; download('stayline.csv', C.toCsv(state.trackers, C.todayStr()), 'text/csv'); } }, T('csv')),
        h('button', { class: 'ghost', onclick: function () { download('stayline.ics', C.toIcs(state.trackers, C.todayStr()), 'text/calendar'); } }, T('ics')),
        h('button', { class: 'ghost', onclick: function () {
          if (needPro()) return;
          download('stayline-key-dates.ics', C.alertsIcs(state.trackers, C.todayStr(), function (k) { return T('icsLabel_' + k); }), 'text/calendar'); toast(T('icsDone'));
        } }, T('icsKey')),
        h('button', { class: 'ghost', onclick: function () { if (needPro()) return; window.print(); } }, T('print')),
        tr ? h('button', { class: 'ghost', onclick: function () {
          var u = shareUrl(tr);
          (navigator.clipboard ? navigator.clipboard.writeText(u) : Promise.reject()).then(function () { toast(T('shareCopied')); }, function () { toast(T('shareFail')); });
        } }, T('shareBtn')) : null
      ]),
      tr ? h('p', { class: 'fine' }, T('shareHint')) : null,
      cloudPanel ? h('div', { style: 'margin:14px 0' }, [cloudPanel.el]) : null,
      h('div', { class: 'settings' }, h('span', { class: 'chip' }, T('pro') + ' ✓')),
      h('div', null, [h('button', { class: 'ghost', onclick: function () { state.theme = state.theme === 'light' ? 'dark' : state.theme === 'dark' ? '' : 'light'; save(); render(); } }, T(state.theme === 'light' ? 'themeLight' : state.theme === 'dark' ? 'themeDark' : 'themeAuto'))]),
      h('div', null, [h('button', { class: 'ghost', onclick: toggleRemind }, state.remind ? T('remindOff') : T('remindOn')), h('p', { class: 'fine' }, T('remindHint'))]),
      tr ? h('button', { class: 'ghost danger', onclick: function () {
        if (!confirm(T('confDel'))) return;
        undoable(T('counterGone'), function () { state.trackers = state.trackers.filter(function (t) { return t.id !== tr.id; }); state.active = ''; save(); render(); });
      } }, T('del')) : null,
      h('p', { class: 'fine' }, T('disclaimer')), h('p', { class: 'fine' }, T('privacy')),
      h('p', { class: 'fine' }, [h('a', { href: legal('privacy') }, T('privacyLink')), ' · ', h('a', { href: legal('terms') }, T('termsLink')), ' · ', h('a', { href: 'mailto:' + CFG.supportEmail }, CFG.supportEmail)])
    ]);
  }


  /* one tap: start a trip today, or close the open one today */
  function quickBtn(tr) {
    var today = C.todayStr(), open = tr.trips.filter(function (t) { return !t.to && t.from <= today; })[0];
    if (open) return h('button', { class: 'pri small', onclick: function () { open.to = today; save(); render(); toast(T('quickOutDone')); } }, T('quickOut'));
    if (C.summary(tr, today).inside) return null;
    return h('button', { class: 'pri small', onclick: function () { if (C.addTrip(tr, { from: today, to: '', place: '' })) { save(); render(); toast(T('quickInDone')); } } }, T('quickIn'));
  }
  function rulesCard(tr) {
    var rows = C.compareRules(tr, C.todayStr());
    return h('section', { class: 'card' }, [h('h2', null, T('rulesH')), h('p', { class: 'muted' }, T('rulesHint')),
      h('ul', { class: 'rulelist' }, rows.map(function (r) {
        return h('li', null, [
          h('span', null, [h('strong', null, T('rule_' + (r.key === 'own' ? 'own' : r.key) + '_s')), r.own ? h('span', { class: 'dates' }, T('rulesOwn')) : null, h('span', { class: 'dates' }, T('usedOf', { u: r.used, l: r.rule.limit })), h('span', { class: 'dates' }, explainText(r.rule))]),
          h('span', { class: 'chip st-' + r.state }, leftText(r.left))]);
      }))]);
  }
  function statsCard(tr) {
    var st = C.yearStats(tr, C.todayStr());
    if (!st.trips) return h('section', { class: 'card' }, [h('h2', null, T('statsH')), h('p', { class: 'muted' }, T('statsNone'))]);
    return h('section', { class: 'card' }, [h('h2', null, T('statsH')),
      h('p', null, T('statsCount', { n: st.trips, p: st.places, t: st.total })),
      st.longest ? h('p', null, T('statsLongest', { n: st.longest.days, where: st.longest.place || '—', date: fmt(st.longest.from) })) : null,
      h('ul', { class: 'alerts' }, st.years.slice(0, 6).map(function (y) { return h('li', null, h('span', null, T('statsYear', { year: y.year, n: y.days }))); }))]);
  }
  function shareUrl(tr) { return location.origin + location.pathname + '#s=' + C.encodeShare(tr); }
  function sharedView(tr) {
    var kids = [header(), h('section', { class: 'banner', role: 'region' }, [h('strong', null, T('shareBadge')), h('div', null, T('shareFor', { name: tr.name || T('namePh') }))]),
      board(tr, true), keyDates(tr), rulesCard(tr), calendarCard(tr), forecastCard(tr), statsCard(tr), tripList(tr, true),
      h('div', { class: 'row wrap' }, [h('a', { class: 'pri link', href: location.pathname }, T('shareOpen'))]),
      h('p', { class: 'fine' }, T('disclaimer'))];
    root.replaceChildren.apply(root, kids);
  }
  function applyTheme() { var mt = document.querySelector('meta[name=theme-color]'), lt = state.theme === 'light' || (!state.theme && window.matchMedia && matchMedia('(prefers-color-scheme: light)').matches); if (mt) mt.setAttribute('content', lt ? '#f6f3ec' : '#14171a'); var th = state.theme === 'light' || state.theme === 'dark' ? state.theme : ''; if (th) document.documentElement.setAttribute('data-theme', th); else document.documentElement.removeAttribute('data-theme'); }
  if (window.matchMedia) { try { matchMedia('(prefers-color-scheme: light)').addEventListener('change', function () { applyTheme(); }); } catch (e) {} }
  function render() {
    var fid = document.activeElement && document.activeElement.id;
    applyTheme();
    document.documentElement.lang = lang; document.title = T('app');
    if (shared) { sharedView(shared); return; }
    if (!state.pro) { root.replaceChildren(header(), paywall()); return; }
    var tr = current(), kids = [header()];
    if (!tr) kids.push(h('p', { class: 'tag' }, T('tag')), empty());
    else {
      var bn = banner(); if (bn) kids.push(bn);
      var pc = permitCard(); if (pc) kids.push(pc);
      var rc = reminderCard(); if (rc) kids.push(rc);
      kids.push(tabs());
      if (state.trackers.length > 1) kids.push(overview());
      kids.push(board(tr), leaveCard(tr), keyDates(tr), planner(tr), itinerary(tr), rulesCard(tr));
      if (state.trackers.length > 1) kids.push(groupCard());
      kids.push(calendarCard(tr), forecastCard(tr), monthCard(tr), weeklyCard(tr), placesCard(tr), statsCard(tr), auditCard(tr), borderCard(tr), tripList(tr));
      var pr = h('div', { class: 'printonly' }, [h('h1', null, T('printTitle') + ' — ' + tr.name)]);
      kids.push(pr);
    }
    kids.push(footer(tr));
    root.replaceChildren.apply(root, kids);
    if ((adding || editing) && tr) { var d = tripDialog(tr); root.appendChild(d); d.showModal(); }
    if (pasting && tr) { var d5 = pasteDialog(tr); root.appendChild(d5); d5.showModal(); }
    if (editCounter && tr) { var d3 = counterDialog(tr); root.appendChild(d3); d3.showModal(); }
    if (creating) { var d2 = trackerDialog(); root.appendChild(d2); d2.showModal(); }
    /* re-rendering drops keyboard focus; put it back on the same input when it had an id */
    if (fid) { var fe = document.getElementById(fid); if (fe && typeof fe.focus === 'function' && document.activeElement !== fe) fe.focus(); }
  }
  document.addEventListener('cancel', function () { adding = creating = editCounter = pasting = false; editing = ''; setTimeout(render, 0); }, true);
  render();
  if (!shared && /^#s=/.test(location.hash)) toast(T('shareBad'));
  if (!shared) remind();
  if (!shared && cloud && cloud.user()) cloud.sync().then(function (r) { if (r.status === 'pulled') toast(window.CloudI18n.t(lang, 'pulled')); });
  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) navigator.serviceWorker.register('sw.js').catch(function () {});
})();
