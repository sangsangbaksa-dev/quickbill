import test from "node:test";
import assert from "node:assert/strict";
import * as L from "../logic.js";

test("totals with tax and discount", () => {
  const t = L.calcTotals([{ qty: 2, price: 50.10 }, { qty: 1, price: 19.9 }], 10, 20);
  assert.deepEqual(t, { subtotal: 120.1, discount: 20, tax: 10.01, total: 110.11, withholding: 0, payable: 110.11 });
});
test("discount cannot exceed subtotal; bad input is safe", () => {
  assert.equal(L.calcTotals([{ qty: 1, price: 10 }], 0, 999).total, 0);
  assert.equal(L.calcTotals([{ qty: "x", price: null }]).total, 0);
});
test("bulk status: only allowed statuses change, paid is settled, input is not mutated", () => {
  const list = [
    { id: "a", type: "invoice", number: "INV-1", client: "A", currency: "USD", issueDate: "2026-01-01", dueDate: "2026-02-01", status: "sent", paid: 0, items: [{ qty: 1, price: 50 }] },
    { id: "q", type: "quote", number: "QUO-1", client: "A", currency: "USD", issueDate: "2026-01-01", dueDate: "2026-02-01", status: "sent", paid: 0, items: [{ qty: 1, price: 50 }] },
  ];
  const out = L.bulkStatus(list, ["a", "q"], "paid");
  assert.equal(out[0].status, "paid");
  assert.equal(out[0].paid, 50);
  assert.equal(out[1], list[1]); // a quote does not take "paid"
  assert.equal(L.bulkStatus(list, ["q"], "accepted")[1].status, "accepted");
  assert.equal(list[0].status, "sent");
  assert.equal(L.bulkStatus(list, [], "paid")[0], list[0]);
});
test("recent activity: payments and issues newest first, drafts left out", () => {
  const list = [
    { id: "a", type: "invoice", number: "INV-1", client: "Acme", currency: "USD", issueDate: "2026-03-01", dueDate: "2026-03-15", status: "sent", paid: 20, payments: [{ date: "2026-03-10", amount: 20 }], items: [{ qty: 1, price: 50 }] },
    { id: "b", type: "invoice", number: "INV-2", client: "Bee", currency: "USD", issueDate: "2026-03-05", dueDate: "2026-03-19", status: "draft", paid: 0, payments: [], items: [{ qty: 1, price: 10 }] },
    { id: "c", type: "quote", number: "QUO-1", client: "Cee", currency: "USD", issueDate: "2026-03-02", dueDate: "2026-04-01", status: "sent", paid: 0, items: [{ qty: 1, price: 5 }] },
  ];
  const rows = L.recentActivity(list);
  assert.deepEqual(rows.map((r) => [r.kind, r.number]), [["payment", "INV-1"], ["quote", "QUO-1"], ["issued", "INV-1"]]);
  assert.equal(rows[0].amount, 20);
  assert.equal(rows[2].amount, 50);
  assert.equal(L.recentActivity(list, 1).length, 1);
});
test("tax presets are sorted, unique and within the tax field's range", () => {
  const p = L.TAX_PRESETS;
  assert.ok(p.length > 0);
  assert.deepEqual([...p].sort((a, b) => a - b), p);
  assert.equal(new Set(p).size, p.length);
  assert.ok(p.every((r) => r >= 0 && r < 100));
});
test("invoice numbering", () => {
  assert.equal(L.nextInvoiceNumber([]), "INV-0001");
  assert.equal(L.nextInvoiceNumber([{ number: "INV-0009" }, { number: "INV-0002" }]), "INV-0010");
});
test("free limit gating", () => {
  const three = [{ id: "a" }, { id: "b" }, { id: "c" }];
  assert.equal(L.canSave(three, false, null), false);
  assert.equal(L.canSave(three, false, "b"), true);
  assert.equal(L.canSave(three, true, null), true);
});
test("license keys", () => {
  const k = L.makeLicense("AB12", "CD34");
  assert.ok(L.validLicense(k));
  assert.ok(L.validLicense(k.toLowerCase()));
  assert.ok(!L.validLicense("PRO-AB12-CD34-0000"));
  assert.ok(!L.validLicense(""));
});
test("csv escapes quotes", () => {
  const csv = L.toCSV([{ number: "INV-1", client: 'A "B" Co', items: [{ qty: 1, price: 5 }], currency: "USD", status: "sent" }]);
  assert.match(csv, /"A ""B"" Co"/);
});
test("overdue", () => {
  const it = [{ qty: 1, price: 100 }];
  assert.ok(L.overdue({ status: "sent", items: it, dueDate: "2020-01-01" }, "2020-02-01"));
  assert.ok(!L.overdue({ status: "paid", items: it, dueDate: "2020-01-01" }, "2020-02-01"));
  assert.ok(!L.overdue({ status: "sent", items: it, paid: 100, dueDate: "2020-01-01" }, "2020-02-01"));
  assert.ok(!L.overdue({ status: "sent", type: "quote", items: it, dueDate: "2020-01-01" }, "2020-02-01"));
  assert.ok(!L.overdue({ status: "draft", items: it, dueDate: "2020-01-01" }, "2020-02-01"));
});

test("addPeriod clamps month ends", () => {
  assert.equal(L.addPeriod("2024-01-31", "monthly"), "2024-02-29");
  assert.equal(L.addPeriod("2024-12-15", "monthly"), "2025-01-15");
  assert.equal(L.addPeriod("2024-02-26", "weekly"), "2024-03-04");
});
test("runRecurring creates one draft per elapsed period", () => {
  const base = { id: "r", number: "INV-0001", client: "A", issueDate: "2024-01-01", dueDate: "2024-01-15",
    items: [{ qty: 1, price: 10 }], recur: "monthly", nextRun: "2024-02-01", status: "paid" };
  let n = 0;
  const { invoices, created } = L.runRecurring([base], "2024-03-05", () => "g" + ++n);
  assert.equal(created, 2);
  assert.equal(invoices.length, 3);
  const g = invoices.filter((i) => i.id.startsWith("g"));
  assert.deepEqual(g.map((i) => i.number).sort(), ["INV-0002", "INV-0003"]);
  assert.ok(g.every((i) => i.status === "draft" && !i.recur && i.dueDate === L.addDays(i.issueDate, 14)));
  assert.equal(invoices.find((i) => i.id === "r").nextRun, "2024-04-01");
  assert.equal(base.nextRun, "2024-02-01"); // input untouched
  assert.equal(L.runRecurring(invoices, "2024-03-05", () => "x").created, 0);
});

test("validInvoice rejects junk", () => {
  const ok = { id: "a", number: "INV-1", items: [], status: "draft", currency: "USD", issueDate: "2024-01-01", dueDate: "2024-01-02" };
  assert.ok(L.validInvoice(ok));
  assert.ok(!L.validInvoice({ ...ok, currency: "usd" }));
  assert.ok(!L.validInvoice({ ...ok, items: null }));
  assert.ok(!L.validInvoice(null));
});

const inv = (o) => ({ id: o.number, type: "invoice", client: "A", currency: "USD", status: "sent", paid: 0,
  issueDate: "2024-01-01", dueDate: "2024-01-15", items: [{ qty: 1, price: 100 }], taxRate: 10, ...o });

test("settle keeps status and paid consistent", () => {
  assert.equal(L.settle(inv({ status: "paid" })).paid, 110);
  assert.equal(L.settle(inv({ paid: 110 })).status, "paid");
  assert.equal(L.settle(inv({ paid: 999 })).paid, 110); // clamped
  assert.equal(L.settle(inv({ paid: -5 })).paid, 0);
  assert.equal(L.settle(inv({ paid: 50 })).status, "sent");
  assert.equal(L.balanceOf(inv({ paid: 50 })), 60);
  assert.equal(L.settle(inv({ type: "quote", paid: 40 })).paid, 0);
});
test("numbering is per document type", () => {
  const list = [{ number: "INV-0007" }, { number: "QUO-0002" }];
  assert.equal(L.nextNumber(list, "invoice"), "INV-0008");
  assert.equal(L.nextNumber(list, "quote"), "QUO-0003");
  assert.equal(L.nextNumber([], "quote"), "QUO-0001");
});
test("convertQuote creates a fresh draft invoice", () => {
  const q = inv({ number: "QUO-0001", type: "quote", status: "accepted", paid: 0 });
  const c = L.convertQuote(q, [q], () => "new", "2024-05-01");
  assert.equal(c.type, "invoice"); assert.equal(c.number, "INV-0001"); assert.equal(c.status, "draft");
  assert.equal(c.dueDate, "2024-05-15"); assert.equal(c.convertedFrom, "QUO-0001");
  c.items[0].price = 1; assert.equal(q.items[0].price, 100); // deep copy
});
test("summarize and byClient ignore quotes and drafts, split by currency", () => {
  const list = [
    inv({ number: "INV-1", paid: 50 }),                       // balance 60, overdue
    inv({ number: "INV-2", dueDate: "2099-01-01" }),          // balance 110, not overdue
    inv({ number: "INV-3", status: "paid", paid: 110 }),
    inv({ number: "INV-4", status: "draft" }),
    inv({ number: "QUO-1", type: "quote" }),
    inv({ number: "INV-5", currency: "KRW", items: [{ qty: 1, price: 1000 }], taxRate: 0, client: "B" }),
  ];
  const s = L.summarize(list, "2024-06-01");
  const usd = s.find((x) => x.currency === "USD");
  assert.deepEqual(usd, { currency: "USD", outstanding: 170, overdue: 60, collected: 160 });
  assert.equal(s.find((x) => x.currency === "KRW").overdue, 1000);
  const c = L.byClient(list);
  assert.equal(c.length, 2);
  const a = c.find((x) => x.client === "A");
  assert.deepEqual([a.count, a.billed, a.paid, a.balance], [3, 330, 160, 170]);
});
test("csv has type and balance", () => {
  const csv = L.toCSV([inv({ number: "INV-1", paid: 10 })]);
  assert.match(csv, /^"?type"?,/);
  assert.match(csv, /"invoice","INV-1".*"110","0","10","100"/);
});

test("late fee grows per started month and is idempotent", () => {
  const o = inv({ number: "INV-9", taxRate: 0, dueDate: "2024-01-15" }); // 100 owed
  assert.equal(L.lateFeeAmount(o, "2024-01-15", 2), 0);
  assert.equal(L.lateFeeAmount(o, "2024-01-16", 2), 2);
  assert.equal(L.lateFeeAmount(o, "2024-02-14", 2), 2);   // 30 days = one month
  assert.equal(L.lateFeeAmount(o, "2024-02-15", 2), 4);   // 31 days = two
  assert.equal(L.lateFeeAmount({ ...o, paid: 100 }, "2025-01-01", 2), 0);
  const once = L.applyLateFee(o, "2024-03-01", 2, "Late fee");
  const twice = L.applyLateFee(once, "2024-03-01", 2, "Late fee");
  assert.deepEqual(once.items, twice.items);
  assert.equal(once.items.filter((x) => x.lateFee).length, 1);
  assert.equal(L.applyLateFee(o, "2024-01-01", 2, "x").items.length, 1); // not late yet
});
test("ageing buckets", () => {
  const list = [
    inv({ number: "A", taxRate: 0, dueDate: "2024-05-20" }),  // 12 days
    inv({ number: "B", taxRate: 0, dueDate: "2024-04-01" }),  // 61 days
    inv({ number: "C", taxRate: 0, dueDate: "2023-01-01" }),  // very old
    inv({ number: "D", taxRate: 0, dueDate: "2024-05-20", status: "paid", paid: 100 }),
  ];
  assert.deepEqual(L.ageing(list, "2024-06-01"), [{ currency: "USD", d30: 100, d60: 0, d90: 100, older: 100 }]);
});
test("tracked time becomes invoice lines", () => {
  const e = [
    { client: "A", desc: "Design", secs: 5400 }, { client: "A", desc: "Calls", secs: 1800 },
    { client: "B", desc: "x", secs: 3600 }, { client: "A", desc: "old", secs: 3600, billed: true },
  ];
  assert.deepEqual(L.unbilledByClient(e), [{ client: "A", secs: 7200, count: 2 }, { client: "B", secs: 3600, count: 1 }]);
  assert.deepEqual(L.timeItems(e, "A", 80), [{ desc: "Design", qty: 1.5, price: 80 }, { desc: "Calls", qty: 0.5, price: 80 }]);
});

test("filterInvoices searches and filters", () => {
  const base = { type: "invoice", from: "Me", currency: "USD", issueDate: "2026-10-01", dueDate: "2026-10-15", taxRate: 0, discount: 0, paid: 0, notes: "", items: [{ desc: "Logo design", qty: 1, price: 100 }] };
  const list = [
    { ...base, id: "1", number: "INV-0001", client: "Acme", status: "sent" },
    { ...base, id: "2", number: "INV-0002", client: "Beta Co", status: "paid", paid: 100 },
    { ...base, id: "3", number: "INV-0003", client: "Gamma", status: "draft", dueDate: "2026-09-01" },
    { ...base, id: "4", type: "quote", number: "QUO-0001", client: "Acme", status: "draft" },
  ];
  const ids = (o) => L.filterInvoices(list, o, "2026-10-20").map((i) => i.id).join();
  assert.equal(ids({}), "1,2,3,4");
  assert.equal(ids({ f: "unpaid" }), "1");
  assert.equal(ids({ f: "overdue" }), "1");
  assert.equal(ids({ f: "paid" }), "2");
  assert.equal(ids({ f: "quotes" }), "4");
  assert.equal(ids({ q: "acme" }), "1,4");
  assert.equal(ids({ q: " LOGO " }), "1,2,3,4");
  assert.equal(ids({ q: "beta", f: "paid" }), "2");
  assert.equal(ids({ q: "zzz" }), "");
  assert.equal(ids({ f: "nonsense" }), "1,2,3,4");
});

const base = () => ({ id: "p", type: "invoice", number: "INV-0001", client: "A", currency: "USD", issueDate: "2026-10-01", dueDate: "2026-10-15", status: "sent", paid: 0, taxRate: 0, discount: 0, items: [{ desc: "x", qty: 1, price: 100 }] });
test("recordPayment logs a dated part-payment and settles", () => {
  let inv = L.recordPayment(base(), "2026-10-05", 30);
  assert.equal(inv.paid, 30);
  assert.deepEqual(inv.payments, [{ date: "2026-10-05", amount: 30 }]);
  assert.equal(inv.status, "sent");
  inv = L.recordPayment(inv, "2026-10-09", 500); // clamped to the balance
  assert.equal(inv.paid, 100);
  assert.equal(inv.status, "paid");
  assert.equal(inv.payments[1].amount, 70);
});
test("recordPayment ignores bad input, quotes and keeps a typed paid amount", () => {
  const b = base();
  assert.equal(L.recordPayment(b, "nope", 10), b);
  assert.equal(L.recordPayment(b, "2026-10-05", 0), b);
  assert.equal(L.recordPayment({ ...b, type: "quote" }, "2026-10-05", 10).paid, 0);
  const typed = L.recordPayment({ ...b, paid: 40 }, "2026-10-05", 10);
  assert.equal(typed.paid, 50);
  assert.equal(L.recordPayment({ ...b, status: "draft" }, "2026-10-05", 10).status, "sent");
});
test("removePayment lowers paid and reopens a paid invoice", () => {
  const paid = L.recordPayment(L.recordPayment(base(), "2026-10-05", 30), "2026-10-09", 70);
  const back = L.removePayment(paid, 1);
  assert.equal(back.paid, 30);
  assert.equal(back.status, "sent");
  assert.equal(L.removePayment(back, 9), back);
});
test("paymentStats: average days, on-time share, slowest client first", () => {
  const a = L.recordPayment(base(), "2026-10-11", 100); // 10 days, on time
  const b = L.recordPayment({ ...base(), id: "q", client: "B", dueDate: "2026-10-05" }, "2026-10-21", 100); // 20 days, late
  const open = L.recordPayment(base(), "2026-10-02", 10); // not fully paid: ignored
  const legacy = { ...base(), status: "paid", paid: 100 }; // no dated payments: ignored
  const s = L.paymentStats([a, b, open, legacy, { ...base(), type: "quote" }]);
  assert.equal(s.count, 2);
  assert.equal(s.avgDays, 15);
  assert.equal(s.onTimePct, 50);
  assert.deepEqual(s.byClient.map((c) => c.client), ["B", "A"]);
  assert.deepEqual(L.paymentStats([]), { count: 0, avgDays: 0, onTimePct: 0, byClient: [] });
});
test("receivedByMonth uses the payment date, one currency", () => {
  const a = L.recordPayment(base(), "2026-10-05", 40);
  const b = L.recordPayment({ ...base(), id: "z", currency: "EUR" }, "2026-10-06", 99);
  const c = L.recordPayment({ ...base(), id: "y" }, "2026-09-30", 10);
  const r = L.receivedByMonth([a, b, c], "2026-10-20", 3, "USD");
  assert.deepEqual(r, [{ month: "2026-08", received: 0 }, { month: "2026-09", received: 10 }, { month: "2026-10", received: 40 }]);
});
test("recurring and quote conversion start with an empty payment log", () => {
  const rec = { ...base(), recur: "weekly", nextRun: "2026-10-08", payments: [{ date: "2026-10-02", amount: 5 }], paid: 5 };
  const r = L.runRecurring([rec], "2026-10-09", () => "n1");
  assert.deepEqual(r.invoices[0].payments, []);
  assert.deepEqual(L.settle({ ...base(), type: "quote", payments: [{ date: "2026-10-02", amount: 5 }] }).payments, []);
});

test("upcomingRecurring projects runs inside the window, sorted", () => {
  const w = { ...base(), id: "w", client: "Weekly Co", recur: "weekly", nextRun: "2026-11-03" };
  const m = { ...base(), id: "m", client: "Monthly Co", currency: "EUR", recur: "monthly", nextRun: "2026-11-30" };
  const none = { ...base(), id: "n" };
  const rows = L.upcomingRecurring([w, m, none, { ...w, id: "q", type: "quote" }], "2026-11-01", 1);
  assert.deepEqual(rows.filter((r) => r.client === "Weekly Co").map((r) => r.date), ["2026-11-03", "2026-11-10", "2026-11-17", "2026-11-24", "2026-12-01"]);
  assert.deepEqual(rows.filter((r) => r.client === "Monthly Co").map((r) => r.date), ["2026-11-30"]);
  assert.deepEqual(rows.map((r) => r.date), [...rows.map((r) => r.date)].sort());
  assert.deepEqual(L.upcomingTotals(rows), { USD: 500, EUR: 100 });
});
test("upcomingRecurring skips runs before today and respects the cap", () => {
  const w = { ...base(), recur: "weekly", nextRun: "2026-10-01" };
  assert.equal(L.upcomingRecurring([w], "2026-11-01", 1)[0].date >= "2026-11-01", true);
  assert.ok(L.upcomingRecurring([{ ...w, nextRun: "2026-11-01" }], "2026-11-01", 24, 3).length <= 3);
});

test("paymentsCSV lists dated payments, oldest first, and defuses formulas", () => {
  const a = L.recordPayment({ ...base(), number: "INV-0002", client: "=HYPERLINK(\"x\")" }, "2026-10-09", 25);
  const b = L.recordPayment(base(), "2026-10-05", 40);
  const csv = L.paymentsCSV([a, b, { ...base(), type: "quote", payments: [{ date: "2026-01-01", amount: 1 }] }, { ...base(), status: "paid", paid: 100 }]).split("\n");
  assert.equal(csv.length, 3);
  assert.match(csv[1], /^"2026-10-05","INV-0001","A","USD","40"/);
  assert.match(csv[2], /^"2026-10-09","INV-0002","'=HYPERLINK/);
});

test("withholding tax lowers what is payable, not the total", () => {
  const t = L.calcTotals([{ qty: 1, price: 1000 }], 10, 0, 3.3);
  assert.deepEqual([t.total, t.withholding, t.payable], [1100, 33, 1067]);
  assert.equal(L.calcTotals([{ qty: 1, price: 100 }], 0, 0, 999).withholding, 50); // capped at 50%
  assert.equal(L.calcTotals([{ qty: 1, price: 100 }], 0, 0, -5).withholding, 0);
  const i = inv({ items: [{ qty: 1, price: 1000 }], taxRate: 0, withholdingRate: 3.3, status: "sent" });
  assert.equal(L.balanceOf(i), 967);
  const paid = L.settle({ ...i, paid: 967 });
  assert.equal(paid.status, "paid");
  assert.equal(L.balanceOf(paid), 0);
  assert.equal(L.grossPaidOf(paid), 1000);   // counts as fully received income
  assert.equal(L.grossPaidOf({ ...i, paid: 483.5 }), 500);
  assert.equal(L.grossPaidOf(inv({ items: [{ qty: 1, price: 100 }], taxRate: 0, paid: 40 })), 40); // no withholding: unchanged
});
test("year summary reports tax withheld by clients", () => {
  const i = inv({ items: [{ qty: 1, price: 1000 }], taxRate: 0, withholdingRate: 3.3, status: "sent", issueDate: "2024-03-01", paid: 967 });
  const s = L.yearSummary([i], [], "2024", "USD");
  assert.deepEqual([s.income, s.withheld], [1000, 33]);
});
test("expected cash-in uses each client's habit, else the due date", () => {
  const mk = (o) => inv({ items: [{ qty: 1, price: 100 }], taxRate: 0, status: "sent", ...o });
  const paid = mk({ id: "p1", client: "Slow", issueDate: "2024-01-01", dueDate: "2024-01-15", paid: 100, status: "paid", payments: [{ date: "2024-02-10", amount: 100 }] });
  const open = mk({ id: "o1", client: "Slow", number: "INV-2", issueDate: "2024-05-01", dueDate: "2024-05-15" });
  const fresh = mk({ id: "o2", client: "New", number: "INV-3", issueDate: "2024-05-01", dueDate: "2024-05-20" });
  const c = L.expectedCash([paid, open, fresh], "2024-05-10", "USD", 3);
  const by = Object.fromEntries(c.rows.map((r) => [r.id, r]));
  assert.equal(by.o1.expected, "2024-06-10");  // 40 days after issue
  assert.equal(by.o1.slow, true);
  assert.equal(by.o2.expected, "2024-05-20");
  assert.equal(c.total, 200);
  assert.deepEqual(c.byMonth.map((m) => m.amount), [100, 100, 0]);
  assert.equal(L.clientHabits([paid]).slow.onTimePct, 0);
});

test("client names like 'constructor' cannot break habits or cash-in", () => {
  for (const name of ["constructor", "toString", "__proto__"]) {
    const o = inv({ id: "z", client: name, items: [{ qty: 1, price: 50 }], taxRate: 0, issueDate: "2024-05-01", dueDate: "2024-05-15" });
    assert.doesNotThrow(() => L.expectedCash([o], "2024-05-10", "USD", 3));
    assert.equal(L.expectedCash([o], "2024-05-10", "USD", 3).rows[0].expected, "2024-05-15");
  }
});
test("client ledger and dashboard reconcile with withholding", () => {
  const o = inv({ number: "W", client: "K", items: [{ qty: 1, price: 100 }], taxRate: 0, withholdingRate: 10, paid: 50 });
  const c = L.byClient([o])[0];
  assert.deepEqual([c.billed, c.withheld, c.paid, c.balance], [90, 10, 50, 40]);
  assert.equal(L.summarize([o], "2024-01-01")[0].outstanding, 40);
  assert.equal(L.upcomingRecurring([{ ...o, recur: "monthly", nextRun: "2024-06-01" }], "2024-05-20", 1)[0].amount, 90);
  assert.match(L.toCSV([o]), /"100","10","50","40"/);
});

test("dashboard cash plus outstanding equals what the client owes you (payable)", () => {
  const o = inv({ number: "W2", client: "K", items: [{ qty: 1, price: 100 }], taxRate: 0, withholdingRate: 10, paid: 50 });
  const s = L.summarize([o], "2024-01-01")[0];
  assert.equal(s.collected + s.outstanding, L.payableOf(o));
  assert.equal(s.collected + s.outstanding + L.withheldOf(o), L.totalOf(o));
});

test("monthLabel keeps the year and month, never a day", () => {
  assert.match(L.monthLabel("2026-11", "en-US"), /Nov.*2026/);
  assert.match(L.monthLabel("2026-11", "es-ES"), /nov.*2026/i);
  assert.match(L.monthLabel("2026-11", "ko-KR"), /2026.*11/);
  assert.equal(L.monthLabel("bad"), "bad");
});

test("reminder habit lookup works for a client with a single paid invoice and reports on-time share", () => {
  const p = inv({ id: "h1", client: "Zed", items: [{ qty: 1, price: 10 }], taxRate: 0, issueDate: "2024-01-01", dueDate: "2024-01-31", paid: 10, status: "paid", payments: [{ date: "2024-01-20", amount: 10 }] });
  assert.deepEqual(L.clientHabits([p]).zed, { count: 1, avgDays: 19, onTimePct: 100 });
});

test("habits treat 'Acme' and ' acme ' as one client", () => {
  const mk = (id, client, issue, on) => inv({ id, client, items: [{ qty: 1, price: 10 }], taxRate: 0, issueDate: issue, dueDate: issue, paid: 10, status: "paid", payments: [{ date: on, amount: 10 }] });
  const h = L.clientHabits([mk("a", "Acme", "2024-01-01", "2024-01-11"), mk("b", " acme ", "2024-02-01", "2024-02-21")]);
  assert.deepEqual(h.acme, { count: 2, avgDays: 15, onTimePct: 0 });
  const open = inv({ id: "c", client: "ACME", items: [{ qty: 1, price: 10 }], taxRate: 0, issueDate: "2024-03-01", dueDate: "2024-03-05" });
  assert.equal(L.expectedCash([mk("a", "Acme", "2024-01-01", "2024-01-11"), open], "2024-03-02", "USD", 1).rows[0].basis, "history");
});

test("client statement: ledger rows, totals, skips drafts and quotes", () => {
  const mk = (o) => ({ id: o.number, client: "Acme", currency: "USD", type: "invoice", status: "sent", issueDate: "2026-01-01", dueDate: "2026-01-15", items: [{ qty: 1, price: 1000 }], taxRate: 0, discount: 0, paid: 0, payments: [], ...o });
  const list = [
    mk({ number: "INV-0002", issueDate: "2026-02-01", dueDate: "2026-02-15", withholdingRate: 3.3 }),
    mk({ number: "INV-0001", status: "paid", paid: 1000, payments: [{ date: "2026-01-10", amount: 1000 }] }),
    mk({ number: "INV-0003", status: "draft" }),
    mk({ number: "QUO-0001", type: "quote" }),
    mk({ number: "INV-0004", client: "Other" }),
    mk({ number: "INV-0005", currency: "EUR" }),
  ];
  const s = L.statement(list, "Acme", "USD", "2026-03-01");
  assert.deepEqual(s.rows.map((r) => r.number), ["INV-0001", "INV-0002"]);
  assert.equal(s.totals.billed, 2000);
  assert.equal(s.totals.withheld, 33);
  assert.equal(s.totals.paid, 1000);
  assert.equal(s.totals.balance, 967);
  assert.equal(s.totals.overdue, 967);
  assert.equal(s.rows[0].payments[0].date, "2026-01-10");
  assert.equal(L.statementCSV(s).split("\n").length, 3);
  assert.equal(L.statement([], "x", "USD").rows.length, 0);
});

test("csv neutralises spreadsheet formulas in text cells", () => {
  const csv = L.toCSV([{ number: "INV-1", client: '=HYPERLINK("http://x","go")', items: [{ qty: 1, price: 5 }], currency: "USD", status: "sent" }]);
  assert.match(csv, /"'=HYPERLINK/);
  assert.doesNotMatch(csv, /^[^"]*,=/m);
  const st = L.statement([{ number: "+1", client: "@A", currency: "USD", issueDate: "2026-01-01", dueDate: "2026-02-01", status: "sent", items: [{ qty: 1, price: 5 }] }], "@A", "USD", "2026-03-01");
  assert.match(L.statementCSV(st), /"'\+1"/);
});
test("recurring invoices number from invoices, not quotes", () => {
  const quote = { id: "q", type: "quote", number: "QUO-0009", issueDate: "2024-01-01", dueDate: "2024-01-15", items: [], currency: "USD", status: "sent", paid: 0 };
  const rec = { id: "r", number: "INV-0001", client: "A", currency: "USD", issueDate: "2024-01-01", dueDate: "2024-01-31", status: "sent", paid: 0, items: [{ qty: 1, price: 5 }], recur: "monthly", nextRun: "2024-02-01" };
  let n = 0;
  const { invoices } = L.runRecurring([quote, rec], "2024-02-01", () => "g" + ++n);
  const made = invoices.find((i) => i.id !== "q" && i.id !== "r");
  assert.equal(made.number, "INV-0002");
});

test("csv neutralises spreadsheet formulas in text cells", () => {
  const csv = L.toCSV([{ number: "INV-1", client: '=HYPERLINK("http://x","go")', items: [{ qty: 1, price: 5 }], currency: "USD", status: "sent" }]);
  assert.match(csv, /"'=HYPERLINK/);
  const st = L.statement([{ number: "+1", client: "@A", currency: "USD", issueDate: "2026-01-01", dueDate: "2026-02-01", status: "sent", items: [{ qty: 1, price: 5 }] }], "@A", "USD", "2026-03-01");
  assert.match(L.statementCSV(st), /"'\+1"/);
});
test("recurring invoices number from invoices, not quotes", () => {
  const quote = { id: "q", type: "quote", number: "QUO-0009", issueDate: "2024-01-01", dueDate: "2024-01-15", items: [], currency: "USD", status: "sent", paid: 0 };
  const rec = { id: "r", number: "INV-0001", client: "A", currency: "USD", issueDate: "2024-01-01", dueDate: "2024-01-31", status: "sent", paid: 0, items: [{ qty: 1, price: 5 }], recur: "monthly", nextRun: "2024-02-01" };
  let n = 0;
  const { invoices } = L.runRecurring([quote, rec], "2024-02-01", () => "g" + ++n);
  const made = invoices.find((i) => i.id !== "q" && i.id !== "r");
  assert.equal(made.number, "INV-0002");
});
