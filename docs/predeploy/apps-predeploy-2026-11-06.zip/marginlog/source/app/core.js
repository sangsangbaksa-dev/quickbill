/* Marginlog core: pure functions, no DOM. Works in the browser (window.MLCore) and in Node tests. */
(function (root) {
  'use strict';
  var KINDS = {
    noise: { tags: ['music', 'voices', 'bass', 'stomping', 'party', 'construction', 'pets'], quiet: [22, 7], steps: ['talk', 'written', 'complaint', 'mediation', 'authority'] },
    landlord: { tags: ['repair', 'mould', 'heating', 'water', 'entry', 'rent', 'deposit'], quiet: null, steps: ['talk', 'written', 'complaint', 'mediation', 'legal'] },
    work: { tags: ['remarks', 'workload', 'exclusion', 'schedule', 'pay', 'threat'], quiet: null, steps: ['talk', 'written', 'complaint', 'mediation', 'legal'] },
    vendor: { tags: ['missed deadline', 'poor work', 'no show', 'extra charge', 'no reply'], quiet: null, steps: ['written', 'complaint', 'mediation', 'legal'] },
    other: { tags: [], quiet: null, steps: ['talk', 'written', 'complaint', 'mediation', 'legal'] }
  };
  var STEP_KINDS = ['talk', 'written', 'complaint', 'mediation', 'authority', 'legal'];
  var LATE_HOURS = 48;

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function uid() { return Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4); }
  function toLocalStamp(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes()); }
  function parseAt(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})$/.exec(String(s || ''));
    if (!m) return null;
    var y = +m[1], mo = +m[2], d = +m[3], h = +m[4], mi = +m[5];
    if (mo < 1 || mo > 12 || d < 1 || d > 31 || h > 23 || mi > 59) return null;
    var dt = new Date(y, mo - 1, d, h, mi);
    if (dt.getMonth() !== mo - 1) return null;
    return { y: y, m: mo, d: d, h: h, mi: mi, dow: (dt.getDay() + 6) % 7, ts: dt.getTime(), day: m[1] + '-' + m[2] + '-' + m[3] };
  }
  function dayNum(stamp) { var p = parseAt(stamp); return p ? Math.floor(Date.UTC(p.y, p.m - 1, p.d) / 864e5) : null; }

  /* ---------- sealing ---------- */
  async function sha256Hex(str) {
    var buf = await root.crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
    var a = new Uint8Array(buf), out = '';
    for (var i = 0; i < a.length; i++) out += (a[i] < 16 ? '0' : '') + a[i].toString(16);
    return out;
  }
  function payload(prev, e) {
    return JSON.stringify([prev || '', e.id, e.type, e.ref || '', e.at, e.rec, e.text, e.sev || 0, e.dur || 0, e.tags || [], e.witness || '', (e.photos || []).map(function (p) { return p.h; }), !!e.reported]);
  }
  async function seal(prev, fields) {
    var e = {
      id: fields.id || uid(), type: fields.type || 'event', ref: fields.ref || '', at: fields.at, rec: fields.rec,
      text: String(fields.text || '').slice(0, 4000), sev: clampInt(fields.sev, 0, 5), dur: clampInt(fields.dur, 0, 14400),
      tags: cleanTags(fields.tags), witness: String(fields.witness || '').slice(0, 200), photos: (fields.photos || []).slice(0, 6).map(function (p) { return { id: String(p.id), h: String(p.h) }; }), reported: !!fields.reported
    };
    e.prev = prev || '';
    e.hash = await sha256Hex(payload(prev, e));
    return e;
  }
  async function verifyChain(entries, cp) {
    var prev = '';
    for (var i = 0; i < entries.length; i++) {
      var e = entries[i];
      if (e.prev !== prev) return { ok: false, bad: i };
      if (await sha256Hex(payload(prev, e)) !== e.hash) return { ok: false, bad: i };
      prev = e.hash;
    }
    if (cp && cp.n) {
      if (entries.length < cp.n) return { ok: false, bad: entries.length, truncated: true };
      if (entries[cp.n - 1].hash !== cp.head) return { ok: false, bad: cp.n - 1 };
    }
    return { ok: true, bad: -1, head: prev, n: entries.length };
  }
  function clampInt(v, lo, hi) { v = Math.round(Number(v)); if (!isFinite(v)) v = lo; return Math.max(lo, Math.min(hi, v)); }
  function cleanTags(t) {
    var seen = {}, out = [];
    (Array.isArray(t) ? t : String(t || '').split(',')).forEach(function (x) {
      x = String(x).trim().toLowerCase().slice(0, 24);
      if (x && !seen[x] && out.length < 8) { seen[x] = 1; out.push(x); }
    });
    return out;
  }

  /* ---------- views over the chain ---------- */
  function voidedIds(entries) { var v = {}; entries.forEach(function (e) { if (e.type === 'void') v[e.ref] = e; }); return v; }
  function events(entries) { var v = voidedIds(entries); return entries.filter(function (e) { return e.type === 'event' && !v[e.id]; }); }
  function addenda(entries, id) { return entries.filter(function (e) { return e.type === 'note' && e.ref === id; }); }
  function isLate(e) { var p = parseAt(e.at); return !!p && e.rec - p.ts > LATE_HOURS * 36e5; }
  function inQuiet(h, q) { if (!q) return false; var a = q[0], b = q[1]; return a === b ? false : (a < b ? h >= a && h < b : h >= a || h < b); }

  function heatmap(evs) {
    var g = []; for (var r = 0; r < 7; r++) { g.push(new Array(24).fill(0)); }
    var max = 0;
    evs.forEach(function (e) { var p = parseAt(e.at); if (p) { g[p.dow][p.h]++; if (g[p.dow][p.h] > max) max = g[p.dow][p.h]; } });
    return { grid: g, max: max };
  }
  function weekly(evs, nowTs, weeks) {
    weeks = weeks || 8; var out = [], i, now = new Date(nowTs);
    var monDay = Math.floor(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / 864e5) - ((now.getDay() + 6) % 7);
    for (i = weeks - 1; i >= 0; i--) { var dd = monDay - i * 7, u = new Date(dd * 864e5); out.push({ start: new Date(u.getUTCFullYear(), u.getUTCMonth(), u.getUTCDate()).getTime(), day: dd, n: 0, sev: 0 }); }
    evs.forEach(function (e) {
      var dn = dayNum(e.at); if (dn == null) return;
      var idx = Math.floor((dn - out[0].day) / 7);
      if (idx >= 0 && idx < weeks) { out[idx].n++; out[idx].sev += e.sev || 0; }
    });
    return out;
  }
  function topBand(evs) {
    if (evs.length < 5) return null;
    var dow = new Array(7).fill(0), hr = new Array(24).fill(0);
    evs.forEach(function (e) { var p = parseAt(e.at); if (p) { dow[p.dow]++; hr[p.h]++; } });
    var bestD = 0, i; for (i = 1; i < 7; i++) if (dow[i] > dow[bestD]) bestD = i;
    var bestH = 0, bestS = -1;
    for (i = 0; i < 24; i++) { var s = hr[i] + hr[(i + 1) % 24] + hr[(i + 2) % 24]; if (s > bestS) { bestS = s; bestH = i; } }
    return { dow: bestD, dowShare: Math.round(100 * dow[bestD] / evs.length), from: bestH, to: (bestH + 3) % 24, hourShare: Math.round(100 * bestS / evs.length) };
  }
  function stats(c, nowTs) {
    var evs = events(c.entries), n = evs.length, st = { total: n, last30: 0, prev30: 0, avgSev: 0, minutes: 0, quiet: 0, late: 0, sinceDays: null, longestGap: 0, trend: 'flat', first: null, last: null };
    if (!n) return st;
    var sev = 0, sevN = 0, days = [], now = new Date(nowTs), todayN = Math.floor(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / 864e5);
    evs.forEach(function (e) {
      var p = parseAt(e.at); if (!p) return;
      var dn = dayNum(e.at), ago = todayN - dn;
      if (ago >= 0 && ago < 30) st.last30++; else if (ago >= 30 && ago < 60) st.prev30++;
      if (e.sev) { sev += e.sev; sevN++; }
      st.minutes += e.dur || 0;
      if (inQuiet(p.h, c.quiet)) st.quiet++;
      if (isLate(e)) st.late++;
      days.push(dn);
    });
    st.avgSev = sevN ? Math.round(10 * sev / sevN) / 10 : 0;
    days.sort(function (a, b) { return a - b; });
    st.first = evs.reduce(function (m, e) { return !m || e.at < m ? e.at : m; }, null);
    st.last = evs.reduce(function (m, e) { return !m || e.at > m ? e.at : m; }, null);
    st.sinceDays = Math.max(0, todayN - days[days.length - 1]);
    for (var i = 1; i < days.length; i++) st.longestGap = Math.max(st.longestGap, days[i] - days[i - 1] - 1);
    if (st.last30 > st.prev30 + 1 || (st.prev30 === 0 && st.last30 >= 3)) st.trend = 'up';
    else if (st.prev30 > st.last30 + 1) st.trend = 'down';
    return st;
  }

  /* ---------- evidence strength ---------- */
  function strength(e) {
    var s = 0, tips = [];
    if ((e.text || '').trim().length >= 40) s += 25; else tips.push('text');
    if (e.dur > 0) s += 15; else tips.push('dur');
    if (e.witness) s += 15; else tips.push('witness');
    if (e.photos && e.photos.length) s += 20; else tips.push('photo');
    if (!isLate(e) && e.rec - (parseAt(e.at) || { ts: e.rec }).ts < 24 * 36e5) s += 15; else tips.push('timely');
    if (e.tags && e.tags.length) s += 10; else tips.push('tag');
    return { score: s, tips: tips };
  }
  function caseStrength(c) {
    var evs = events(c.entries); if (!evs.length) return 0;
    return Math.round(evs.reduce(function (a, e) { return a + strength(e).score; }, 0) / evs.length);
  }

  /* ---------- escalation ladder ---------- */
  function ladder(c) { return (KINDS[c.kind] || KINDS.other).steps; }
  function suggestNext(c, nowTs) {
    var done = {}, steps = c.steps || [], evs = events(c.entries);
    steps.forEach(function (s) { done[s.kind] = (done[s.kind] || 0) + 1; });
    var order = ladder(c), st = stats(c, nowTs), hi = evs.filter(function (e) { return e.sev >= 4; }).length;
    if (!evs.length) return { key: 'none' };
    var pending = steps.filter(function (s) { return s.due && !s.done; }).sort(function (a, b) { return a.due < b.due ? -1 : 1; });
    var today = toLocalStamp(new Date(nowTs)).slice(0, 10);
    if (pending.length && pending[0].due < today) return { key: 'overdue', step: pending[0] };
    if (pending.length) return { key: 'waiting', step: pending[0] };
    for (var i = 0; i < order.length; i++) {
      var k = order[i];
      if (done[k]) continue;
      if (k === 'talk') { if (done.written || done.complaint) continue; return { key: 'talk', kind: k }; }
      if (k === 'written') { if (done.complaint) continue; return evs.length >= 3 || hi >= 1 ? { key: 'written', kind: k } : { key: 'keep' }; }
      if (k === 'complaint') return st.last30 >= 2 || hi >= 2 ? { key: 'complaint', kind: k } : { key: 'keep' };
      return st.last30 >= 2 ? { key: 'next', kind: k } : { key: 'keep' };
    }
    return order.every(function (k) { return done[k]; }) ? { key: 'exhausted' } : { key: 'keep' };
  }

  /* ---------- exports ---------- */
  function csvCell(v) {
    v = String(v == null ? '' : v);
    if (/^[=+\-@\t\r]/.test(v)) v = "'" + v;
    return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }
  function toCsv(c) {
    var rows = [['when', 'recorded', 'late', 'severity', 'minutes', 'tags', 'witness', 'reported', 'text', 'notes', 'voided', 'hash']], vd = voidedIds(c.entries);
    c.entries.filter(function (e) { return e.type === 'event'; }).slice().sort(function (a, b) { return a.at < b.at ? -1 : 1; }).forEach(function (e) {
      rows.push([e.at.replace('T', ' '), new Date(e.rec).toISOString(), isLate(e) ? 'yes' : '', e.sev || '', e.dur || '', e.tags.join(' '), e.witness, e.reported ? 'yes' : '', e.text, addenda(c.entries, e.id).map(function (n) { return n.text; }).join(' | '), vd[e.id] ? vd[e.id].text : '', e.hash.slice(0, 16)]);
    });
    return rows.map(function (r) { return r.map(csvCell).join(','); }).join('\r\n') + '\r\n';
  }
  function reportMarkdown(c, L, nowTs, chain) {
    var st = stats(c, nowTs), vd = voidedIds(c.entries), evs = events(c.entries), all = c.entries.filter(function (e) { return e.type === 'event'; }).slice().sort(function (a, b) { return a.at < b.at ? -1 : 1; });
    var out = ['# ' + c.name, ''];
    if (c.counterpart) out.push(L.counterpart + ': ' + c.counterpart);
    if (c.goal) out.push(L.goal + ': ' + c.goal);
    out.push(L.generated + ': ' + toLocalStamp(new Date(nowTs)).replace('T', ' '), '');
    out.push('## ' + L.summary, '');
    out.push('- ' + L.total + ': ' + st.total + (st.first ? ' (' + st.first.slice(0, 10) + ' – ' + st.last.slice(0, 10) + ')' : ''));
    out.push('- ' + L.last30 + ': ' + st.last30 + ' (' + L.prev30 + ': ' + st.prev30 + ')');
    if (st.avgSev) out.push('- ' + L.avgSev + ': ' + st.avgSev + ' / 5');
    if (st.minutes) out.push('- ' + L.minutes + ': ' + st.minutes);
    if (c.quiet) out.push('- ' + L.quietHits + ' (' + pad(c.quiet[0]) + ':00–' + pad(c.quiet[1]) + ':00): ' + st.quiet);
    var nv = all.length - evs.length; if (nv) out.push('- ' + L.voidedBadge + ': ' + nv);
    var tb = topBand(evs); if (tb) out.push('- ' + L.pattern + ': ' + L.days[tb.dow] + ' ' + tb.dowShare + '%, ' + pad(tb.from) + ':00–' + pad(tb.to) + ':00 ' + tb.hourShare + '%');
    out.push('', '## ' + L.timeline, '');
    all.forEach(function (e, i) {
      var isV = !!vd[e.id], tags = e.tags.length ? ' [' + e.tags.join(', ') + ']' : '';
      out.push((i + 1) + '. **' + e.at.replace('T', ' ') + '**' + (e.sev ? ' · ' + L.sev + ' ' + e.sev + '/5' : '') + (e.dur ? ' · ' + e.dur + ' min' : '') + tags + (isLate(e) ? ' · ' + L.late : '') + (isV ? ' · ' + L.voidedBadge.toUpperCase() : ''));
      out.push('   ' + e.text.replace(/\n+/g, ' '));
      out.push('   ' + L.recordedAt + ' ' + toLocalStamp(new Date(e.rec)).replace('T', ' ') + ' · #' + e.hash.slice(0, 16));
      if (e.witness) out.push('   ' + L.witness + ': ' + e.witness);
      if (e.photos.length) out.push('   ' + L.photos + ': ' + e.photos.length);
      if (e.reported) out.push('   ' + L.reportedTo);
      if (isV) out.push('   ' + L.voidedBadge.toUpperCase() + ' (' + vd[e.id].at.replace('T', ' ') + '): ' + vd[e.id].text.replace(/\n+/g, ' '));
      addenda(c.entries, e.id).forEach(function (n) { out.push('   + ' + n.at.replace('T', ' ') + ': ' + n.text.replace(/\n+/g, ' ')); });
    });
    if ((c.steps || []).length) {
      out.push('', '## ' + L.steps, '');
      c.steps.slice().sort(function (a, b) { return a.at < b.at ? -1 : 1; }).forEach(function (s) { out.push('- ' + s.at + ' · ' + (L.stepNames[s.kind] || s.kind) + (s.note ? ': ' + s.note : '') + (s.due ? ' (' + L.due + ' ' + s.due + (s.done ? ', ' + L.answered : '') + ')' : '')); });
    }
    out.push('', '## ' + L.integrity, '');
    out.push(chain && chain.ok ? L.chainOk.replace('{n}', c.entries.length).replace('{h}', chain.head) : L.chainBad);
    return out.join('\n') + '\n';
  }

  /* ---------- import / sanitise ---------- */
  function sanitizeCase(c) {
    if (!c || typeof c !== 'object') return null;
    var kind = Object.prototype.hasOwnProperty.call(KINDS, c.kind) ? c.kind : 'other', q = Array.isArray(c.quiet) && c.quiet.length === 2 ? [clampInt(c.quiet[0], 0, 23), clampInt(c.quiet[1], 0, 23)] : null;
    /* Never drop a damaged record silently: keep it (coerced) so the chain check fails visibly. */
    var entries = (Array.isArray(c.entries) ? c.entries : []).filter(function (e) { return e && typeof e === 'object'; }).map(function (e) {
      var okShape = typeof e.id === 'string' && typeof e.hash === 'string' && typeof e.prev === 'string' && ['event', 'note', 'void'].indexOf(e.type) >= 0 && parseAt(e.at) && isFinite(e.rec) && typeof e.text === 'string';
      return { id: String(e.id || uid()).slice(0, 40), type: ['event', 'note', 'void'].indexOf(e.type) >= 0 ? e.type : 'event', ref: String(e.ref || '').slice(0, 40), at: parseAt(e.at) ? e.at : '1970-01-01T00:00', rec: isFinite(e.rec) ? +e.rec : 0, text: String(e.text == null ? '' : e.text).slice(0, 4000), sev: clampInt(e.sev, 0, 5), dur: clampInt(e.dur, 0, 14400), tags: cleanTags(e.tags), witness: String(e.witness || '').slice(0, 200), photos: (Array.isArray(e.photos) ? e.photos : []).slice(0, 6).filter(function (p) { return p && p.id; }).map(function (p) { return { id: String(p.id).slice(0, 40), h: String(p.h).slice(0, 64) }; }), reported: !!e.reported, prev: okShape ? e.prev : '?', hash: okShape ? e.hash : '' };
    });
    var steps = (Array.isArray(c.steps) ? c.steps : []).filter(function (s) { return s && STEP_KINDS.indexOf(s.kind) >= 0 && /^\d{4}-\d{2}-\d{2}$/.test(s.at || ''); }).map(function (s) {
      return { id: String(s.id || uid()).slice(0, 40), kind: s.kind, at: s.at, note: String(s.note || '').slice(0, 300), due: /^\d{4}-\d{2}-\d{2}$/.test(s.due || '') ? s.due : '', done: !!s.done };
    });
    return { id: String(c.id || uid()).slice(0, 40), name: String(c.name || 'Case').slice(0, 80), kind: kind, counterpart: String(c.counterpart || '').slice(0, 80), goal: String(c.goal || '').slice(0, 200), quiet: q, created: isFinite(c.created) ? +c.created : Date.now(), archived: !!c.archived, entries: entries, steps: steps, live: c.live && isFinite(c.live.start) ? { start: +c.live.start } : null };
  }

  /* ---------- tags, readiness, letter, calendar ---------- */
  function tagCounts(evs, limit) {
    var m = {}; evs.forEach(function (e) { (e.tags || []).forEach(function (x) { m[x] = (m[x] || 0) + 1; }); });
    return Object.keys(m).map(function (k) { return { tag: k, n: m[k] }; }).sort(function (a, b) { return b.n - a.n || (a.tag < b.tag ? -1 : 1); }).slice(0, limit || 6);
  }
  function readiness(c, nowTs) {
    var evs = events(c.entries), st = stats(c, nowTs), spanDays = 0;
    if (st.first && st.last) spanDays = dayNum(st.last) - dayNum(st.first);
    var checks = [
      { key: 'count', ok: evs.length >= 3 },
      { key: 'span', ok: spanDays >= 7 },
      { key: 'strength', ok: caseStrength(c) >= 60 },
      { key: 'parties', ok: !!(c.counterpart && c.goal) },
      { key: 'written', ok: (c.steps || []).some(function (s) { return s.kind === 'written'; }) },
      { key: 'late', ok: evs.length > 0 && st.late * 5 < evs.length }
    ];
    return { checks: checks, met: checks.filter(function (x) { return x.ok; }).length, total: checks.length };
  }
  function addDays(day, n) { var p = /^(\d{4})-(\d{2})-(\d{2})$/.exec(day); var d = new Date(Date.UTC(+p[1], +p[2] - 1, +p[3] + n)); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
  function fill(s, v) { for (var x in v) s = s.split('{' + x + '}').join(v[x]); return s; }
  /* A plain factual notice built only from what the log holds. L is the language table (ltr* keys). */
  function noticeLetter(c, L, nowTs, days) {
    var evs = events(c.entries).slice().sort(function (a, b) { return a.at < b.at ? -1 : 1; }), st = stats(c, nowTs), today = toLocalStamp(new Date(nowTs)).slice(0, 10), out = [];
    days = clampInt(days || 14, 1, 90);
    out.push(fill(L.ltrDate, { d: today }));
    out.push(fill(L.ltrTo, { who: c.counterpart || '[ ]' }), '');
    out.push(fill(L.ltrSubj, { name: c.name }), '', L.ltrOpen, '');
    if (evs.length) out.push(fill(L.ltrFacts, { a: st.first.slice(0, 10), b: st.last.slice(0, 10), n: evs.length }));
    if (c.quiet && st.quiet) out.push(fill(L.ltrQuiet, { n: st.quiet, a: pad(c.quiet[0]) + ':00', b: pad(c.quiet[1]) + ':00' }));
    if (st.minutes) out.push(fill(L.ltrMin, { n: st.minutes }));
    out.push('', L.ltrList);
    var shown = evs.slice(-12);
    if (evs.length > shown.length) out.push(fill(L.ltrMore, { n: evs.length - shown.length }));
    shown.forEach(function (e) { var t = e.text.replace(/\s+/g, ' ').trim(); out.push('- ' + e.at.replace('T', ' ') + (e.dur ? ' (' + e.dur + ' min)' : '') + ': ' + (t.length > 140 ? t.slice(0, 137) + '...' : t)); });
    out.push('', c.goal ? fill(L.ltrAsk, { goal: c.goal }) : L.ltrAskDef, fill(L.ltrDue, { date: addDays(today, days) }), '', L.ltrPref, '', L.ltrClose, L.ltrYou);
    return out.join('\n') + '\n';
  }
  function icsEsc(v) { return String(v).replace(/\\/g, '\\\\').replace(/\r?\n/g, '\\n').replace(/[,;]/g, function (m) { return '\\' + m; }); }
  function icsFold(line) {
    var out = [], b = line, n = /[^\x00-\x7f]/.test(line) ? 24 : 70;
    while (b.length > n) { var k = n; if (/[\ud800-\udbff]/.test(b.charAt(k - 1))) k--; out.push(b.slice(0, k)); b = ' ' + b.slice(k); }
    out.push(b); return out.join('\r\n');
  }
  /* All-day calendar events for steps still waiting on an answer. */
  function toIcs(c, L, nowTs) {
    var names = L.stepNames || {}, d = new Date(nowTs), stamp = d.getUTCFullYear() + pad(d.getUTCMonth() + 1) + pad(d.getUTCDate()) + 'T' + pad(d.getUTCHours()) + pad(d.getUTCMinutes()) + pad(d.getUTCSeconds()) + 'Z';
    var open = (c.steps || []).filter(function (s) { return s.due && !s.done && /^\d{4}-\d{2}-\d{2}$/.test(s.due); });
    if (!open.length) return '';
    var lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Marginlog//EN', 'CALSCALE:GREGORIAN'];
    open.forEach(function (s) {
      lines.push('BEGIN:VEVENT', 'UID:' + String(s.id).replace(/[^A-Za-z0-9-]/g, '') + '@marginlog', 'DTSTAMP:' + stamp, 'DTSTART;VALUE=DATE:' + s.due.replace(/-/g, ''), 'DTEND;VALUE=DATE:' + addDays(s.due, 1).replace(/-/g, ''),
        'SUMMARY:' + icsEsc(fill(L.icsSummary, { step: names[s.kind] || s.kind, 'case': c.name })), 'END:VEVENT');
    });
    lines.push('END:VCALENDAR');
    return lines.map(icsFold).join('\r\n') + '\r\n';
  }

  /* ---------- all-cases deadlines: one .ics file with every open reply deadline ---------- */
  function calendarAll(cases, L, nowTs) {
    var parts = cases.filter(function (c) { return !c.archived; }).map(function (c) { var s = toIcs(c, L, nowTs); var m = s.match(/BEGIN:VEVENT[\s\S]*?END:VEVENT\r\n/g); return m ? m.join('') : ''; }).join('');
    if (!parts) return '';
    return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Marginlog//EN', 'CALSCALE:GREGORIAN'].map(function (x) { return x + '\r\n'; }).join('') + parts + 'END:VCALENDAR\r\n';
  }
  /* ---------- digest: Markdown summary of every active case, overdue items first ---------- */
  function digest(cases, L, nowTs) {
    var names = L.stepNames || {}, today = toLocalStamp(new Date(nowTs)).slice(0, 10), rows = overview(cases.filter(function (c) { return !c.archived; }), nowTs), att = [];
    cases.forEach(function (c) {
      if (c.archived) return;
      (c.steps || []).forEach(function (s) { if (s.due && !s.done && /^\d{4}-\d{2}-\d{2}$/.test(s.due) && s.due < today) att.push({ due: s.due, text: fill(L.dgOverdueItem, { step: names[s.kind] || s.kind, 'case': c.name || '', d: s.due }) }); });
    });
    att.sort(function (a, b) { return a.due < b.due ? -1 : a.due > b.due ? 1 : 0; });
    var out = ['# ' + L.dgTitle + ' ' + today, '', '## ' + L.dgAttention];
    out = out.concat(att.length ? att.map(function (a) { return '- ' + a.text; }) : ['- ' + L.dgNone]);
    out.push('', '## ' + L.dgCases);
    out = out.concat(rows.length ? rows.map(function (r) {
      return '- ' + (r.name || L['kind_' + r.kind] || r.kind) + ' (' + (L['kind_' + r.kind] || r.kind) + '): ' + fill(L.ovEntries, { n: r.total }) + ', ' + fill(L.dgRecent, { n: r.last30 }) + ', ' + fill(L.ovStrength, { s: r.strength }) + ', ' + fill(L.ovOpen, { n: r.openSteps }) + (r.overdue ? ', ' + fill(L.ovOverdue, { n: r.overdue }) : '');
    }) : ['- ' + L.ovNone]);
    return out.join('\n') + '\n';
  }

  /* ---------- encrypted backup: AES-GCM, key from a passphrase via PBKDF2-SHA256 (WebCrypto, no library) ---------- */
  function b64(bytes) { var s = ''; for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]); return btoa(s); }
  function unb64(s) { var bin = atob(String(s)), out = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i); return out; }
  async function deriveKey(pass, salt, iter, usage) {
    var base = await crypto.subtle.importKey('raw', new TextEncoder().encode(String(pass)), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt: salt, iterations: iter, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, [usage]);
  }
  async function encryptText(text, pass) {
    var salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12)), iter = 310000;
    var key = await deriveKey(pass, salt, iter, 'encrypt');
    var ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv }, key, new TextEncoder().encode(text));
    return { alg: 'AES-GCM', kdf: 'PBKDF2-SHA256', iter: iter, salt: b64(salt), iv: b64(iv), data: b64(new Uint8Array(ct)) };
  }
  /* throws when the passphrase is wrong or the file was altered (GCM tag check) */
  async function decryptText(env, pass) {
    if (!env || env.alg !== 'AES-GCM' || env.kdf !== 'PBKDF2-SHA256' || !(env.iter >= 100000 && env.iter <= 1000000)) throw new Error('format');
    var key = await deriveKey(pass, unb64(env.salt), env.iter, 'decrypt');
    var pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(env.iv) }, key, unb64(env.data));
    return new TextDecoder().decode(pt);
  }
  /* ---------- all-cases overview: one row per case ---------- */
  function overview(cases, nowTs) {
    var today = toLocalStamp(new Date(nowTs)).slice(0, 10);
    return cases.map(function (c) {
      var st = stats(c, nowTs), open = (c.steps || []).filter(function (s) { return s.due && !s.done; });
      return { id: c.id, kind: c.kind, name: c.name || '', archived: !!c.archived, total: st.total, last30: st.last30, lastAt: st.last,
        openSteps: open.length, overdue: open.filter(function (s) { return /^\d{4}-\d{2}-\d{2}$/.test(s.due) && s.due < today; }).length, strength: caseStrength(c) };
    });
  }
  /* ---------- gallery, timeline, reminders, plain-text chronology (read-only views over the chain) ---------- */
  /* every photo attached to an event, newest first; `voided` marks photos on entries that were voided (still kept) */
  function photoIndex(c) {
    var out = [], v = voidedIds(c.entries);
    c.entries.filter(function (e) { return e.type === 'event'; }).forEach(function (e) {
      (e.photos || []).forEach(function (p) { out.push({ id: p.id, h: p.h, at: e.at, entry: e.id, voided: !!v[e.id] }); });
    });
    return out.sort(function (a, b) { return a.at < b.at ? 1 : a.at > b.at ? -1 : 0; });
  }
  /* events grouped by calendar month (YYYY-MM), newest month first */
  function monthGroups(evs) {
    var groups = [], idx = {};
    evs.slice().sort(function (a, b) { return a.at < b.at ? 1 : a.at > b.at ? -1 : 0; }).forEach(function (e) {
      var ym = String(e.at).slice(0, 7);
      if (!idx[ym]) { idx[ym] = { ym: ym, items: [] }; groups.push(idx[ym]); }
      idx[ym].items.push(e);
    });
    return groups;
  }
  /* open reply deadlines across active cases: overdue ones, and those due within `days` days; soonest first */
  function dueItems(cases, nowTs, days) {
    var today = toLocalStamp(new Date(nowTs)).slice(0, 10), limit = addDays(today, clampInt(days == null ? 7 : days, 0, 90)), out = [];
    (cases || []).forEach(function (c) {
      if (!c || c.archived) return;
      (c.steps || []).forEach(function (s) {
        if (s.done || !/^\d{4}-\d{2}-\d{2}$/.test(s.due || '') || s.due > limit) return;
        out.push({ caseId: c.id, caseName: c.name || '', kind: s.kind, stepId: s.id, due: s.due, overdue: s.due < today, daysLeft: Math.round((Date.parse(s.due + 'T00:00:00Z') - Date.parse(today + 'T00:00:00Z')) / 864e5) });
      });
    });
    return out.sort(function (a, b) { return a.due < b.due ? -1 : a.due > b.due ? 1 : 0; });
  }
  /* plain-text chronology for pasting into an email or form. L takes the same labels as reportMarkdown. */
  function chronologyText(c, L, nowTs, chain) {
    var vd = voidedIds(c.entries), all = c.entries.filter(function (e) { return e.type === 'event'; }).slice().sort(function (a, b) { return a.at < b.at ? -1 : 1; }), out = [];
    out.push(c.name || '', '');
    if (c.counterpart) out.push(L.counterpart + ': ' + c.counterpart);
    if (c.goal) out.push(L.goal + ': ' + c.goal);
    out.push(L.generated + ': ' + toLocalStamp(new Date(nowTs)).replace('T', ' '), '');
    out.push(L.timeline + ':', '');
    all.forEach(function (e, i) {
      var isV = !!vd[e.id];
      out.push((i + 1) + '. ' + e.at.replace('T', ' ') + (e.sev ? ' | ' + L.sev + ' ' + e.sev + '/5' : '') + (e.dur ? ' | ' + e.dur + ' min' : '') + (e.tags.length ? ' | ' + e.tags.join(', ') : '') + (isLate(e) ? ' | ' + L.late : '') + (isV ? ' | ' + L.voidedBadge : ''));
      e.text.split(/\r?\n/).forEach(function (line) { out.push('   ' + line); });
      if (e.witness) out.push('   ' + L.witness + ': ' + e.witness);
      if (e.photos.length) out.push('   ' + L.photos + ': ' + e.photos.length);
      if (e.reported) out.push('   ' + L.reportedTo);
      if (isV) out.push('   ' + L.voidedBadge + ' (' + vd[e.id].at.replace('T', ' ') + '): ' + vd[e.id].text.replace(/\s+/g, ' '));
      addenda(c.entries, e.id).forEach(function (n) { out.push('   + ' + n.at.replace('T', ' ') + ': ' + n.text.replace(/\s+/g, ' ')); });
      out.push('   ' + L.recordedAt + ' ' + toLocalStamp(new Date(e.rec)).replace('T', ' ') + ' | #' + e.hash.slice(0, 16));
    });
    out.push('', L.integrity + ':', chain && chain.ok ? L.chainOk.replace('{n}', c.entries.length).replace('{h}', chain.head) : L.chainBad);
    return out.join('\n') + '\n';
  }

  var api = {
    KINDS: KINDS, STEP_KINDS: STEP_KINDS, LATE_HOURS: LATE_HOURS,
    uid: uid, pad: pad, toLocalStamp: toLocalStamp, parseAt: parseAt, dayNum: dayNum, sha256Hex: sha256Hex, seal: seal, verifyChain: verifyChain, cleanTags: cleanTags, clampInt: clampInt,
    events: events, addenda: addenda, voidedIds: voidedIds, isLate: isLate, inQuiet: inQuiet, heatmap: heatmap, weekly: weekly, topBand: topBand, stats: stats,
    strength: strength, caseStrength: caseStrength, ladder: ladder, suggestNext: suggestNext, toCsv: toCsv, reportMarkdown: reportMarkdown, sanitizeCase: sanitizeCase,
    tagCounts: tagCounts, readiness: readiness, addDays: addDays, noticeLetter: noticeLetter, toIcs: toIcs, encryptText: encryptText, decryptText: decryptText, overview: overview, calendarAll: calendarAll, digest: digest,
    photoIndex: photoIndex, monthGroups: monthGroups, dueItems: dueItems, chronologyText: chronologyText
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.MLCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
