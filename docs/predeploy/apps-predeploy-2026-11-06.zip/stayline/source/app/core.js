/* Stayline core: pure functions, no DOM. Works in browser (window.SL) and Node.
   A "tracker" is { id, name, rule, trips }.
   rule  = { kind: 'rolling', limit, window }   e.g. 90 days in any 180
         | { kind: 'year',    limit }           e.g. 183 days per calendar year
   trip  = { id, place, from: 'YYYY-MM-DD', to: 'YYYY-MM-DD' | '' }  ('' = still there)
   Both the first and last day of a trip count as full days. All maths is on UTC day numbers, so DST cannot shift a count. */
(function (root) {
  'use strict';
  var RE = /^(\d{4})-(\d{2})-(\d{2})$/;

  function dn(s) { var m = RE.exec(s); return m ? Date.UTC(+m[1], +m[2] - 1, +m[3]) / 86400000 : NaN; }
  function str(n) {
    var d = new Date(n * 86400000), m = d.getUTCMonth() + 1, day = d.getUTCDate();
    return d.getUTCFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (day < 10 ? '0' : '') + day;
  }
  function todayStr(d) {
    d = d || new Date();
    var m = d.getMonth() + 1, day = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (day < 10 ? '0' : '') + day;
  }
  function addDays(s, n) { return str(dn(s) + n); }
  function validDate(s) { var n = dn(s); return !isNaN(n) && str(n) === s; }

  var PRESETS = {
    schengen: { kind: 'rolling', limit: 90, window: 180 },
    tax183: { kind: 'year', limit: 183 },
    visitor180: { kind: 'rolling', limit: 180, window: 365 }
  };
  function cleanRule(r) {
    r = r || PRESETS.schengen;
    var limit = Math.max(1, Math.min(366, Math.floor(+r.limit) || 90));
    if (r.kind === 'year') return { kind: 'year', limit: limit };
    var win = Math.max(limit, Math.min(730, Math.floor(+r.window) || 180));
    return { kind: 'rolling', limit: limit, window: win };
  }

  /* set of day numbers spent inside. Ongoing trips run through `today`. Overlaps count once. */
  function stayDays(trips, today) {
    var set = {}, t = dn(today);
    (trips || []).forEach(function (tr) {
      var a = dn(tr.from), b = tr.to ? dn(tr.to) : t;
      if (isNaN(a) || isNaN(b) || b < a || b - a > 3660) return;
      for (var d = a; d <= b; d++) set[d] = true;
    });
    return set;
  }
  function windowStart(rule, d) {
    if (rule.kind === 'year') return Date.UTC(new Date(d * 86400000).getUTCFullYear(), 0, 1) / 86400000;
    return d - (rule.window - 1);
  }
  function usedOn(set, rule, d) {
    var n = 0;
    for (var x = windowStart(rule, d); x <= d; x++) if (set[x]) n++;
    return n;
  }
  /* first stay-day >= from where the count passes the limit, or null */
  function firstBreach(set, rule, from) {
    var keys = Object.keys(set).map(Number).filter(function (d) { return d >= from; }).sort(function (a, b) { return a - b; });
    for (var i = 0; i < keys.length; i++) if (usedOn(set, rule, keys[i]) > rule.limit) return keys[i];
    return null;
  }

  /* where the tracker stands on `today`: used, left, state, and when the next day frees up */
  function summary(tr, today) {
    today = today || todayStr();
    var rule = cleanRule(tr.rule), set = stayDays(tr.trips, today), t = dn(today);
    var used = usedOn(set, rule, t), left = rule.limit - used;
    var state = left < 0 ? 'over' : left <= Math.max(5, Math.round(rule.limit * 0.15)) ? 'tight' : 'ok';
    var ws = windowStart(rule, t), freesOn = null;
    if (used >= rule.limit) {
      if (rule.kind === 'rolling') {
        /* first future day on which one more day still fits */
        for (var d = t + 1; d <= t + rule.window + 1; d++) if (usedOn(set, rule, d) < rule.limit) { freesOn = str(d); break; }
      } else freesOn = (new Date(t * 86400000).getUTCFullYear() + 1) + '-01-01';
    }
    var permit = null;
    if (tr.expires && validDate(tr.expires)) {
      var pd = dn(tr.expires) - t;
      permit = { days: pd, state: pd < 0 ? 'gone' : pd <= 30 ? 'soon' : 'ok' };
    }
    return { rule: rule, used: used, left: left, state: state, windowFrom: str(ws), freesOn: freesOn, inside: !!set[t], permit: permit };
  }

  /* longest run of days starting on day number e that keeps `set` within the rule (set is not modified) */
  function runFit(set, rule, e) {
    var n = 0, added = [];
    for (var d = e; d < e + 800; d++) {
      if (!set[d]) { set[d] = true; added.push(d); }
      if (firstBreach(set, rule, e) !== null) { if (added[added.length - 1] === d) { delete set[d]; added.pop(); } break; }
      n++;
    }
    added.forEach(function (x) { delete set[x]; });
    return n;
  }
  /* first day number >= f where a run of `nights` days breaks nothing, or null */
  function firstFit(base, rule, nights, f) {
    for (var e = f; e < f + 800; e++) {
      var set = {}, k;
      for (k in base) set[k] = true;
      for (var i = 0; i < nights; i++) set[e + i] = true;
      if (firstBreach(set, rule, e) === null) return e;
    }
    return null;
  }
  /* how many days in a row can I stay if I arrive on `entry`? 0 means arriving already breaks the limit */
  function maxStay(tr, entry, today) {
    return runFit(stayDays(tr.trips, today || todayStr()), cleanRule(tr.rule), dn(entry));
  }
  /* first arrival date >= from for which a stay of `nights` days breaks nothing; null if impossible */
  function earliestEntry(tr, nights, from, today) {
    var rule = cleanRule(tr.rule);
    nights = Math.floor(nights);
    if (!(nights >= 1) || nights > rule.limit) return null;
    var e = firstFit(stayDays(tr.trips, today || todayStr()), rule, nights, dn(from));
    return e === null ? null : str(e);
  }

  /* ---- what-if itinerary. drafts = [{ id, from, to }] (both required), never counted as real trips.
     Drafts are replayed in date order on top of the real trips; each result says whether that leg fits. ---- */
  function validDraft(d) { return !!d && validDate(d.from) && validDate(d.to) && dn(d.to) >= dn(d.from) && dn(d.to) - dn(d.from) <= 366; }
  function byFrom(a, b) { return a.from < b.from ? -1 : a.from > b.from ? 1 : 0; }
  function simulate(tr, drafts, today) {
    today = today || todayStr();
    var rule = cleanRule(tr.rule), set = stayDays(tr.trips, today), res = [], peak = 0, peakDate = null, ok = true;
    (drafts || []).filter(validDraft).sort(byFrom).forEach(function (d) {
      var a = dn(d.from), b = dn(d.to), days = b - a + 1, fit = runFit(set, rule, a), i;
      for (i = a; i <= b; i++) set[i] = true;
      var breach = firstBreach(set, rule, a), p = 0, pd = null;
      for (i = a; i <= b; i++) { var u = usedOn(set, rule, i); if (u > p) { p = u; pd = i; } }
      if (p > peak) { peak = p; peakDate = str(pd); }
      var fits = breach === null;
      if (!fits) ok = false;
      var early = null;
      if (!fits && days <= rule.limit) {
        var tmp = {}, k;
        for (k in set) tmp[k] = true;
        for (i = a; i <= b; i++) delete tmp[i];
        /* days other drafts or real trips already hold stay in tmp, so the suggestion respects them */
        var e = firstFit(tmp, rule, days, a); early = e === null ? null : str(e);
      }
      res.push({ id: d.id, from: d.from, to: d.to, days: days, ok: fits, breachDate: breach === null ? null : str(breach),
        fit: fit, trimTo: !fits && fit > 0 ? str(a + fit - 1) : null, earliest: early, peak: p, peakDate: pd === null ? null : str(pd) });
    });
    return { ok: ok, legs: res, peak: peak, peakDate: peakDate, limit: rule.limit };
  }
  function addDraft(tr, d) {
    if (!validDraft(d)) return false;
    tr.drafts = tr.drafts || [];
    if (tr.drafts.length >= 20) return false;
    tr.drafts.push({ id: 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), from: d.from, to: d.to });
    tr.drafts.sort(byFrom);
    return true;
  }
  function removeDraft(tr, id) {
    var n = (tr.drafts || []).length; tr.drafts = (tr.drafts || []).filter(function (d) { return d.id !== id; }); return tr.drafts.length !== n;
  }
  /* turn every draft into a real (planned) trip and empty the list; returns how many moved */
  function commitDrafts(tr) {
    var n = 0;
    (tr.drafts || []).slice().forEach(function (d) { if (addTrip(tr, { place: '', from: d.from, to: d.to })) n++; });
    tr.drafts = [];
    return n;
  }

  /* ---- family / group: one trip for several counters (each keeps its own rule) ---- */
  function fitsRun(base, rule, e, nights) {
    var set = {}, k;
    for (k in base) set[k] = true;
    for (var i = 0; i < nights; i++) set[e + i] = true;
    return firstBreach(set, rule, e) === null;
  }
  /* everyone arrives on `entry`: how long can the group stay together, and who is the limit? */
  function groupMaxStay(trackers, entry, today) {
    today = today || todayStr();
    var people = trackers.map(function (tr) { return { id: tr.id, name: tr.name, max: maxStay(tr, entry, today) }; });
    var min = people.length ? Math.min.apply(null, people.map(function (p) { return p.max; })) : 0;
    return { days: min, people: people, limiting: people.filter(function (p) { return p.max === min; }).map(function (p) { return p.id; }) };
  }
  /* first arrival date >= from when the whole group can stay `nights` days; null if some rule never allows it */
  function groupEarliest(trackers, nights, from, today) {
    today = today || todayStr();
    nights = Math.floor(nights);
    if (!trackers.length || !(nights >= 1)) return null;
    var rules = trackers.map(function (tr) { return cleanRule(tr.rule); });
    if (rules.some(function (r) { return nights > r.limit; })) return null;
    var bases = trackers.map(function (tr) { return stayDays(tr.trips, today); });
    for (var e = dn(from), end = e + 800; e < end; e++) {
      var all = true;
      for (var i = 0; i < trackers.length && all; i++) all = fitsRun(bases[i], rules[i], e, nights);
      if (all) return str(e);
    }
    return null;
  }

  /* contiguous ranges of arrival dates (within `horizon` days after `from`) from which a stay of `nights` days fits */
  function arrivalWindows(tr, nights, from, today, horizon) {
    var rule = cleanRule(tr.rule), out = [];
    nights = Math.floor(nights);
    if (!(nights >= 1) || nights > rule.limit) return out;
    var base = stayDays(tr.trips, today || todayStr()), f = dn(from), cur = null;
    for (var e = f; e <= f + (horizon || 365); e++) {
      if (fitsRun(base, rule, e, nights)) { if (cur) cur.to = str(e); else { cur = { from: str(e), to: str(e) }; out.push(cur); } }
      else cur = null;
    }
    return out;
  }

  /* pasted text -> trips. One trip per line: two dates (YYYY-MM-DD, YYYY/M/D or YYYY.M.D) plus an optional place;
     one date = a single day. Lines that do not parse are returned in `bad` (1-based line numbers). */
  function parseTrips(text) {
    var trips = [], bad = [], DATE = /(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/g;
    String(text || '').split(/\r?\n/).slice(0, 500).forEach(function (line, i) {
      if (!line.trim()) return;
      var ds = [], m, rest = line;
      DATE.lastIndex = 0;
      while ((m = DATE.exec(line))) ds.push(m[1] + '-' + (m[2].length < 2 ? '0' : '') + m[2] + '-' + (m[3].length < 2 ? '0' : '') + m[3]);
      rest = line.replace(DATE, ' ').replace(/[,;→>\t]|\bto\b|(^|\s)[-~–—](\s|$)/gi, ' ').replace(/\s+/g, ' ').trim();
      var t = ds.length === 1 ? { from: ds[0], to: ds[0] } : ds.length === 2 ? { from: ds[0], to: ds[1] } : null;
      if (!t || !validTrip(t)) { bad.push(i + 1); return; }
      trips.push({ place: rest.slice(0, 60), from: t.from, to: t.to });
    });
    return { trips: trips, bad: bad };
  }

  /* heads-ups worth a banner today, across all counters: over, leave-by within 7 days, breach ahead within 14,
     permit ending within 30 (or already ended). Most urgent first. */
  var URGENT_DAYS = { over: 0, leave_by: 7, leave_by_safe: 7, breach_ahead: 14, permit_end: 30, permit_gone: 0 };
  function urgent(trackers, today) {
    today = today || todayStr();
    var out = [];
    trackers.forEach(function (tr) {
      alerts(tr, today).forEach(function (a) {
        if (a.kind === 'over' || a.kind === 'permit_gone' || (a.kind in URGENT_DAYS && a.in >= 0 && a.in <= URGENT_DAYS[a.kind])) out.push({ kind: a.kind, date: a.date, in: a.in, id: tr.id, name: tr.name });
      });
    });
    return out.sort(function (a, b) { return a.in - b.in; });
  }
  /* plain-text version of a what-if result, for sharing */
  function itineraryText(sim, label) {
    return sim.legs.map(function (l) {
      return l.from + ' -> ' + l.to + ' (' + l.days + ') ' + (l.ok ? 'OK' : 'X ' + l.breachDate) + (label ? ' ' + label(l) : '');
    }).join('\n');
  }

  /* look back `years` years: every stretch of days where the count was over the limit, with the worst excess */
  function audit(tr, today, years) {
    today = today || todayStr();
    var rule = cleanRule(tr.rule), set = stayDays(tr.trips, today), t = dn(today), start = t - Math.round((years || 3) * 365), out = [], cur = null;
    for (var d = start; d <= t; d++) {
      var over = set[d] ? usedOn(set, rule, d) - rule.limit : 0;
      if (over > 0) {
        if (cur && cur.toN === d - 1) { cur.toN = d; if (over > cur.over) cur.over = over; }
        else { cur = { fromN: d, toN: d, over: over }; out.push(cur); }
      }
    }
    return out.map(function (e) { return { from: str(e.fromN), to: str(e.toN), over: e.over }; });
  }

  /* month grid (weeks start on Monday) for 'YYYY-MM'. Each cell: date, inMonth, in (a stay day), planned (stay day after today),
     over (count above the limit that day), today. */
  function calendarMonth(tr, ym, today) {
    today = today || todayStr();
    var m = /^(\d{4})-(\d{2})$/.exec(ym);
    if (!m) return [];
    var rule = cleanRule(tr.rule), set = stayDays(tr.trips, today), t = dn(today);
    var first = Date.UTC(+m[1], +m[2] - 1, 1) / 86400000, next = Date.UTC(+m[1], +m[2], 1) / 86400000;
    var start = first - ((new Date(first * 86400000).getUTCDay() + 6) % 7), weeks = [];
    for (var d = start; d < next; d += 7) {
      var row = [];
      for (var i = 0; i < 7; i++) {
        var x = d + i, inside = !!set[x];
        row.push({ date: str(x), inMonth: x >= first && x < next, in: inside, planned: inside && x > t, over: inside && usedOn(set, rule, x) > rule.limit, today: x === t });
      }
      weeks.push(row);
    }
    return weeks;
  }
  function addMonth(ym, n) {
    var m = /^(\d{4})-(\d{2})$/.exec(ym), d = new Date(Date.UTC(+m[1], +m[2] - 1 + n, 1));
    return str(d.getTime() / 86400000).slice(0, 7);
  }

  /* greedy auto-itinerary: `count` trips of `nights` days, each as early as the rules allow, at least `gap` days after the last.
     Returns drafts that fit (fewer than `count` if the rule runs out of room within a year of searching). */
  function autoItinerary(tr, count, nights, gap, from, today) {
    today = today || todayStr();
    var rule = cleanRule(tr.rule), set = stayDays(tr.trips, today), f = dn(from), out = [];
    nights = Math.floor(nights); gap = Math.max(0, Math.floor(gap) || 0);
    if (!(nights >= 1) || nights > rule.limit) return out;
    for (var n = 0; n < Math.min(20, Math.floor(count) || 0); n++) {
      var e = firstFit(set, rule, nights, f);
      if (e === null || e > f + 400) break;
      for (var i = 0; i < nights; i++) set[e + i] = true;
      out.push({ id: 'a' + n, from: str(e), to: str(e + nights - 1) });
      f = e + nights + gap;
    }
    return out;
  }

  /* days spent inside per calendar month, oldest first, ending with the month of `today` */
  function monthlyUsage(tr, today, months) {
    today = today || todayStr();
    var set = stayDays(tr.trips, today), t = new Date(dn(today) * 86400000), out = [];
    for (var i = months - 1; i >= 0; i--) {
      var y = t.getUTCFullYear(), m = t.getUTCMonth() - i;
      var first = Date.UTC(y, m, 1) / 86400000, next = Date.UTC(y, m + 1, 1) / 86400000, n = 0;
      for (var d = first; d < next; d++) if (set[d]) n++;
      out.push({ month: str(first).slice(0, 7), days: n });
    }
    return out;
  }

  /* where the days went: per place, over the `days` days up to and including `today` (past and ongoing only; planned trips are ignored).
     Places match ignoring case and surrounding spaces; trips without a place are grouped under ''. Biggest first. */
  function placeStats(tr, today, days) {
    today = today || todayStr(); days = days || 365;
    var end = dn(today), start = end - days + 1, by = {}, order = [];
    tr.trips.forEach(function (t) {
      var set = stayDays([t], today), n = 0;
      for (var d = start; d <= end; d++) if (set[d]) n++;
      if (!n) return;
      var label = String(t.place || '').trim(), key = label.toLowerCase();
      if (!by[key]) { by[key] = { place: label, days: 0, trips: 0, longest: 0 }; order.push(key); }
      var e = by[key]; e.days += n; e.trips++; if (n > e.longest) e.longest = n;
    });
    return order.map(function (k) { return by[k]; }).sort(function (a, b) { return b.days - a.days || (a.place < b.place ? -1 : a.place > b.place ? 1 : 0); });
  }

  /* days left on each of the next `n` days if nothing new is added (an ongoing stay is assumed to end today) */
  function forecast(tr, today, n) {
    today = today || todayStr();
    var rule = cleanRule(tr.rule), set = stayDays(tr.trips, today), t = dn(today), out = [];
    for (var i = 0; i <= n; i++) out.push({ date: str(t + i), left: rule.limit - usedOn(set, rule, t + i) });
    return out;
  }

  /* dated heads-up list for one tracker, soonest first. kind: over | leave_by | frees | breach_ahead | permit_end | permit_gone.
     in = days from today (0 = today). */
  function alerts(tr, today) {
    today = today || todayStr();
    var rule = cleanRule(tr.rule), set = stayDays(tr.trips, today), t = dn(today), out = [];
    var s = summary(tr, today);
    function add(kind, d) { out.push({ kind: kind, date: str(d), in: d - t }); }
    if (s.left < 0) add('over', t);
    else if (s.inside) {
      var sd = safeLastDay(tr, today), ld = lastDay(tr, today);
      if (ld) add('leave_by', dn(ld));
      if (sd && sd !== ld) add('leave_by_safe', dn(sd));
    }
    var ahead = firstBreach(set, rule, t + 1);
    if (ahead !== null && s.left >= 0) add('breach_ahead', ahead);
    if (s.freesOn) add('frees', dn(s.freesOn));
    if (s.permit) add(s.permit.state === 'gone' ? 'permit_gone' : 'permit_end', dn(tr.expires));
    return out.sort(function (a, b) { return a.in - b.in; });
  }

  /* all-day calendar events for every upcoming key date (separate from toIcs, which exports trips). label(kind, tracker) supplies the (translated) title. */
  function alertsIcs(trackers, today, label) {
    today = today || todayStr();
    var lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Stayline//EN', 'CALSCALE:GREGORIAN'], stamp = today.replace(/-/g, '') + 'T000000Z';
    trackers.forEach(function (tr) {
      alerts(tr, today).forEach(function (a) {
        if (a.kind === 'over' || a.kind === 'permit_gone' || a.in < 0) return;
        var day = a.date.replace(/-/g, ''), next = addDays(a.date, 1).replace(/-/g, '');
        lines.push('BEGIN:VEVENT', 'UID:' + String(tr.id).replace(/[^A-Za-z0-9_-]/g, '') + '-' + a.kind + '-' + day + '@stayline', 'DTSTAMP:' + stamp,
          'DTSTART;VALUE=DATE:' + day, 'DTEND;VALUE=DATE:' + next,
          'SUMMARY:' + icsEsc((label ? label(a.kind, tr) : a.kind) + (tr.name ? ' (' + tr.name + ')' : '')), 'END:VEVENT');
      });
    });
    lines.push('END:VCALENDAR');
    return lines.join('\r\n') + '\r\n';
  }

  /* If you are inside today and keep staying, the last day that still fits the rule (null if not inside,
     already over, or the limit is not reached within 800 days). */
  function lastDay(tr, today) {
    var rule = cleanRule(tr.rule), set = stayDays(tr.trips, today), t = dn(today);
    if (!set[t] || usedOn(set, rule, t) > rule.limit) return null;
    for (var d = t + 1; d <= t + 800; d++) {
      set[d] = true;
      if (usedOn(set, rule, d) > rule.limit) return str(d - 1);
    }
    return null;
  }

  /* cells for the strip: every day of the current window, marked in/out/today */
  function strip(tr, today) {
    var rule = cleanRule(tr.rule), set = stayDays(tr.trips, today), t = dn(today), a = windowStart(rule, t), out = [];
    var end = rule.kind === 'year' ? Date.UTC(new Date(t * 86400000).getUTCFullYear(), 11, 31) / 86400000 : t;
    for (var d = a; d <= end; d++) out.push({ date: str(d), in: !!set[d], today: d === t, future: d > t });
    return out;
  }

  function oneLine(n, max) { return String(n == null ? '' : n).replace(/[\r\n\u2028\u2029]+/g, ' ').trim().slice(0, max); }
  function cleanNote(n) { return oneLine(n, 120); }
  function validTrip(t) {
    if (!t || !validDate(t.from)) return false;
    if (t.to && (!validDate(t.to) || dn(t.to) < dn(t.from))) return false;
    return true;
  }
  function addTrip(tr, trip) {
    if (!validTrip(trip)) return false;
    tr.trips.push({ id: 't' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), place: oneLine(trip.place, 60), from: trip.from, to: trip.to || '', note: cleanNote(trip.note), holiday: trip.holiday === true, remindOn: validDate(trip.remindOn) ? trip.remindOn : '', remindText: cleanNote(trip.remindText) });
    tr.trips.sort(function (a, b) { return a.from < b.from ? 1 : a.from > b.from ? -1 : 0; });
    return true;
  }
  function updateTrip(tr, id, patch) {
    var t = tr.trips.filter(function (x) { return x.id === id; })[0];
    if (!t) return false;
    var next = { place: patch.place != null ? patch.place : t.place, from: patch.from, to: patch.to || '' };
    if (!validTrip(next)) return false;
    t.place = oneLine(next.place, 60); t.from = next.from; t.to = next.to;
    if (patch.note != null) t.note = cleanNote(patch.note);
    if (patch.holiday !== undefined) t.holiday = patch.holiday === true;
    if (patch.remindOn !== undefined) t.remindOn = validDate(patch.remindOn) ? patch.remindOn : '';
    if (patch.remindText !== undefined) t.remindText = cleanNote(patch.remindText);
    tr.trips.sort(function (a, b) { return a.from < b.from ? 1 : a.from > b.from ? -1 : 0; });
    return true;
  }
  function cleanBuffer(b) { return Math.max(0, Math.min(30, Math.floor(+b) || 0)); }
  /* safety margin: pretend the limit is `buffer` days lower, so the leave-by date keeps a cushion for delays */
  function safeLastDay(tr, today) {
    var b = cleanBuffer(tr.buffer);
    if (!b) return null;
    var rule = cleanRule(tr.rule), lim = Math.max(1, rule.limit - b);
    var copy = { rule: rule.kind === 'year' ? { kind: 'year', limit: lim } : { kind: 'rolling', limit: lim, window: rule.window }, trips: tr.trips };
    return lastDay(copy, today);
  }
  /* everything a border officer or a visa form asks for: trips overlapping the counting window, with day counts */
  function borderSheet(tr, today) {
    today = today || todayStr();
    var s = summary(tr, today), a = dn(s.windowFrom), t = dn(today), rows = [];
    tr.trips.slice().sort(function (x, y) { return x.from < y.from ? -1 : x.from > y.from ? 1 : 0; }).forEach(function (x) {
      var b = x.to ? dn(x.to) : t;
      if (b < a || dn(x.from) > t) return;
      rows.push({ place: x.place || '', from: x.from, countedFrom: str(Math.max(dn(x.from), a)), to: x.to || '', days: Object.keys(stayDays([x], today)).filter(function (k) { return +k >= a && +k <= t; }).length, note: x.note || '' });
    });
    return { name: tr.name || '', rule: s.rule, used: s.used, left: s.left, windowFrom: s.windowFrom, today: today, trips: rows, overlap: rows.reduce(function (n, r) { return n + r.days; }, 0) > s.used, lastDay: lastDay(tr, today), safeLastDay: safeLastDay(tr, today), expires: tr.expires || '' };
  }
  /* rebuild a tracker list from untrusted JSON (restore from file): drop anything malformed, clamp the rest */
  function sanitize(list) {
    var out = [];
    (Array.isArray(list) ? list : []).slice(0, 50).forEach(function (t) {
      if (!t || typeof t !== 'object') return;
      var tr = { id: String(t.id || 'k' + out.length).slice(0, 40), name: oneLine(t.name, 40), rule: cleanRule(t.rule), expires: validDate(t.expires) ? t.expires : '', buffer: cleanBuffer(t.buffer), trips: [] };
      (Array.isArray(t.trips) ? t.trips : []).slice(0, 2000).forEach(function (x, i) {
        if (x && validTrip(x)) tr.trips.push({ id: String(x.id || 't' + i).slice(0, 40), place: oneLine(x.place, 60), from: x.from, to: x.to || '', note: cleanNote(x.note), holiday: x.holiday === true, remindOn: validDate(x.remindOn) ? x.remindOn : '', remindText: cleanNote(x.remindText) });
      });
      tr.trips.sort(function (a, b) { return a.from < b.from ? 1 : a.from > b.from ? -1 : 0; });
      tr.drafts = [];
      (Array.isArray(t.drafts) ? t.drafts : []).slice(0, 20).forEach(function (x, i) {
        if (validDraft(x)) tr.drafts.push({ id: String(x.id || 'd' + i).slice(0, 40), from: x.from, to: x.to });
      });
      tr.drafts.sort(byFrom);
      out.push(tr);
    });
    return out;
  }
  function removeTrip(tr, id) {
    var n = tr.trips.length; tr.trips = tr.trips.filter(function (t) { return t.id !== id; }); return tr.trips.length !== n;
  }

  function csvCell(v) {
    v = String(v == null ? '' : v);
    if (/^[=+\-@\t\r]/.test(v)) v = "'" + v;
    return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }
  function toCsv(trackers, today) {
    var rows = [['tracker', 'rule', 'permit_until', 'place', 'from', 'to', 'days']];
    trackers.forEach(function (tr) {
      var r = cleanRule(tr.rule), label = r.kind === 'year' ? r.limit + '/calendar-year' : r.limit + '/' + r.window;
      tr.trips.slice().reverse().forEach(function (t) {
        var days = Object.keys(stayDays([t], today || todayStr())).length;
        rows.push([tr.name, label, tr.expires || '', t.place, t.from, t.to, days]);
      });
    });
    return rows.map(function (r) { return r.map(csvCell).join(','); }).join('\n');
  }

  /* iCalendar export: one all-day event per trip (DTEND is exclusive, so the day after the last day).
     An ongoing trip ends today. */
  function icsEsc(v) { return String(v == null ? '' : v).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n'); }
  function toIcs(trackers, today) {
    var t0 = today || todayStr(), stamp = t0.replace(/-/g, '') + 'T000000Z';
    var lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Stayline//EN', 'CALSCALE:GREGORIAN'];
    trackers.forEach(function (tr) {
      tr.trips.forEach(function (t) {
        var end = t.to || t0;
        lines.push('BEGIN:VEVENT', 'UID:' + String(t.id).replace(/[^A-Za-z0-9_-]/g, '') + '@stayline',
          'DTSTAMP:' + stamp, 'DTSTART;VALUE=DATE:' + t.from.replace(/-/g, ''),
          'DTEND;VALUE=DATE:' + addDays(end, 1).replace(/-/g, ''),
          'SUMMARY:' + icsEsc((tr.name ? tr.name + ': ' : '') + (t.place || 'Stay')), 'END:VEVENT');
      });
    });
    lines.push('END:VCALENDAR');
    return lines.join('\r\n') + '\r\n';
  }

  /* ---- offline licence check. Placeholder scheme: anyone reading this file can mint a key.
     Replace with a vendor-issued key + server check before charging real money. ---- */
  function keySum(body) {
    var h = 11;
    for (var i = 0; i < body.length; i++) h = (h * 37 + body.charCodeAt(i)) % 46656;
    return h.toString(36).toUpperCase().padStart(3, '0');
  }
  function makeKey(seed) {
    var body = (seed || 'AAAAAAAA').toUpperCase().replace(/[^A-Z0-9]/g, '').padEnd(8, 'A').slice(0, 8);
    return 'SL-' + body.slice(0, 4) + '-' + body.slice(4, 8) + '-' + keySum(body);
  }
  function validKey(k) {
    var m = /^SL-([A-Z0-9]{4})-([A-Z0-9]{4})-([A-Z0-9]{3})$/.exec(String(k || '').trim().toUpperCase());
    return !!m && keySum(m[1] + m[2]) === m[3];
  }

  /* the same trips measured against the common limits side by side, plus the counter's own rule when it is custom */
  function compareRules(tr, today) {
    today = today || todayStr();
    var rows = [], seen = {};
    function add(key, rule) {
      var r = cleanRule(rule), id = r.kind + r.limit + '/' + (r.window || 0);
      if (seen[id]) return; seen[id] = true;
      var s = summary({ rule: r, trips: tr.trips }, today);
      rows.push({ key: key, rule: r, used: s.used, left: s.left, state: s.state, freesOn: s.freesOn });
    }
    var own = cleanRule(tr.rule);
    add('schengen', PRESETS.schengen); add('visitor180', PRESETS.visitor180); add('tax183', PRESETS.tax183);
    add('own', own);
    var mine = rows.filter(function (r) { return JSON.stringify(r.rule) === JSON.stringify(own); })[0];
    if (mine) { mine.own = true; rows.splice(rows.indexOf(mine), 1); rows.unshift(mine); }
    return rows;
  }
  /* travel statistics from the whole trip list: days per calendar year, longest single stay, trip and place counts */
  function yearStats(tr, today) {
    today = today || todayStr();
    var set = stayDays(tr.trips, today), byYear = {}, total = 0, k;
    for (k in set) { var y = new Date(+k * 86400000).getUTCFullYear(); byYear[y] = (byYear[y] || 0) + 1; total++; }
    var years = Object.keys(byYear).map(Number).sort(function (a, b) { return b - a; }).map(function (y) { return { year: y, days: byYear[y] }; });
    var longest = null, places = {}, t = dn(today), count = 0;
    (tr.trips || []).forEach(function (x) {
      var a = dn(x.from), b = x.to ? dn(x.to) : t;
      if (isNaN(a) || isNaN(b) || b < a) return;
      count++;
      var n = b - a + 1;
      if (!longest || n > longest.days) longest = { days: n, place: x.place || '', from: x.from, to: x.to || '' };
      var p = String(x.place || '').trim().toLowerCase();
      if (p) places[p] = true;
    });
    return { years: years, total: total, trips: count, places: Object.keys(places).length, longest: longest };
  }

  /* read-only share link: the counter's rule and trips packed into a URL fragment (never sent to a server). Notes are left out. */
  function b64url(s) { return btoa(unescape(encodeURIComponent(s))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function unb64url(s) { s = String(s).replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return decodeURIComponent(escape(atob(s))); }
  function encodeShare(tr) {
    var r = cleanRule(tr.rule);
    var o = { v: 1, n: oneLine(tr.name, 40), r: r.kind === 'year' ? ['y', r.limit] : ['r', r.limit, r.window], e: tr.expires || '', t: (tr.trips || []).slice(0, 200).map(function (x) { return [x.from, x.to || '', oneLine(x.place, 60)]; }) };
    return b64url(JSON.stringify(o));
  }
  function decodeShare(code) {
    try {
      if (!code || code.length > 40000) return null;
      var o = JSON.parse(unb64url(code));
      if (!o || o.v !== 1 || !Array.isArray(o.t) || !Array.isArray(o.r)) return null;
      var rule = o.r[0] === 'y' ? { kind: 'year', limit: o.r[1] } : { kind: 'rolling', limit: o.r[1], window: o.r[2] };
      var list = sanitize([{ id: 'shared', name: o.n, rule: rule, expires: o.e, trips: o.t.slice(0, 200).map(function (x, i) { return { id: 's' + i, from: x && x[0], to: x && x[1], place: x && x[2] }; }) }]);
      return list[0] || null;
    } catch (e) { return null; }
  }

  /* .ics import: each VEVENT becomes a trip. Summary is the place. All-day DTEND is exclusive, so the last day is one day before it.
     Timed events use the calendar date of start and end. Returns [{place, from, to}] (to '' for a single day). */
  function parseIcs(text) {
    var lines = String(text || '').replace(/\r\n?/g, '\n').replace(/\n[ \t]/g, '').split('\n');
    var out = [], cur = null;
    function day(v) { var m = /^(\d{4})(\d{2})(\d{2})/.exec(v || ''); return m ? m[1] + '-' + m[2] + '-' + m[3] : ''; }
    lines.forEach(function (ln) {
      if (ln === 'BEGIN:VEVENT') { cur = {}; return; }
      if (ln === 'END:VEVENT') {
        if (cur && validDate(cur.start)) {
          var to = cur.end && validDate(cur.end) ? cur.end : cur.start;
          if (cur.allDay && dn(to) > dn(cur.start)) to = addDays(to, -1);
          if (dn(to) < dn(cur.start)) to = cur.start;
          out.push({ place: oneLine(cur.summary || '', 60), from: cur.start, to: to === cur.start ? '' : to });
        }
        cur = null; return;
      }
      if (!cur) return;
      var i = ln.indexOf(':'); if (i < 0) return;
      var key = ln.slice(0, i), val = ln.slice(i + 1), head = key.split(';')[0];
      if (head === 'DTSTART') { cur.start = day(val); cur.allDay = /VALUE=DATE(?!-TIME)/.test(key) || /^\d{8}$/.test(val); }
      else if (head === 'DTEND') cur.end = day(val);
      else if (head === 'SUMMARY') cur.summary = val.replace(/\\(.)/g, function (m, c) { return /n/i.test(c) ? ' ' : c; });
    });
    return out.slice(0, 500);
  }
  /* RFC 4180-style CSV reader: quoted cells, doubled quotes, CRLF or LF. Returns rows of cells. */
  function csvRows(text) {
    var rows = [], row = [], cell = '', q = false, s = String(text || '').replace(/^﻿/, '');
    for (var i = 0; i < s.length; i++) {
      var ch = s.charAt(i);
      if (q) {
        if (ch === '"') { if (s.charAt(i + 1) === '"') { cell += '"'; i++; } else q = false; }
        else cell += ch;
      } else if (ch === '"') q = true;
      else if (ch === ',') { row.push(cell); cell = ''; }
      else if (ch === '\n' || ch === '\r') {
        if (ch === '\r' && s.charAt(i + 1) === '\n') i++;
        row.push(cell); rows.push(row); row = []; cell = '';
      } else cell += ch;
    }
    if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
    return rows;
  }
  /* CSV -> trips for the current counter. Needs a header row with `from` and `to` (matched ignoring case; `place` is optional),
     so the file toCsv writes can be read back. Empty `to` = still there. A leading apostrophe before a formula character
     (toCsv's guard) is removed. Returns { trips, bad } like parseTrips; `bad` holds approximate line numbers
     (header is line 1; blank lines are skipped, so after one they can drift). */
  function parseCsvTrips(text) {
    var rows = csvRows(text).filter(function (r) { return r.some(function (c) { return String(c).trim() !== ''; }); });
    var out = { trips: [], bad: [] };
    if (rows.length < 2) return out;
    var head = rows[0].map(function (c) { return String(c).trim().toLowerCase(); });
    var iF = head.indexOf('from'), iT = head.indexOf('to'), iP = head.indexOf('place');
    if (iF < 0 || iT < 0) return out;
    /* cells are kept as typed: a leading apostrophe is not removed (csvCell only adds one before = + - @ tab CR on export) */
    function cellOf(r, k) { return k < 0 || r[k] == null ? '' : String(r[k]).trim(); }
    /* spreadsheets often write 2026/6/1 or 2026.6.1: pad those to YYYY-MM-DD before checking */
    function dateOf(r, k) {
      var v = cellOf(r, k), m = /^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/.exec(v);
      return m ? m[1] + '-' + (m[2].length < 2 ? '0' : '') + m[2] + '-' + (m[3].length < 2 ? '0' : '') + m[3] : v;
    }
    rows.slice(1, 501).forEach(function (r, i) {
      var t = { place: oneLine(cellOf(r, iP), 60), from: dateOf(r, iF), to: dateOf(r, iT) };
      if (!validTrip(t)) { out.bad.push(i + 2); return; }
      out.trips.push(t);
    });
    out.capped = Math.max(0, rows.length - 501);
    return out;
  }

  /* same trip = same first and last day and same place (ignoring case and spaces). Splits incoming trips into new ones and duplicates
     (duplicates of existing trips or of earlier incoming rows). */
  function sameTrip(a, b) {
    return a.from === b.from && (a.to || '') === (b.to || '') && String(a.place || '').trim().toLowerCase() === String(b.place || '').trim().toLowerCase();
  }
  function newTrips(existing, incoming) {
    var fresh = [], dupes = 0;
    (incoming || []).forEach(function (t) {
      if ((existing || []).some(function (x) { return sameTrip(x, t); }) || fresh.some(function (x) { return sameTrip(x, t); })) dupes++;
      else fresh.push(t);
    });
    return { fresh: fresh, dupes: dupes };
  }
  /* what if the current stay ends on `date`: days inside and days left that day. Ongoing trips run to `date`;
     trips that start after it are dropped; planned trips are cut at `date`. Returns null for a bad date. */
  function leaveOn(tr, date, today) {
    today = today || todayStr();
    if (!validDate(date)) return null;
    var rule = cleanRule(tr.rule), x = dn(date);
    var trips = (tr.trips || []).filter(function (t) { return !isNaN(dn(t.from)) && dn(t.from) <= x; }).map(function (t) {
      return { from: t.from, to: t.to && !isNaN(dn(t.to)) ? str(Math.min(dn(t.to), x)) : date };
    });
    var used = usedOn(stayDays(trips, today), rule, x), left = rule.limit - used;
    return { date: date, used: used, left: left, limit: rule.limit, state: left < 0 ? 'over' : left <= Math.max(5, Math.round(rule.limit * 0.15)) ? 'tight' : 'ok' };
  }
  /* weeks (Monday to Sunday) of the current calendar year, up to and including `today`: days inside per week, from the week containing 1 January */
  function weeklyYear(tr, today) {
    today = today || todayStr();
    var t = dn(today), y = new Date(t * 86400000).getUTCFullYear(), jan1 = Date.UTC(y, 0, 1) / 86400000;
    var set = stayDays(tr.trips, today), out = [];
    for (var w = jan1 - ((new Date(jan1 * 86400000).getUTCDay() + 6) % 7); w <= t; w += 7) {
      var n = 0;
      for (var d = w; d < w + 7; d++) if (d >= jan1 && d <= t && set[d]) n++;
      out.push({ start: str(w), days: n });
    }
    return out;
  }
  /* plain-language wording for a rule: { key, vars } for T(key, vars) */
  function explainRule(rule) {
    var r = cleanRule(rule);
    if (r.kind === 'year') return r.limit === 183 ? { key: 'explain_tax183', vars: {} } : { key: 'explain_year', vars: { l: r.limit } };
    if (r.limit === 90 && r.window === 180) return { key: 'explain_schengen', vars: {} };
    if (r.limit === 180 && r.window === 365) return { key: 'explain_visitor180', vars: {} };
    return { key: 'explain_rolling', vars: { l: r.limit, w: r.window } };
  }
  /* trip reminders across counters: a reminder date from today to `days` ahead, soonest first */
  function reminders(trackers, today, days) {
    today = today || todayStr(); days = days == null ? 30 : days;
    var t = dn(today), out = [];
    (trackers || []).forEach(function (tr) {
      (tr.trips || []).forEach(function (x) {
        if (!x.remindOn || !validDate(x.remindOn)) return;
        var n = dn(x.remindOn) - t;
        if (n < 0 || n > days) return;
        out.push({ id: tr.id, name: tr.name || '', trip: x.id, place: x.place || '', on: x.remindOn, text: x.remindText || '', in: n });
      });
    });
    return out.sort(function (a, b) { return a.in - b.in; });
  }

  /* counters whose permit or visa ends within `days` days, or ended up to 30 days ago. Soonest first. */
  function permitWatch(trackers, today, days) {
    today = today || todayStr(); days = days == null ? 90 : days;
    var out = [];
    (trackers || []).forEach(function (tr) {
      if (!tr.expires || !validDate(tr.expires)) return;
      var left = dn(tr.expires) - dn(today);
      if (left < -30 || left > days) return;
      out.push({ id: tr.id, name: tr.name || '', expires: tr.expires, left: left });
    });
    return out.sort(function (a, b) { return a.left - b.left; });
  }
  /* plain-text (Markdown) report for every counter: rule, days counted now, days per calendar year, places, longest stay, permit date */
  function yearReport(trackers, today) {
    today = today || todayStr();
    var out = ['# Stayline report', '', 'Generated ' + today + '. These are estimates from the dates entered; official records decide.', ''];
    (trackers || []).forEach(function (tr) {
      var r = cleanRule(tr.rule), st = yearStats(tr, today), s = summary(tr, today);
      out.push('## ' + (tr.name || 'Counter'), '');
      out.push('- Rule: ' + (r.kind === 'year' ? r.limit + ' days per calendar year' : r.limit + ' days in any ' + r.window + ' days'));
      out.push('- Counted now: ' + s.used + ' days, ' + (s.left >= 0 ? s.left + ' left' : (-s.left) + ' over'));
      if (tr.expires && validDate(tr.expires)) out.push('- Permit or visa valid until: ' + tr.expires);
      out.push('- Trips: ' + st.trips + ', places: ' + st.places + ', days inside in total: ' + st.total);
      if (st.longest) out.push('- Longest stay: ' + st.longest.days + ' days' + (st.longest.place ? ' (' + st.longest.place + ')' : '') + ', from ' + st.longest.from);
      if (st.years.length) { out.push('', '| Year | Days inside |', '| --- | --- |'); st.years.forEach(function (y) { out.push('| ' + y.year + ' | ' + y.days + ' |'); }); }
      out.push('');
    });
    return out.join('\n');
  }
  var API = {
    oneLine: oneLine, parseIcs: parseIcs, permitWatch: permitWatch, yearReport: yearReport,
    PRESETS: PRESETS, dn: dn, str: str, todayStr: todayStr, addDays: addDays, validDate: validDate, cleanRule: cleanRule,
    stayDays: stayDays, usedOn: usedOn, summary: summary, maxStay: maxStay, lastDay: lastDay, earliestEntry: earliestEntry, strip: strip,
    validDraft: validDraft, simulate: simulate, addDraft: addDraft, removeDraft: removeDraft, commitDrafts: commitDrafts, forecast: forecast, groupMaxStay: groupMaxStay, groupEarliest: groupEarliest, monthlyUsage: monthlyUsage, placeStats: placeStats, autoItinerary: autoItinerary, calendarMonth: calendarMonth, addMonth: addMonth, audit: audit, urgent: urgent, itineraryText: itineraryText, arrivalWindows: arrivalWindows, parseTrips: parseTrips, parseCsvTrips: parseCsvTrips, leaveOn: leaveOn, newTrips: newTrips, weeklyYear: weeklyYear, explainRule: explainRule, reminders: reminders, alerts: alerts, alertsIcs: alertsIcs,
    compareRules: compareRules, yearStats: yearStats, encodeShare: encodeShare, decodeShare: decodeShare, safeLastDay: safeLastDay, borderSheet: borderSheet, cleanBuffer: cleanBuffer, cleanNote: cleanNote, validTrip: validTrip, addTrip: addTrip, updateTrip: updateTrip, sanitize: sanitize, removeTrip: removeTrip, toCsv: toCsv, toIcs: toIcs, csvCell: csvCell, makeKey: makeKey, validKey: validKey
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else root.SL = API;
})(typeof window !== 'undefined' ? window : globalThis);
